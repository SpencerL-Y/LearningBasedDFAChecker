1. tools, algorithms to compute the complementation of Buechi.
2. initial experimental results.
