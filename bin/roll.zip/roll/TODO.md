# What we have don in ROLL project

## Learner support

## File format support


# What we plan to do in ROLL project

The things we are going to do are categorized as below.

## What we must do next

1. A new automaton data structure which is easier to manipulate. (Easy to add and delete states and transitions)

2. Refactor the procedure for learning algorithm (CeAnalysis, FilterSuffix etc.).

3. Learning algorithm for deterministic omega automata (including Rabin, Street and Parity automata). In particular, we need to implement the teachers for FDFA, Rabin, Street and Parity automata.

4. More tests for the code. (Start with the words package)

5. Documents.

6. Expcetion class.

7. Learning algorithm for BDDs (Using JavaBDD as uniform interface).

8. BDD-based learning algorithm for DFAs.

9. Remove dk dependency since it requires characters as letters

## What we can do in the future

1. Bisimulation algorithm for DFAs and NFAs. (Antichain etc.)

2. Synthesis algorithm for reactive or programs.

3. Independent Automata package.

4. Make the source code publicly available (Bitbucket and Github).

5. Minimization for DBAs and DRAs (Using SAT solvers).
