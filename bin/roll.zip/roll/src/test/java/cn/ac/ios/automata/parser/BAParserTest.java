package cn.ac.ios.automata.parser;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;

import automata.FiniteAutomaton;
import cn.ac.ios.automata.parser.ba.JBAParser;

public class BAParserTest {
	
	public static void main(String[] args) throws FileNotFoundException {
		String file = "/home/liyong/workspace/roll/aab.ba";
		InputStream reader = new FileInputStream(new File(file));
		JBAParser parser = new JBAParser(reader);
		
		FiniteAutomaton a = parser.parse();
		System.out.println(a.toString());
	}

}
