/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.tree.fdfa;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import cn.ac.ios.automata.words.Word;
import cn.ac.ios.query.MembershipOracle;
import cn.ac.ios.query.Query;

public class MembershipOracleImpl implements MembershipOracle<Boolean> {
	@Override
	public Boolean answerMembershipQuery(Query<Boolean> query) {
		Word wordLeft = query.getPrefix();
		Word wordRight = query.getSuffix();
		System.out.println("Is (" + wordLeft.toStringWithAlphabet() 
		+ ", " + wordRight.toStringWithAlphabet() + ") in the unknown languge: 1/0");
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		boolean answer = false;
		 
		try {
			boolean finished = false;
			while(! finished) {
				String input = reader.readLine();
				if(input.equals("1")) {
					answer = true;
					finished = true;
				}else if(input.equals("0")) {
					answer = false;
					finished = true;
				}else {
					System.out.println("Illegal input, try again!");
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		query.answerQuery(answer);
		return answer;
	}
}
