/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.print;

import java.io.OutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.List;

import cn.ac.ios.table.ObservationTable;

public class PrintTest {
	
	public class ObservationRowTest {
		private String word ;
		private List<Boolean> values;
		
		public ObservationRowTest(String word, List<Boolean> values) {
			this.word = word;
			this.values = values;
		}
		
		public String getWord() {
			return word;
		}
		public List<Boolean> getValues() {
			return values;
		}
	}
	
	public static void main(String []args) {
		PrintTest printTest = new PrintTest();
		printTest.print(System.out);
	}
	
	public void print(OutputStream stream) {
		PrintStream out = new PrintStream(stream);
		List<ObservationRowTest> upperTable = new ArrayList<>();
		List<ObservationRowTest> lowerTable = new ArrayList<>();
		List<String> columns = new ArrayList<>();
		String epsilon = "ϵ";
		String a = "a";
		String b = "b";
		String ab = "ab";
		String aa = "aa";
		String aaa = "aaa";
		
		//columns
		columns.add(epsilon);
		columns.add(aaa);
		columns.add(aa);
		columns.add(a);
		
		// upper table
		List<Boolean> mpmm = new ArrayList<>();
		mpmm.add(false); mpmm.add(true); mpmm.add(false); mpmm.add(false);  
		upperTable.add(new ObservationRowTest(epsilon, mpmm));
		List<Boolean> mppm = new ArrayList<>();
		mppm.add(false); mppm.add(true); mppm.add(true); mppm.add(false); 
		upperTable.add(new ObservationRowTest(a, mppm));
		
		// lower table
		lowerTable.add(new ObservationRowTest(b, mpmm));
		List<Boolean> mpmp = new ArrayList<>();
		mpmp.add(false); mpmp.add(true); mpmp.add(true); mpmp.add(false); 
		lowerTable.add(new ObservationRowTest(ab, mpmp));
		List<Boolean> mppp = new ArrayList<>();
		mppp.add(false); mppp.add(true); mppp.add(true); mppp.add(true); 
		lowerTable.add(new ObservationRowTest(aa, mppp));
		// upper tabke 
		int[] maxNum4Cols = new int[columns.size() + 1];
		for(ObservationRowTest row : upperTable) {
			String word = row.getWord();
			maxNum4Cols[0] = Integer.max(word.length(), maxNum4Cols[0]);
		}
		
		for(ObservationRowTest row : lowerTable) {
			String word = row.getWord();
			maxNum4Cols[0] = Integer.max(word.length(), maxNum4Cols[0]);
		}
		
		for(int colNr = 0; colNr < columns.size() ; colNr ++) {
			String word = columns.get(colNr);
			maxNum4Cols[colNr + 1] = Integer.max(word.length(), maxNum4Cols[colNr + 1]);
		}
		Formatter f = new Formatter(out);
		// first print out columns
		f.format("%-" + maxNum4Cols[0] + "s || ", " ");
		
		for(int colNr = 0; colNr < columns.size() ; colNr ++) {
			f.format("%-" + maxNum4Cols[colNr + 1] + "s | ", columns.get(colNr));
		}
		f.format("\n");
		// separator for headers 
		for(int colNr = 0; colNr < maxNum4Cols.length ; colNr ++) {
			int numEq = maxNum4Cols[colNr] + 3;
			for(int i = 0; i < numEq; i ++) {
				f.format("=");
			}
		}
		f.format("\n");
		// upper table
		for(ObservationRowTest row : upperTable) {
			f.format("%-" + maxNum4Cols[0] + "s || ", row.getWord());
			for(int colNr = 0; colNr < columns.size() ; colNr ++) {
				String str = row.getValues().get(colNr) ? "+" : "-";
				f.format("%-" + maxNum4Cols[colNr + 1] + "s | ", str);
			}
			f.format("\n");
		}
		// separator for upper 
		for(int colNr = 0; colNr < maxNum4Cols.length ; colNr ++) {
			int numEq = maxNum4Cols[colNr] + 3;
			for(int i = 0; i < numEq; i ++) {
				f.format("=");
			}
		}
		f.format("\n");
		// lower table
		for(ObservationRowTest row : lowerTable) {
			f.format("%-" + maxNum4Cols[0] + "s || ", row.getWord());
			for(int colNr = 0; colNr < columns.size() ; colNr ++) {
				String str = row.getValues().get(colNr) ? "+" : "-";
				f.format("%-" + maxNum4Cols[colNr + 1] + "s | ", str);
			}
			f.format("\n");
		}
		
		String word = "abc", splitter = "";
		String[] wordArr = word.split(splitter);
		for(int i = 0; i < wordArr.length ; i ++) {
			System.out.println(wordArr[i]);
		}
		
	}
}
