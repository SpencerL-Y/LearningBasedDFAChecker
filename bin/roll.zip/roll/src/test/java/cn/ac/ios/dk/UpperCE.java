/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.dk;

import automata.FiniteAutomaton;
import cn.ac.ios.util.UtilAutomaton;
import dk.brics.automaton.Automaton;
import dk.brics.automaton.State;
import dk.brics.automaton.Transition;

public class UpperCE {
	
	public static void main(String[] args) {
		Automaton m = buildLeading() ;
		Automaton p1 = buildProgress();
		Automaton pa = buildProgressa();
		Automaton pb = buildProgressb();
		Automaton pc = buildProgressc();
		
		State u = m.getInitialState();
		
		Automaton paclone = pa.clone();
		State acc = paclone.getAcceptStates().iterator().next();
		paclone.setInitialState(acc);
		paclone = paclone.intersection(pa);
		paclone = UtilAutomaton.addEpsilon(paclone);
		State init = paclone.getInitialState();
		for (Transition t : init.getTransitions())
			u.addTransition(new Transition(t.getMin(), t.getMax(), t.getDest()));
		
		Automaton pbclone = pb.clone();
		acc = pbclone.getAcceptStates().iterator().next();
		pbclone.setInitialState(acc);
		pbclone = pbclone.intersection(pb);
		pbclone = UtilAutomaton.addEpsilon(pbclone);
		init = pbclone.getInitialState();
		for (Transition t : init.getTransitions())
			u.addTransition(new Transition(t.getMin(), t.getMax(), t.getDest()));
		
		Automaton pcclone = pc.clone();
		acc = pcclone.getAcceptStates().iterator().next();
		pcclone.setInitialState(acc);
		pcclone = pcclone.intersection(pc);
		pcclone = UtilAutomaton.addEpsilon(pcclone);
		init = pcclone.getInitialState();
		for (Transition t : init.getTransitions())
			u.addTransition(new Transition(t.getMin(), t.getMax(), t.getDest()));
		
		System.out.println("" + m.toDot());
		
		FiniteAutomaton aut = UtilAutomaton.convertToRabitAutomaton(m);
		aut.saveAutomaton("C:/Users/liyong/workspace/jalf/jalf/testinc.ba");
		
	}
	
	private static Automaton buildLeading() {
		Automaton c = new Automaton();
		State init = new State();
		init.addTransition(new Transition('a', init));
		init.addTransition(new Transition('b', init));
		init.addTransition(new Transition('c', init));
		c.setInitialState(init);
		System.out.println("leading: " + c.toDot());
		return c;
	}
	
	private static Automaton buildProgress() {
		FiniteAutomaton aut = new FiniteAutomaton("C:/Users/liyong/workspace/jalf/jalf/inc.ba");
		Automaton c = UtilAutomaton.convertToDkAutomaton(aut);
		System.out.println("progress: " + c.toDot());
		
		return c;
	}
	private static Automaton buildProgressa() {
		FiniteAutomaton aut = new FiniteAutomaton("C:/Users/liyong/workspace/jalf/jalf/inca.ba");
		Automaton c = UtilAutomaton.convertToDkAutomaton(aut);
		System.out.println("progressa: " + c.toDot());
		
		return c;
	}
	private static Automaton buildProgressb() {
		FiniteAutomaton aut = new FiniteAutomaton("C:/Users/liyong/workspace/jalf/jalf/incb.ba");
		Automaton c = UtilAutomaton.convertToDkAutomaton(aut);
		System.out.println("progressb: " + c.toDot());
		
		return c;
	}
	private static Automaton buildProgressc() {
		FiniteAutomaton aut = new FiniteAutomaton("C:/Users/liyong/workspace/jalf/jalf/incc.ba");
		Automaton c = UtilAutomaton.convertToDkAutomaton(aut);
		System.out.println("progressc: " + c.toDot());
		
		return c;
	}

}
