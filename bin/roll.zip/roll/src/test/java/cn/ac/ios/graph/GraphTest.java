/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.graph;

import cn.ac.ios.value.ValueManager;
import cn.ac.ios.automata.AccType;
import cn.ac.ios.value.Type;
import cn.ac.ios.value.Value;

public class GraphTest {
	
	public static void main(String []args) {
		ValueManager context = new ValueManager();
		
		GraphSimple graph = new GraphSimple(context);
		
		Type typeModel = context.newTypeObject(AccType.class);
		
		Value valueModel = graph.addSettableGraphProperty(Properties.SEMANTICS, typeModel);
		valueModel.set(AccType.WEIGHT);
		
		Type typeWeight = context.newTypeDouble();
		Value weight = typeWeight.newValue();
		
		Type typeNode = context.newTypeInteger();
		Value nodeIdx = typeNode.newValue();
		
		NodeProperty nodeProp = graph.addSettableNodeProperty(Properties.LABEL, typeNode);
		
		EdgeProperty edgeProp = graph.addSettableEdgeProperty(Properties.WEIGHT, typeWeight);
		
		graph.queryNode(0);
		graph.prepareNode(2);
		
		nodeIdx.set(0);
		nodeProp.set(nodeIdx);
		
		graph.setSuccessorNode(0, 1);
		weight.set(0.3);
		edgeProp.set(weight, 0);
		
		graph.setSuccessorNode(1, 2);
		weight.set(0.7);
		edgeProp.set(weight, 1);
		
		graph.queryNode(1);
		nodeIdx.set(1);
		nodeProp.set(nodeIdx);
		graph.prepareNode(1);
		graph.setSuccessorNode(0, 1);
		weight.set(1.0);
		edgeProp.set(weight, 0);
		
		graph.queryNode(2);
		nodeIdx.set(2);
		nodeProp.set(nodeIdx);
		graph.prepareNode(1);
		graph.setSuccessorNode(0, 2);
		weight.set(1.0);
		edgeProp.set(weight, 0);
		
//		graph.explore();
		System.out.println(GraphExporterDOT.toString(graph));
		
		// 0 -> 1 : 0.3 1-> 1 : 1
		// 0 -> 2 : 0.7 2-> 2 : 1
		
		
	}

}
