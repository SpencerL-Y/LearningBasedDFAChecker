/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.word;

import automata.FiniteAutomaton;
import cn.ac.ios.automata.words.Alphabet;
import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.automata.words.Word;
import cn.ac.ios.util.AutomatonPrinter;
import cn.ac.ios.util.DollarAutomatonBuilder;

import cn.ac.ios.util.UtilAutomaton;
import cn.ac.ios.value.ValueManager;
import cn.ac.ios.value.Type;
import cn.ac.ios.value.Value;
import dk.brics.automaton.Automaton;

public class WordTest {
	
	public static void main(String[] args) {
		
		
		ValueManager contextValue = new ValueManager();
		WordManager contextWord = new WordManager(contextValue);
		
		Type typeObject = contextValue.newTypeLetter(String.class);
		Value valueLetter = typeObject.newValue();
		
		Alphabet alphabet = contextWord.getAlphabet();
		
		valueLetter.set("a");
		alphabet.add(valueLetter.clone());
		valueLetter.set("b");
		alphabet.add(valueLetter.clone());
		valueLetter.set("c");
		alphabet.add(valueLetter.clone());
		valueLetter.set("");
		contextWord.setLetterSplitter(valueLetter.clone());
		Word emptyWord = contextWord.getEmptyWord();
		System.out.println(alphabet.toString());
		System.out.println(emptyWord);
		System.out.println(contextWord.getLetterWord(2) + " = " + contextWord.getLetterWord(2).toStringWithAlphabet());
		
		Word word = emptyWord.fromLetters(new int[]{2,0,1});
		System.out.println(word.toString());
		System.out.println(word.toStringWithAlphabet());
		
		Word prefix = emptyWord.fromLetters(new int[]{0, 1, 0});
		Word suffix = emptyWord.fromLetters(new int[]{1, 0}); 
		
		Automaton aut = DollarAutomatonBuilder.buildDollarAutomaton(prefix, suffix);
		FiniteAutomaton rabitAut = UtilAutomaton.convertToRabitAutomaton(aut);
		System.out.println("prefix: " + prefix.toStringWithAlphabet());
		System.out.println("suffix: " + suffix.toStringWithAlphabet());
		AutomatonPrinter.print(rabitAut, System.out);
		
		String p = "acaaaccbbbcbccbbbbaacaccabccbabccabbaaaacbacccaacbbcbcaaacbccbbaabbaacabbaccbbababbacbacabaabaccbbbcccbcbbacacccbabcabaacaacaaabbacbaacacabbcacbbcbbbbaccaabbbaccbacaabbacabacbaccbbcccbcbcccabacabbbaaaaccaabcaabaacccbaaaaaacbbccabbcacacccbabaaaaaaccaabbbbcacabacbcbaaaaaccabaaaaacabaacbaacbabacabacabacaacbbabcbcbabccabacbaacbbbabbccccabbcaabbccbabaccccccacbbaaacabbbbabbaccabbbcccbbcbcbcabcbbbacaccaabababaaaccacaccbccccbccacabcabaabcbabaabccbcbbcaacbcbccccbcabbccbccccbccacaaaaccbbcbaacbcbccccaacccacccaacbbbbaaacbacbaacbbaacaabcbabbbcaaaaabaaaaccaccacbcbccbccccbbcbcbaacbacbabbccaaaccbacaacbaaacacbaaacbabacaabbacacababaabbbbcabacbaabccaaabacbabaaacaacaacacbbbaccbbbabbbcabcbbcbbbaabbbacbbbacacabcccaaccacabbbcaccbbbbccbbaabcccbcbabbbccbcabaabcaaacccabccbbbbabbabbacbbbccccbaabbccccccbbcbabbbaabbaacacacaacaabccbbaccccbaccbaabacbacaccbbbcaaacccabbccccbccbcbababbcbcbabccbbabbccbabbcbcbacaacabcbbccacabcabcabcbbcabcaaabcaabcaacbcbaacabacbabbcabcbbbcabccbbbacababaabaaaacccabbbbcccbacbabcaacabaacccaccabbcacbabccacbcaacacbbccbccaababbbbcbcacccbbbaaaaaacabacccbabbcbbabaabacaabcaccabaabccccbcbbbacaccbcaacbaaaaacbabccaccbcbcbaabacbacbcbbcabcbccaaabbbbbcccaaaccbaacaaaabbbbcaacbabacacccababcaabcabacbabbcaaabcaabacbcbacaaaaaaccaccbbabbaacaacccbbbabbbbbaabcaaaacaabbacaccbbcacccbbcbcababbccbbbaabaacabbbccbccbbcbccccccccbcbcbbbbbaaccccabcaccbbbccaccbbcbcccabcbabbabababcabbaabbcacbcbaacbabccbacbbbccababccbbbbaabacbbcbaccbababbccaaaaaabbbcaacaacabbbabacccbabbcbbbbccbbccbcabbaaccabcbcbaaacbaacaaacbcaaacabcbaaacacbaabcbcbacbaacaaccacaabcacacacacbccbbccbcccacbbbaaacabababbcbbabbaccbcbabcbaacaaacacababcacbbccbcacacbcabbbcccbbbcaaabacccbaccbabcacaccacaaccacccbcaaabbaaaaacbcabcccbaccaacbbaccabbbbccaaacbaabacbcababaaacbbbbbbaabbccbbbccaaaacbbababbaaacabcccabbaaaaaaacaaaacabbaccaabbbbcabbbbaabaccbcabacaaaccbbbcabcbaacbcacacccbaccabbbbabcaacbbaaaaaacbcbcababbbaccaaaabcacaaaaacaaacccbcacacbbbbbbbaaaaaccbabbaacabbcccaabcaaababbacbbcaaccccbcbabcbbaacbbaaccabacbbbccccabbabacbcbcbbcabbcbcaacbaabacaabbaccbbbcccacccaabacbcacccbbabcaaccccbacbbcabbccccbacaacccacacbacbcbacaacccaacbcababababccbbbccabaabaaaccacbbccbacacccaaaaabcbcaababa:aaaacacbccccaacabababcabccabacabacbbcbcabbaacbccaabccaaacaacbacaccbacabccabbcacababaaaacacaaaacccbaaacbbcbbcaacaacbabbabaabbbaaaaaaaccacccbaacacabbcbcccbbaaaaacccbbcccaaabaaacaabbcaccacbaacbacacbcbccccbcccbcacaababbbcbbaabcaccabbcccccaaaaaaaabcbcbaabbbbbbbcccaabaabcaabaccbbcccacbbcccbaaacabbaabcccbbbacbcabbabbabaabbacbbaccababccbacacabbbccbaabaaacbcaacabbacabcacbccaababbcbacbacbacabcacccbbcbaabbbacbcacccccbaccccababbacbbbbbabbcbaccbacbaccbabccaccacabaaaacccaabcaabcaccaaaaabbbbacccababbaaaacbacacaccbbccbbccbbbcacbbccbacabcbbcbacacbbbbacbbbcaacaaaabbcbacacbacaccccbcccbcacbcbbccacacaccacccabacaaacbbaaacaccabaaaaaaaacbbcaaabacaacacbaccbaabacbcbcbaaaccaaaabaacbcbacccaaaaabbaaacbbcabbcacabaacacbacabbbabbccacbaabbbacccbcacccaabacccbcabccbcabbcbaacaaabbcbacccabaabbccccccacaaabacaccbaabcbbcbbaacaccacaabbbaccacaccacbaabaacbbacbabaacbccacbaccabccbcaaabbbcbbabacaacbbbccccbbcbbaaacaccbaaccacbccbacbcbcacbaabcbccbaccacccacababccbcbcacccbabbcccbcbacaabaaccaccacbbccacbcababaccbccabcbbbcbbacacaabbaba";
		int k = -1;
		for(int i = 0; i < p.length(); i ++) {
			
			if(p.charAt(i) == ':') {
				k = i;
				System.out.println("hello: " + p.charAt(i));
				break;
			}
			else if((p.charAt(i) != 'a') && (p.charAt(i) != 'b') && (p.charAt(i) != 'c'))
				System.out.println(p.charAt(i));
			
		}
		
		System.out.println("index of : is " + k + " " + p.length());
		
		Word pr = contextWord.getWordFromString(p.substring(0, k), "");
		
		Word sf = contextWord.getWordFromString(p.substring(k+1, p.length()), "");
		
		System.out.println("length of suffix " + sf.length());
		
		Word period = computeSmallestPeriod(sf);
		System.out.println("reduced of suffix " + period.length());
		
		for (int i = 1; i <= sf.length() / 2; i++) {
			if (sf.length() % i == 0) {
				Word rep = sf.getPrefix(i);
				for (int j = 1; j < suffix.length() / i; j++)
					rep = rep.concat(rep);
				if (rep.equals(sf)) {
					sf = sf.getPrefix(i);
					break;
				}
			}
		}
		System.out.println("reduced of suffix " + sf.length());
		sf = contextWord.getWordFromString("abbaabbaabba");
		System.out.println("length of suffix " + sf.length());
		period = computeSmallestPeriod(sf);
		System.out.println("reduced of suffix " + period.length());
	}
	
	
	private static Word computeSmallestPeriod(Word period) {

		// from the possible smallest length
		for(int i = 1; i <= period.length() / 2; i ++) {
			// can be divided
			if (period.length() % i == 0) {
				Word rep = period.getPrefix(i);
				// compute the number of repeat
				int num = period.length() / i;
				boolean repeated = true;
				for(int j = 0; j < num; j ++) {
					int pNr = j * i;
					Word p = period.getSubWord(pNr, i);
					if(! p.equals(rep)) {
						repeated = false;
						break;
					}
				}
				// reduce the period
				if(repeated) { 
					period = rep;
					break;
				}
			}
		}
		
		return period;
		
	}

}
