/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.wlearner;

import cn.ac.ios.automata.Automaton;
import cn.ac.ios.automata.words.Alphabet;
import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.automata.words.Word;
import cn.ac.ios.learner.Learner;
import cn.ac.ios.learner.buechi.ldollar.*;
import cn.ac.ios.learner.lstar.LearnerLStar;
import cn.ac.ios.wlearner.EquivalenceOracleImpl;
import cn.ac.ios.query.MembershipOracle;
import cn.ac.ios.query.Query;
import cn.ac.ios.query.QuerySimple;
import cn.ac.ios.value.ValueManager;
import cn.ac.ios.value.Type;
import cn.ac.ios.value.Value;

public class WLStarTest {
	
	public static void main(String []args) {
		
		ValueManager contextValue = new ValueManager();
		WordManager contextWord = new WordManager(contextValue);
		Type typeObject = contextValue.newTypeObject(String.class);
		contextValue.newTypeLetter(String.class);
		Value valueLetter = typeObject.newValue();
		Alphabet alphabet = contextWord.getAlphabet();
		valueLetter.set("$");
		alphabet.add(valueLetter.clone());
		valueLetter.set("a");
		alphabet.add(valueLetter.clone());
		valueLetter.set("b");
		alphabet.add(valueLetter.clone());
		valueLetter.set("c");
		alphabet.add(valueLetter.clone());
		alphabet.setImmutable();
		valueLetter.set("");
		contextWord.setLetterSplitter(valueLetter);
		MembershipOracle<Boolean> membershipOracle = new MembershipOracleImpl();
		Learner<Automaton, Boolean> lstar = new LearnerLStar(contextWord, membershipOracle);
		System.out.println("Start learning");
		lstar.startLearning();
		boolean result = false;
		while(true) {
			System.out.println("Table is both closed and consistent\n" + lstar.toString());
			Automaton model = lstar.getHypothesis();
			LDollartoBuchi LD = new LDollartoBuchi(model,contextWord);
			System.out.println("The L$ automaton:");
			System.out.println(LD.dktoString());
			boolean flag = LD.checkInclusion();
			System.out.println("Current hypothesis L$  contained in the language Σ*$Σ⁺ ：" + flag);
			EquivalenceOracleImpl equivalenceOracle = new EquivalenceOracleImpl();
			result = equivalenceOracle.answerEquivalenceQuery(flag, LD);
			if(result == true) break;
			Word word = InputHelper.getCeWord(contextWord, flag, LD);
			Query<Boolean> ceQuery = new QuerySimple<>(word);
			lstar.refineHypothesis(ceQuery);
		}
	}
}
