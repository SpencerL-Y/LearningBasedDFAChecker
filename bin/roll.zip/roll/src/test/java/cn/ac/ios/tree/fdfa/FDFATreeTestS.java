/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.tree.fdfa;

import cn.ac.ios.automata.Automaton;
import cn.ac.ios.automata.words.Alphabet;
import cn.ac.ios.automata.words.WordManager;

import cn.ac.ios.learner.fdfa.LearnerFDFA;
import cn.ac.ios.learner.fdfa.tree.LearnerFDFATreeSyntactic;
import cn.ac.ios.query.EquivalenceOracle;
import cn.ac.ios.query.MembershipOracle;
import cn.ac.ios.query.Query;
import cn.ac.ios.value.ValueManager;
import cn.ac.ios.value.Type;
import cn.ac.ios.value.Value;

public class FDFATreeTestS {
	public static void main(String []args) {
		
		ValueManager contextValue = new ValueManager();
		WordManager contextWord = new WordManager(contextValue);
		Type typeObject = contextValue.newTypeObject(String.class);
		contextValue.newTypeLetter(String.class);
		Value valueLetter = typeObject.newValue();
		Alphabet alphabet = contextWord.getAlphabet();
		
		valueLetter.set("a");
		alphabet.add(valueLetter.clone());
		valueLetter.set("b");
		alphabet.add(valueLetter.clone());
		alphabet.setImmutable();
		valueLetter.set("");
		contextWord.setLetterSplitter(valueLetter);
		MembershipOracle<Boolean> membershipOracle = new MembershipOracleImpl();
		LearnerFDFA fdfa = new LearnerFDFATreeSyntactic(contextWord, membershipOracle);
		System.out.println("starting learning");
		fdfa.startLearning();
		boolean result = false;
		while(true) {
			System.out.println("Current tables are as follows: \n" + fdfa.toString());
			fdfa.getHypothesis();
			EquivalenceOracle<Automaton, Boolean> equivalenceOracle = new EquivalenceOracleImpl();
			result = equivalenceOracle.answerEquivalenceQuery(null);
			if(result == true) break;
			Query<Boolean> ceQuery = InputHelper.getCeWord(contextWord);
		    fdfa.refineHypothesis(ceQuery);
			System.out.println("Current tree is as follows: \n" + fdfa.toString());
		}
		
	}
}
