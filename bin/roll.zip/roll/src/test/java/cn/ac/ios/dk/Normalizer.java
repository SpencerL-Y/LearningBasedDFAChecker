/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.dk;

import cn.ac.ios.automata.words.Alphabet;
import cn.ac.ios.automata.words.WordManager;

import cn.ac.ios.util.UtilAutomaton;
import cn.ac.ios.value.ValueManager;
import cn.ac.ios.value.Type;
import cn.ac.ios.value.Value;
import cn.ac.ios.automata.Automaton;
import cn.ac.ios.automata.DFA;
import dk.brics.automaton.State;
import dk.brics.automaton.Transition;
import gnu.trove.map.TIntObjectMap;
import gnu.trove.map.hash.TIntObjectHashMap;

public class Normalizer {
	
	private static Automaton buildLeadingAutomaton() {
		
		ValueManager contextValue = new ValueManager();
		WordManager contextWord = new WordManager(contextValue);
		
		Type typeObject = contextValue.newTypeObject(Character.class);
		Value valueLetter = typeObject.newValue();
		
		Alphabet alphabet = contextWord.getAlphabet();
		
		valueLetter.set(new Character('a'));
		alphabet.add(valueLetter.clone());
		valueLetter.set(new Character('b'));
		alphabet.add(valueLetter.clone());
		
		Automaton dfa = new DFA(contextWord);
		
		
		dfa.addNewState(0);
		dfa.setInitial();
		dfa.addTransition(0, 1);
		dfa.addTransition(1, 2);
		dfa.addNewStateEnd();
		
		dfa.addNewState(1);
		dfa.addTransition(0, 1);
		dfa.addTransition(1, 1);
		dfa.addNewStateEnd();
		
		dfa.addNewState(2);
		dfa.addTransition(1, 0);
		dfa.addTransition(0, 3);
		dfa.addNewStateEnd();
		
		dfa.addNewState(3);
		dfa.addTransition(1, 3);
		dfa.addTransition(0, 3);
		dfa.addNewStateEnd();
		

		System.out.println("\n" + dfa.toString());;
		return dfa;
	}
	
	public static void main(String[] args) {
		TIntObjectMap<State> map = new TIntObjectHashMap<>(); 
		Automaton autL = buildLeadingAutomaton();
		dk.brics.automaton.Automaton dkAutL = UtilAutomaton.convertToDkAutomaton(map, autL);
		String uv = "$abab";
		int dollarNr = uv.indexOf(WordManager.getStringDollar());
		
		String u = uv.substring(0, dollarNr);
		String v = uv.substring(dollarNr + 1);
		
		dk.brics.automaton.Automaton dkAutStrU = dk.brics.automaton.Automaton.makeString(u);
		dk.brics.automaton.Automaton dkAutStrV = dk.brics.automaton.Automaton.makeString(v);
		System.out.println(dkAutStrV.toDot());
		dk.brics.automaton.Automaton dkAutStrDollar = dk.brics.automaton.Automaton.makeString(WordManager.getStringDollar());
		dk.brics.automaton.Automaton dkAutStrVStar = dkAutStrV.clone().repeat(0); // V*
		dk.brics.automaton.Automaton dkAutStrVPlus = dkAutStrV.clone().repeat(1); // V+
		
		dkAutStrU = dkAutStrU.concatenate(dkAutStrVStar);
		dkAutStrU = dkAutStrU.concatenate(dkAutStrDollar);
		dkAutStrU = dkAutStrU.concatenate(dkAutStrVPlus);
		dkAutStrU.minimize();
		System.out.println(dkAutStrU.toDot());
		
		for(int stateNr = 0; stateNr < autL.getNumStates() ; stateNr ++) {
			dk.brics.automaton.Automaton dkAutLOther = UtilAutomaton.convertToDkAutomaton(autL, stateNr, stateNr);
			State state = map.get(stateNr);
			
			Transition trans = new Transition(WordManager.getStringDollar().charAt(0), dkAutLOther.getInitialState());
			state.addTransition(trans);
			
			dk.brics.automaton.Automaton dkAutInter = dkAutStrU.intersection(dkAutL);
			System.out.println(stateNr + " :\n " + dkAutInter.toDot());
			String decomposition = dkAutInter.getShortestExample(true);
			
			if(decomposition != null) {
				System.out.println("" + decomposition);
				break;
			}
			
			state.getTransitions().remove(trans);
		}
		System.out.println(dkAutL.toDot());
		
		
		
		
	}

}
