/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.mem;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.Test;

import automata.FiniteAutomaton;
import cn.ac.ios.oracle.BuechiRunner;
import cn.ac.ios.roll.sampler.BuechiSampler;
import cn.ac.ios.util.AutomatonPrinter;
import cn.ac.ios.util.Pair;
import oracle.AutomatonBuilder;
import oracle.EmptinessCheck;
import oracle.ProductBuilder;

public class BuechiRunnerTest {

	static FiniteAutomaton aut;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		String file = "C:/Users/liyong/workspace/jalf/jalf/bug.ba";
		aut = new FiniteAutomaton(file);
		AutomatonPrinter.print(aut, System.out);
	}
	
	private static List<String> getList(String word) {
		List<String> lst = new ArrayList<>();
		String[] letters = word.split("");
		
		for(String letter : letters) {
			lst.add(letter);
		}
		
		return lst;
	}
	
	private boolean isAcc(List<String> prefix, List<String> suffix) {
		AutomatonBuilder builder = new AutomatonBuilder(prefix, suffix);
		System.out.println(prefix + ", " + suffix);
		FiniteAutomaton b = builder.build();
		System.out.println("b ---------");
		AutomatonPrinter.print(b, System.out);
		FiniteAutomaton c = ProductBuilder.build(aut, b);
		System.out.println("c ---------");
		AutomatonPrinter.print(c, System.out);
		EmptinessCheck checker = new EmptinessCheck(c);
		return ! checker.isEmpty();
	}
	
	private boolean isAcc2(List<String> prefix, List<String> suffix) {
//		AutomatonOmegaBuilder builder = new AutomatonOmegaBuilder(prefix, suffix);
//		System.out.println(prefix + ", " + suffix);
//		FiniteAutomaton b = builder.build();
//		System.out.println("b ---------");
//		AutomatonPrinter.print(b, System.out);
		FiniteAutomaton c = ProductBuilder.build(aut, prefix, suffix);
		System.out.println("c ---------");
		AutomatonPrinter.print(c, System.out);
		EmptinessCheck checker = new EmptinessCheck(c);
		return ! checker.isEmpty();
	}

	@Test
	public void test() {

		for(int i = 0; i < 70; i ++) {
			Pair<List<String>, List<String>> word = BuechiSampler.sampleUniform(aut);
			System.out.println("=========== " + (i+1) + " th");
			assertEquals(true, isAcc2(word.getLeft(), word.getRight()));
			assertEquals(true, isAcc(word.getLeft(), word.getRight()));
		}


		
		assertEquals(true, isAcc2( getList("b"), getList("ab")));
		assertEquals(true, isAcc2( getList("bab"), getList("ba")));
		
	}

}
