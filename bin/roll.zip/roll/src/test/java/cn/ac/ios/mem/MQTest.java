/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.mem;

import java.util.ArrayList;
import java.util.List;

import automata.FiniteAutomaton;
import cn.ac.ios.oracle.BuechiRunner;
import cn.ac.ios.util.AutomatonPrinter;
import cn.ac.ios.util.UtilAutomaton;
import dk.brics.automaton.Automaton;
import oracle.EmptinessCheck;
import oracle.RabitOracle;

public class MQTest {
	
	private static List<String> getList(String word) {
		List<String> lst = new ArrayList<>();
		String[] letters = word.split("");
		
		for(String letter : letters) {
			lst.add(letter);
		}
		
		return lst;
	}
	
	public static void main(String[] args) {
		String file = "C:/Users/liyong/workspace/jalf/jalf/bug.ba";
		FiniteAutomaton automaton = new FiniteAutomaton(file);
		Automaton dkAut = UtilAutomaton.convertToDkAutomaton(automaton);
		Automaton pre = Automaton.makeString("acab");
		Automaton suf = Automaton.makeString("ab");
		
		suf = suf.repeat(1);
		
		
		Automaton autW = pre.concatenate(suf);
		System.out.println(autW.toDot());
		Automaton aut = dkAut.intersection(autW);

		System.out.println(aut.toDot());
		FiniteAutomaton pro = UtilAutomaton.convertToRabitAutomaton(aut); 
		AutomatonPrinter.print(pro, System.out);
		EmptinessCheck checker = new EmptinessCheck(pro);
		System.out.println("is empty: " + checker.isEmpty());
		List<String> prefix = getList("acab");
		List<String> suffix = getList("ab");
        System.out.println(prefix);
        System.out.println(suffix);
		System.out.println(BuechiRunner.isAccepting(automaton, prefix, suffix));
		RabitOracle rabit = new RabitOracle(automaton);
		System.out.println(rabit.isAccepted(prefix, suffix));
	}

}
