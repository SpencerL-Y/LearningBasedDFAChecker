/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.dk;

import automata.FiniteAutomaton;
import cn.ac.ios.oracle.Minimizer;
import cn.ac.ios.util.AutomatonPrinter;
import cn.ac.ios.util.LDBABuilder;
import cn.ac.ios.util.UtilAutomaton;
import dk.brics.automaton.Automaton;
import dk.brics.automaton.State;
import dk.brics.automaton.Transition;

public class DkAutomaton {
	
	private static Automaton buildLeadingAutomaton() {
		Automaton autL = new Automaton();
		State init = new State();
		State a = new State();
		State b = new State();
		State ba = new State();
		
		init.addTransition(new Transition('a', a));
		init.addTransition(new Transition('b', b));
		
		a.addTransition(new Transition('a', a));
		a.addTransition(new Transition('b', a));
		
		b.addTransition(new Transition('b', init) );
		b.addTransition(new Transition('a', ba) );
		
		ba.addTransition(new Transition('a', ba));
		ba.addTransition(new Transition('b', ba));
		
		autL.setDeterministic(true);
		autL.setInitialState(init);
		return autL;
	}
	
	private static Automaton buildAnAutomaton() {
		Automaton autA = new Automaton();
		State init = new State();
		State b = new State();
		State ba = new State();
		
		init.addTransition(new Transition('a',init));
		init.addTransition(new Transition('b', b));

		
		b.addTransition(new Transition('b', init) );
		b.addTransition(new Transition('a', ba) );
		
		b.setAccept(true);
		
		ba.addTransition(new Transition('a', ba));
		ba.addTransition(new Transition('b', ba));
		
		autA.setDeterministic(true);
		autA.setInitialState(init);
		return autA;
	}
	
	private static Automaton buildAnAutomaton2() {
		Automaton autA = new Automaton();
		State init = new State();
		State b = new State();
		
		init.addTransition(new Transition('a',init));
		init.addTransition(new Transition('b', b));

		
		b.addTransition(new Transition('b', b) );
		b.addTransition(new Transition('a', b) );
		
		b.setAccept(true);
		
		
		autA.setDeterministic(true);
		autA.setInitialState(init);
		return autA;
	}
	
	private static Automaton buildAutomaton3() {
		Automaton autA = new Automaton();
		State init = new State();
		State b = new State();
		
		State acc = new State();
		
		init.addTransition(new Transition('a',init));
		init.addTransition(new Transition('b', b));

		
		b.addTransition(new Transition('b', b) );
		b.addTransition(new Transition('a', b) );
		
		acc.addTransition(new Transition('a',init));
		acc.addTransition(new Transition('b', b));
		
		init.addTransition(new Transition('b', acc));
		b.addTransition(new Transition('b', acc));
		b.addTransition(new Transition('a', acc) );
		
		acc.setAccept(true);
		autA.setDeterministic(false);
		autA.setInitialState(init);
		return autA;
	}
	
	private static Automaton buildAutomaton4() {
		Automaton autA = new Automaton();
		State init = new State();
		State b = new State();
		
		State acc = new State();
		
		init.addTransition(new Transition('a',init));
		init.addTransition(new Transition('b', b));

		
		b.addTransition(new Transition('b', acc) );
		b.addTransition(new Transition('a', b) );
		
		acc.addTransition(new Transition('a', acc));
		acc.addTransition(new Transition('b', acc));
		
		acc.setAccept(true);
		autA.setDeterministic(true);
		autA.setInitialState(init);
		return autA;
	}
	
	private static Automaton buildAutomaton5() {
		Automaton autA = new Automaton();
		State init = new State();		
		State acc = new State();
		
		init.addTransition(new Transition('a', init));
		init.addTransition(new Transition('b', acc));
		
		acc.addTransition(new Transition('a', acc));
		acc.addTransition(new Transition('b', acc));
		
		acc.setAccept(true);
		autA.setDeterministic(true);
		autA.setInitialState(init);
		return autA;
	}
	
	private static Automaton buildAutomaton6() {
		Automaton autA = new Automaton();
		State init = new State();
		State b = new State();
		State c = new State();
		State acc = new State();
		
		init.addTransition(new Transition('a', init));
		init.addTransition(new Transition('b', b));
		init.addTransition(new Transition('c', c));
		init.addTransition(new Transition('b', acc));
		
		
		b.addTransition(new Transition('a', b));
		b.addTransition(new Transition('b', b));
		b.addTransition(new Transition('c', b));
		b.addTransition(new Transition('a', acc));
		b.addTransition(new Transition('b', acc));
		b.addTransition(new Transition('c', acc));
		
		
		c.addTransition(new Transition('a', b));
		c.addTransition(new Transition('a', acc));
		
		acc.addTransition(new Transition('a', init));
		acc.addTransition(new Transition('b', b));
		acc.addTransition(new Transition('c', c));
		
		acc.setAccept(true);
		autA.setDeterministic(false);
		autA.setInitialState(init);
		return autA;
	}
	
	private static Automaton buildAutomaton7() {
		Automaton autA = new Automaton();
		State init = new State();
		State c = new State();
		State acc = new State();
		
		init.addTransition(new Transition('a', init));
		init.addTransition(new Transition('b', acc));
		init.addTransition(new Transition('c', c));
		
		c.addTransition(new Transition('a', acc));
		
		acc.addTransition(new Transition('a', acc));
		acc.addTransition(new Transition('b', acc));
		acc.addTransition(new Transition('c', acc));
		
		acc.setAccept(true);
		autA.setDeterministic(true);
		autA.setInitialState(init);
		return autA;
	}
	
	private static Automaton buildAutomaton8() {
		Automaton autA = new Automaton();
		State init = new State();
		State qf = new State();
		State q0f = new State();
		State qcf = new State();
		State acc = new State();
		
		init.addTransition(new Transition('a', init));
		init.addTransition(new Transition('b', qf));
		
		qf.addTransition(new Transition('a', q0f));
		qf.addTransition(new Transition('b', acc));
		qf.addTransition(new Transition('c', qcf));
		
		acc.addTransition(new Transition('a', q0f));
		acc.addTransition(new Transition('b', acc));
		acc.addTransition(new Transition('c', qcf));
		
		q0f.addTransition(new Transition('a', q0f));
		q0f.addTransition(new Transition('b', acc));
		q0f.addTransition(new Transition('c', qcf));
		
		qcf.addTransition(new Transition('a', q0f));
		qcf.addTransition(new Transition('b', acc));
		qcf.addTransition(new Transition('c', qcf));
		
		acc.setAccept(true);
		autA.setDeterministic(true);
		autA.setInitialState(init);
		return autA;
	}
	
	private static Automaton buildAutomaton9() {
		Automaton autA = new Automaton();
		State init = new State();
		State acc = new State();
		
		init.addTransition(new Transition('a', init));
		init.addTransition(new Transition('b', acc));
		
		
		acc.addTransition(new Transition('a', init));
		acc.addTransition(new Transition('b', acc));
		
		acc.setAccept(true);
		autA.setDeterministic(true);
		autA.setInitialState(init);
		return autA;
	}
	
	private static Automaton buildAutomaton10() {
		Automaton autA = new Automaton();
		State init = new State();
		State acc = new State();
		
		init.addTransition(new Transition('a', init));
		init.addTransition(new Transition('b', acc));
		
		
		acc.addTransition(new Transition('a', acc));
		acc.addTransition(new Transition('b', acc));
		acc.addTransition(new Transition('c', acc));
		
		acc.setAccept(true);
		autA.setDeterministic(true);
		autA.setInitialState(init);
		return autA;
	}
	
	public static void main(String[] args) {
		Automaton autL = buildLeadingAutomaton();
		System.out.println("M : \n " + autL.toDot());
		Automaton autA = buildAnAutomaton();
		System.out.println("A : \n " + autA.toDot());
		
		Automaton pautA = autA.clone();
		State b = pautA.getInitialState().step('b');
		pautA.setInitialState(b);
		
		Automaton aut = autA.intersection(pautA);
		//aut.minimize();
		System.out.println("product : \n " + aut.toDot());
//		Automaton rautA = autA.repeat(1);
//		rautA.minimize();
//		System.out.println("RA : \n " + rautA.toDot());
//		
//		Automaton pAutL = autL.clone();
//		State a = pAutL.getInitialState().step('a');
//		pAutL.setInitialState(a);
//		a.setAccept(true);
//		
//		Automaton pAutA = rautA.clone();
//		State b = pAutA.getAcceptStates().iterator().next();
//		pAutA.setInitialState(b);
//		System.out.println("RRA : \n " + pAutA.toDot());
//		Automaton autInter = pAutA.intersection(rautA);
//		System.out.println("RA * RRA : \n " + autInter.toDot());
//		
//		Automaton autA2 = buildAnAutomaton2(); 
//		Automaton rautA2 = autA2.repeat(1);
//
//		System.out.println("RA2 : \n " + rautA2.toDot());
		Automaton au3 = buildAutomaton3();
		Automaton au4 = au3.clone();
		State acc = au4.getAcceptStates().iterator().next();
		
		
		
		System.out.println("A3 : \n " + au3.toDot());
		au3.determinize();
		System.out.println("DA3 : \n " + au3.toDot());
		
		Automaton aut4 = buildAutomaton4();
		Automaton aut5 = buildAutomaton5();
		
		System.out.println("A4 : \n " + aut4.toDot());
		System.out.println("A5 : \n " + aut5.toDot());
		
		Automaton aut6 = aut4.intersection(aut5);
		System.out.println("A6 : \n " + aut6.toDot());
		
		Automaton aut7 = buildAutomaton6();
		System.out.println("A7 : \n " + aut7.toDot());
		aut7.determinize();
		System.out.println("A7d : \n " + aut7.toDot());
		Automaton aut8 = buildAutomaton7();
		System.out.println("A8 : \n " + aut8.toDot());
		Automaton aut9 = aut8.repeat(1);
		if(aut9.subsetOf(aut8)) {
			if(aut8.subsetOf(aut9)) {
				System.out.println("true");
			}else {
				System.out.println(" 9 subsetof 8");
				Automaton n = aut8.minus(aut9);
				System.out.println(n.getShortestExample(true));
			}

		}else {
			Automaton n = aut9.minus(aut8);
			System.out.println(" 8 subsetof 9");
			System.out.println(n.getShortestExample(true));
		}
		
		aut9 = buildAutomaton7();
		System.out.println(aut9.repeat(1).toDot());
		
		Automaton aut10 = buildAutomaton8();
		System.out.println("10: \n" + aut10.toDot());
		
		Automaton aut11 = aut10.clone();
		State qff = aut11.getAcceptStates().iterator().next();
		aut11.setInitialState(qff);
		aut11.minimize();
		System.out.println("11: \n" + aut11.toDot());
		
		aut10 = aut10.intersection(aut11);
		System.out.println("inter: " + aut10.toDot());
		
		Automaton aut12 = buildAutomaton9();
		System.out.println("12: \n" + aut12.toDot());
		
		Automaton aut13 = aut12.clone();
		qff = aut13.getAcceptStates().iterator().next();
		aut13.setInitialState(qff);
		System.out.println("13: \n" + aut13.toDot());
		
		aut13 = aut12.intersection(aut13);
		System.out.println("13 inter: \n" + aut13.toDot());
		
		aut13 = aut12.minus(aut13);
		System.out.println("" + aut13.getShortestExample(true));
		
		aut13 = buildAutomaton6();
		FiniteAutomaton autN = UtilAutomaton.convertToRabitAutomaton(aut13);
		System.out.println("autN: \n" + aut13.toDot());
		autN = Minimizer.minimizeNFA(autN, 12);
		System.out.println("autN mini: \n");
		AutomatonPrinter.print(autN, System.out);
		
		Automaton dkaut = buildAutomaton10();
		System.out.println("dkaut: \n" + dkaut.toDot());
		
		LDBABuilder builder = new LDBABuilder(dkaut);
		Automaton c = builder.buildBuechi();
		c.minimize();
		System.out.println("dkaut: \n" + c.toDot());
		 build() ;
		
		 
		 //
		 System.out.println("no ----------");

	}
	
	private static Automaton build2() {
		Automaton autA = new Automaton();
		State a0 = new State();
		a0.addTransition(new Transition('a', a0));
		a0.addTransition(new Transition('b', a0));
		a0.addTransition(new Transition('c', a0));
		
		a0.setAccept(true);
		
		autA.setInitialState(a0);
		
		return autA;
	}
	
	private static Automaton build() {
		Automaton autA = new Automaton();
		State a0 = new State();
		State a1 = new State();
		State a2 = new State();
		State a3 = new State();
		State a4 = new State();
		State a5 = new State();
		State a6 = new State();
		State a7 = new State();
		State a8 = new State();
		State a9 = new State();
		State a10 = new State();
		State a11 = new State();
		State a12 = new State();
		State a13 = new State();
		State a14 = new State();
		
		a0.addTransition(new Transition('a', a2));
		a0.addTransition(new Transition('b', a7));
		a0.addTransition(new Transition('c', a1));
		
		a1.addTransition(new Transition('a', a4));
		a1.addTransition(new Transition('b', a8));
		a1.addTransition(new Transition('c', a1));
		
		a2.addTransition(new Transition('a', a6));
		a2.addTransition(new Transition('b', a5));
		a2.addTransition(new Transition('c', a3));
		
		a3.addTransition(new Transition('a', a13));
		a3.addTransition(new Transition('b', a1));
		a3.addTransition(new Transition('c', a3));
		
		a4.addTransition(new Transition('a', a6));
		a4.addTransition(new Transition('b', a1));
		a4.addTransition(new Transition('c', a1));
		
		a5.addTransition(new Transition('a', a14));
		a5.addTransition(new Transition('b', a1));
		a5.addTransition(new Transition('c', a14));
		
		a6.addTransition(new Transition('a', a6));
		a6.addTransition(new Transition('b', a1));
		a6.addTransition(new Transition('c', a6));
		
		a7.addTransition(new Transition('a', a9));
		a7.addTransition(new Transition('b', a11));
		a7.addTransition(new Transition('c', a12));
		
		a8.addTransition(new Transition('a', a14));
		a8.addTransition(new Transition('b', a1));
		a8.addTransition(new Transition('c', a1));
		
		a9.addTransition(new Transition('a', a1));
		a9.addTransition(new Transition('b', a10));
		a9.addTransition(new Transition('c', a1));
		
		a10.addTransition(new Transition('a', a9));
		a10.addTransition(new Transition('b', a1));
		a10.addTransition(new Transition('c', a9));
		
		a11.addTransition(new Transition('a', a1));
		a11.addTransition(new Transition('b', a11));
		a11.addTransition(new Transition('c', a1));
		
		a12.addTransition(new Transition('a', a1));
		a12.addTransition(new Transition('b', a4));
		a12.addTransition(new Transition('c', a1));
		
		a13.addTransition(new Transition('a', a6));
		a13.addTransition(new Transition('b', a1));
		a13.addTransition(new Transition('c', a3));
		
		a14.addTransition(new Transition('a', a1));
		a14.addTransition(new Transition('b', a5));
		a14.addTransition(new Transition('c', a1));
		
		a1.setAccept(true);
//		a3.setAccept(true);
//		a12.setAccept(true);
//		a10.setAccept(true);
//		
//		a4.setAccept(true);
//		a8.setAccept(true);
//		a14.setAccept(true);
		
		autA.setInitialState(a0);
		autA.minimize();
		System.out.println("-------\n" + autA.toDot());
		
		Automaton autB = build2();
		
		autB = autB.intersection(autA);
		autB.minimize();
		System.out.println("-------\n" + autB.toDot());
		
		
		return autA;
	}
	
	private static Automaton constructM() {
		Automaton m = new Automaton();
		
		State init = new State();
        State acc = new State();
        
		init.addTransition(new Transition('a', acc));
		init.addTransition(new Transition('b', init));
		acc.addTransition(new Transition('a', init));
		acc.addTransition(new Transition('b', acc));
		

		
		m.setInitialState(init);
		
		return m;
	}
	
	private static Automaton constructL() {
		Automaton m = new Automaton();
		
		State init = new State();
        State acc = new State();
        
		init.addTransition(new Transition('b', init));
		init.addTransition(new Transition('a', acc));
		acc.addTransition(new Transition('a', acc));
		acc.addTransition(new Transition('b', init));
		

		
		m.setInitialState(init);
		acc.setAccept(true);
		return m;
	}
	
	private static Automaton constructA() {
		Automaton m = new Automaton();
		
		State init = new State();
        State acc = new State();
        
		init.addTransition(new Transition('b', acc));
		init.addTransition(new Transition('a', acc));
		acc.addTransition(new Transition('a', acc));
		acc.addTransition(new Transition('b', init));
		

		
		m.setInitialState(init);
		acc.setAccept(true);
		return m;
	}

}
