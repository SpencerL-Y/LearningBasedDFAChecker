package cn.ac.ios.dd.graph;

import cn.ac.ios.automata.words.Alphabet;
import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.bdd.graph.BuechiBDD;
import cn.ac.ios.bdd.graph.IntersectionChecker;
import cn.ac.ios.value.Type;
import cn.ac.ios.value.Value;
import cn.ac.ios.value.ValueManager;
import dk.brics.automaton.Automaton;
import dk.brics.automaton.State;
import dk.brics.automaton.Transition;
import net.sf.javabdd.BDD;

public class TestBuechiBDD {
	
	public static void main(String[] args) {
		
		Automaton A = getA();
		Automaton B = getB();
		
		ValueManager values = new ValueManager();
		WordManager words = new WordManager(values);
		Type typeObject = values.newTypeLetter(String.class);
		Value valueLetter = typeObject.newValue();
		
		Alphabet alphabet = words.getAlphabet();
		
		valueLetter.set("a");
		alphabet.add(valueLetter.clone());
		valueLetter.set("b");
		alphabet.add(valueLetter.clone());
		
		System.out.println("A:\n" + A.toDot());
		System.out.println("B:\n" + B.toDot());
		
		IntersectionChecker checker = new IntersectionChecker(words, A, B);
		checker.prepareSymbolic();
		
		BuechiBDD bddA = checker.getBuechiA();
		BuechiBDD bddB = checker.getBuechiB();
		
		// 
		System.out.println("A");
		System.out.println("init: ");
		bddA.getInitial().printDot();
		System.out.println("trans:");
		bddA.getTransition().printDot();;
		System.out.println("accs:");
		for(BDD dd : bddA.getAcceptance()) {
			dd.printDot();
		}
		//
		System.out.println("B");
		System.out.println("init: ");
		bddB.getInitial().printDot();
		System.out.println("trans:");
		bddB.getTransition().printDot();;
		System.out.println("accs:");
		for(BDD dd : bddB.getAcceptance()) {
			dd.printDot();
		}
	}
	
	// accepts a^.. + (ab)^..
	private static Automaton getA() {
		Automaton A = new Automaton();
		State q0 = new State();
		State q1 = new State();
		State q2 = new State();
		
		A.setInitialState(q0);
		
		q0.addTransition(new Transition('a', q1));
		q1.addTransition(new Transition('a', q1));
		q1.addTransition(new Transition('b', q2));
		q2.addTransition(new Transition('a', q1));
		
		q1.setAccept(true);
		q2.setAccept(true);
		return A;
	}
	
	private static Automaton getB() {
		Automaton B = new Automaton();
		State q0 = new State();
		State q1 = new State();
		State q2 = new State();
		
		B.setInitialState(q0);
		
		q0.addTransition(new Transition('a', q1));
//		q1.addTransition(new Transition('a', q1));
		q1.addTransition(new Transition('b', q2));
		q2.addTransition(new Transition('a', q1));
		
		//q1.setAccept(true);
		q2.setAccept(true);
		return B;
	}

}
