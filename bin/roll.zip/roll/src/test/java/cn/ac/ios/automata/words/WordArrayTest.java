/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

/**
 * 
 */
package cn.ac.ios.automata.words;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import cn.ac.ios.value.ValueManager;
import cn.ac.ios.value.Type;
import cn.ac.ios.value.Value;

/**
 * @author liyong
 *
 */
public class WordArrayTest {

	/**
	 * @throws java.lang.Exception
	 */
	private static ValueManager contextValue = new ValueManager();
	private static WordManager contextWord ;
	private static int [] letters = {0,0,0,1,1,1,2,1,2,0,2,2}; //  aaabbbcbcacc
	private static Word wordLetter ;
	private static Word wordArray;
	private static Word wordEmpty;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		contextWord = new WordManager(contextValue);
		
		Type typeObject = contextValue.newTypeObject(Character.class);
		Value valueLetter = typeObject.newValue();
		
		Alphabet alphabet = contextWord.getAlphabet();
		
		valueLetter.set(new Character('a'));
		alphabet.add(valueLetter.clone());
		valueLetter.set(new Character('b'));
		alphabet.add(valueLetter.clone());
		valueLetter.set(new Character('c'));
		alphabet.add(valueLetter.clone());
		
		wordArray = contextWord.getArrayWord(letters);
		wordLetter = contextWord.getLetterWord(0);
		wordEmpty = contextWord.getEmptyWord();

	}

	/**
	 * Test method for {@link cn.ac.ios.automata.words.WordArray#isEmpty()}.
	 */
	@Test
	public void testIsEmpty() {
		assertEquals(true, wordEmpty.isEmpty());
		assertEquals(false, wordArray.isEmpty());
		assertEquals(false, wordLetter.isEmpty());
	}

	/**
	 * Test method for {@link cn.ac.ios.automata.words.WordArray#getFirstLetter()}.
	 */
	@Test
	public void testGetFirstLetter() {
		assertEquals(0, wordLetter.getFirstLetter());
		assertEquals(0, wordArray.getFirstLetter());
		assertEquals(-1, wordEmpty.getFirstLetter());
	}

	/**
	 * Test method for {@link cn.ac.ios.automata.words.WordArray#getLastLetter()}.
	 */
	@Test
	public void testGetLastLetter() {
		assertEquals(0, wordLetter.getLastLetter());
		assertEquals(2, wordArray.getLastLetter());
		assertEquals(-1, wordEmpty.getLastLetter());
	}

	/**
	 * Test method for {@link cn.ac.ios.automata.words.WordArray#write(int, int[], int, int)}.
	 */
	@Test
	public void testWrite() {
		int []arr = {1,2,1,2,0};
		int []test = new int[5];
		
		wordArray.write(5, test, 0, 5);
		
		for(int i = 0; i < 5; i ++) {
			assertEquals(arr[i], test[i]);
		}
		
	}

	/**
	 * Test method for {@link cn.ac.ios.automata.words.WordArray#getLetter(int)}.
	 */
	@Test
	public void testGetLetter() {
		for(int i = 0; i < wordArray.length(); i ++) {
			assertEquals(letters[i], wordArray.getLetter(i));
		}
	}

	/**
	 * Test method for {@link cn.ac.ios.automata.words.WordArray#getSubWord(int, int)}.
	 */
	@Test
	public void testGetSubWord() {
		int []arr = {1,2,1,2,0};
		
		Word word = wordArray.getSubWord(5, 5);
		
		for(int i = 0; i < word.length(); i ++) {
			assertEquals(arr[i], word.getLetter(i));
		}
	}

	/**
	 * Test method for {@link cn.ac.ios.automata.words.WordArray#getPrefix(int)}.
	 */
	@Test
	public void testGetPrefix() {
		int []arr = {0,0,0,1,1,1,2,1};
		
		Word word = wordArray.getPrefix(8);
		
		for(int i = 0; i < word.length(); i ++) {
			assertEquals(arr[i], word.getLetter(i));
		}
	}

	/**
	 * Test method for {@link cn.ac.ios.automata.words.WordArray#getSuffix(int)}.
	 */
	@Test
	public void testGetSuffix() {
		int []arr = {1,2,1,2,0,2,2};
		
		Word word = wordArray.getSuffix(5);
		
		for(int i = 0; i < word.length(); i ++) {
			assertEquals(arr[i], word.getLetter(i));
		}
	}

	/**
	 * Test method for {@link cn.ac.ios.automata.words.WordArray#append(int)}.
	 */
	@Test
	public void testAppend() {
		int [] arr = {0,0,0,1,1,1,2,1,2,0,2,2, 1}; //  aaabbbcbcacc
		
		assertEquals(2, wordEmpty.append(2).getFirstLetter());
		assertEquals(2, wordEmpty.append(2).getLastLetter());
		assertEquals(2, wordLetter.append(2).getLastLetter());
		Word word = wordArray.append(1);
		for(int i = 0; i < word.length(); i ++) {
			assertEquals(arr[i], word.getLetter(i));
		}
	}

	/**
	 * Test method for {@link cn.ac.ios.automata.words.WordArray#preappend(int)}.
	 */
	@Test
	public void testPreappend() {
		int [] arr = {1, 0,0,0,1,1,1,2,1,2,0,2,2}; //  aaabbbcbcacc
		
		assertEquals(2, wordEmpty.preappend(2).getFirstLetter());
		assertEquals(2, wordEmpty.preappend(2).getLastLetter());
		assertEquals(2, wordLetter.preappend(2).getFirstLetter());
		Word word = wordArray.preappend(1);
		for(int i = 0; i < word.length(); i ++) {
			assertEquals(arr[i], word.getLetter(i));
		}
	}

	/**
	 * Test method for {@link cn.ac.ios.automata.words.WordArray#isPrefixOf(cn.ac.ios.automata.words.Word)}.
	 */
	@Test
	public void testIsPrefixOf() {
		int [] arr = {1, 0,0,0,1,1,1,2,2}; //  aaabbbcbcacc
		
		assertEquals(true, wordEmpty.isPrefixOf(wordEmpty));
		assertEquals(true, wordEmpty.isPrefixOf(wordLetter));
		assertEquals(false, wordLetter.isPrefixOf(wordEmpty));

		Word word = contextWord.getArrayWord(arr);
		assertEquals(false, word.isPrefixOf(wordArray));
		for(int length = 0; length <= wordArray.length(); length ++) {
			Word prefix = wordArray.getPrefix(length);
			assertEquals(true, prefix.isPrefixOf(wordArray));
		}
	}

	/**
	 * Test method for {@link cn.ac.ios.automata.words.WordArray#isSuffixOf(cn.ac.ios.automata.words.Word)}.
	 */
	@Test
	public void testIsSuffixOf() {
		int [] arr = {0,1,1,1,2,2}; //  aaabbbcbcacc
		
		assertEquals(true, wordEmpty.isSuffixOf(wordEmpty));
		assertEquals(true, wordEmpty.isSuffixOf(wordLetter));
		assertEquals(false, wordLetter.isSuffixOf(wordEmpty));

		Word word = contextWord.getArrayWord(arr);
		assertEquals(false, word.isPrefixOf(wordArray));
		for(int length = 0; length <= wordArray.length(); length ++) {
			Word prefix = wordArray.getSuffix(length);
			assertEquals(true, prefix.isSuffixOf(wordArray));
		}
	}

	/**
	 * Test method for {@link cn.ac.ios.automata.words.WordArray#equals(cn.ac.ios.automata.words.Word)}.
	 */
	@Test
	public void testEquals() {		
		Word wordSuffix = wordLetter.getSuffix(1);
		Word wordPrefix = wordArray.getPrefix(1);
		assertEquals(true, wordEmpty.equals(wordEmpty));
		assertEquals(true, wordEmpty.equals(wordSuffix));
		assertEquals(true, wordLetter.equals(wordPrefix));
	}
}
