/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.ba;

import java.util.List;

import automata.FiniteAutomaton;
import cn.ac.ios.oracle.BuechiRunner;
import cn.ac.ios.oracle.Minimizer;
import cn.ac.ios.roll.sampler.BuechiSampler;
import cn.ac.ios.util.AutomatonPrinter;
import cn.ac.ios.util.Pair;

public class SampleTest {
	
	public static void main(String []args) {
		
		String file = "C:/Users/liyong/workspace/jalf/jalf/bugrecur.ba";
		
		FiniteAutomaton automaton = new FiniteAutomaton(file);
		automaton = Minimizer.minimizeBuechi(automaton, 12);
		AutomatonPrinter.print(automaton, System.out);
		Pair<List<String>, List<String>> word = BuechiSampler.sampleUniform(automaton);
//		
//		System.out.println(word.getLeft() + " : "+ word.getRight());
		int numA = 0, numAC = 0, numB = 0, numBC = 0;
		for(int n = 0; n < 100; n ++) {
			word = BuechiSampler.samplePath(automaton);
			System.out.println(word.getLeft() + " : "+ word.getRight());
			numA += word.getLeft().size() + word.getRight().size();
			numAC += word.getRight().size();
			if(! BuechiRunner.isAccepting(automaton, word.getLeft(), word.getRight())) {
				System.err.println("error");
			}
			word = BuechiSampler.sampleUniform(automaton);
			System.out.println(word.getLeft() + " : "+ word.getRight());
			numB += word.getLeft().size() + word.getRight().size();
			numBC += word.getRight().size();
			if(! BuechiRunner.isAccepting(automaton, word.getLeft(), word.getRight())) {
				System.err.println("error");
			}
		}
		
		System.out.println("average length: " + numA + ", " + numAC);
		System.out.println("average length: " + numB + ", " + numBC);

		
	}

}
