/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.oracle.teacher;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

import cn.ac.ios.options.Options;
import cn.ac.ios.oracle.BuechiRunner;
import automata.FiniteAutomaton;
import cn.ac.ios.automata.words.Alphabet;
import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.automata.words.Word;
import cn.ac.ios.query.Query;
import cn.ac.ios.query.QuerySimple;
import cn.ac.ios.roll.Statistics;
import cn.ac.ios.util.Timer;
import cn.ac.ios.value.ValueManager;
import cn.ac.ios.value.Type;
import cn.ac.ios.value.Value;
import oracle.EqResult;
import oracle.RabitOracle;

/**
 * Currently only for Buechi equivalence checking
 * */
public class TeacherRabit implements Teacher<FiniteAutomaton, EqResult, Boolean> {
	private final RabitOracle rabitOracle;
	private final WordManager contextWord;
	
	public TeacherRabit(WordManager contextWord, FiniteAutomaton targetAut) {
		assert targetAut != null && contextWord != null;
		this.contextWord = contextWord;
		this.rabitOracle = new RabitOracle(targetAut);
		if(Options.verbose) this.rabitOracle.setVerbose();
		// initialize alphabet
		ValueManager contextValue = contextWord.getContextValue();
		Type typeString = contextValue.newTypeLetter(String.class);
		Value valueLetter = typeString.newValue();
		Alphabet alphabet = contextWord.getAlphabet();
		if(Options.learnerLDollar) {
			valueLetter.set(WordManager.getStringDollar());
			alphabet.add(valueLetter.clone());
		}
		for(String letter : targetAut.alphabet) {
			valueLetter.set(letter);
			alphabet.add(valueLetter.clone());
		}
		alphabet.setImmutable();
		valueLetter.set("");
	    contextWord.setLetterSplitter(valueLetter);
	}
	
	@Override
	public Query<EqResult> answerEquivalenceQuery(FiniteAutomaton automaton) {
		
		System.out.println("Resloving equivalence check by RABIT...");
		PrintStream outOld = System.out;
		redirectRabitOut();
		Timer timer = new Timer();
		timer.start();
		EqResult result = rabitOracle.isEqualBuechi(automaton);
		timer.stop();
		Statistics.timeEquivalenceQuery += timer.getTimeElapsed();
		++ Statistics.numEquivalenceQuery;
		Statistics.timeLastEquivalenceQuery = timer.getTimeElapsed();
		System.setOut(outOld);
		
		Query<EqResult> query = null;
		if(result.isEqual) {
			query = new QuerySimple<>(contextWord.getEmptyWord(), contextWord.getEmptyWord());
			query.answerQuery(result);
		}else {

			Word prefix = contextWord.getWordFromString(rabitOracle.getPrefix());
			Word suffix = null;
			if(rabitOracle.getSuffix() != null) {
				suffix = contextWord.getWordFromString(rabitOracle.getSuffix());
			}else {
				suffix = contextWord.getEmptyWord();
			}
			query = new QuerySimple<>(prefix, suffix);
			query.answerQuery(result);
		}
		System.out.println("Done for equivalence check by RABIT...");
		if(Options.verbose) System.out.println("rabit counter example = " + query);
		return query;
	}

	@Override
	public Boolean answerMembershipQuery(Query<Boolean> query) {
		List<String> prefix = new ArrayList<>();
		List<String> suffix = new ArrayList<>();
        
		for(int i = 0; i < query.getPrefix().length(); i ++) {
			prefix.add(contextWord.letterToString(query.getPrefix().getLetter(i)));
		}
		for(int i = 0; i < query.getSuffix().length(); i ++) {
			suffix.add(contextWord.letterToString(query.getSuffix().getLetter(i)));
		}
		
        Timer timer = new Timer();
        timer.start();
        
		boolean result;
		
		if(suffix.isEmpty()) {
			result = false;
		}else {
			result = BuechiRunner.isAccepting(rabitOracle.getTarget(), prefix, suffix);
		}
		
		timer.stop();
		Statistics.timeMembershipQuery += timer.getTimeElapsed();
		++ Statistics.numMembershipQuery; 
		return result;
	}
	
	private void redirectRabitOut() {
		
		try {
			PrintStream out = new PrintStream(new FileOutputStream("rabitlog.txt"));
			System.setOut(out);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
