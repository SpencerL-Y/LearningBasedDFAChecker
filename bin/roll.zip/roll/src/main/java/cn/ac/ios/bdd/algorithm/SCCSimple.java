package cn.ac.ios.bdd.algorithm;

import cn.ac.ios.bdd.BDDManager;
import cn.ac.ios.bdd.graph.BuechiBDD;
import net.sf.javabdd.BDD;

// for buechi intersection
//TODO
public class SCCSimple {
	
	private final BDD presAndActions;
	private final BDD nextAndActions;
	private final BDD transitions;
    private final BDD nodes;
    private final BDD transitionsNoActions;
    private final BDD actionCube;
    private final BDDManager bdd;
    private final BDD leftBDD;
    private final BDD rightBDD;
    
	public SCCSimple(BuechiBDD buechi) {
		assert buechi != null;
		this.bdd = buechi.getBDDManager();
		this.nodes = buechi.getStateSpace();
		this.actionCube = buechi.getActionCube();
		this.presAndActions = buechi.getPreCube().and(buechi.getActionCube());
		this.nextAndActions = buechi.getNextCube().and(buechi.getActionCube());
		this.transitions = buechi.getTransition();
		this.transitionsNoActions = buechi.getTransition().exist(buechi.getActionCube());
		assert buechi.getAcceptance().size() == 2;
		this.leftBDD = buechi.getAcceptance().get(0);
		this.rightBDD = buechi.getAcceptance().get(1);
	}
	
	

}
