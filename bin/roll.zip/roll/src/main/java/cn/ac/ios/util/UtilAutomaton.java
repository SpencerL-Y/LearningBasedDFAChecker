/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.util;

import java.util.BitSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.Set;

import automata.FAState;
import automata.FiniteAutomaton;
import cn.ac.ios.automata.Acceptor;
import cn.ac.ios.automata.Automaton;
import cn.ac.ios.automata.words.Alphabet;
import cn.ac.ios.learner.Learner;
import cn.ac.ios.learner.buechi.ldollar.LearnerOmegaBuechi;
import cn.ac.ios.learner.fdfa.LearnerFDFA;
import cn.ac.ios.options.Options;
import dk.brics.automaton.State;
import dk.brics.automaton.Transition;
import gnu.trove.map.TIntObjectMap;
import gnu.trove.map.hash.TIntObjectHashMap;

public class UtilAutomaton {
	
	private static State getState(TIntObjectMap<State> map, int stateNr) {
		State state = map.get(stateNr);
		if(state == null) {
			state = new State();
			map.put(stateNr, state);
		}
		return state;
	}
	
	public static dk.brics.automaton.Automaton convertToDkAutomaton(Automaton aut) {
		TIntObjectMap<State> map = new TIntObjectHashMap<>();
		return convertToDkAutomaton(map, aut);
	}
	
	public static dk.brics.automaton.Automaton convertToDkAutomaton(TIntObjectMap<State> map, Automaton aut) {	
		dk.brics.automaton.Automaton dkAut = new dk.brics.automaton.Automaton();
		Alphabet alphabet = aut.getAlphabet();
		
		for(int stateNr = 0; stateNr < aut.getNumStates(); stateNr ++) {
			State state = getState(map, stateNr);
			// initial states
			if(aut.getInitialStates().get(stateNr)) {
				dkAut.setInitialState(state);
			}
			// final states
			if(aut.isAccepted(stateNr)) {
				state.setAccept(true);
			}

			for (int letter = 0; letter < alphabet.size(); letter ++) {
				BitSet succs = aut.getSuccessors(stateNr, letter);
				int succ =  succs.nextSetBit(0);
				State stateSucc = getState(map, succ);
				state.addTransition(new Transition(alphabet.get(letter).toString().charAt(0),
						stateSucc));
			}
		}
		
		dkAut.setDeterministic(true);
		// should not restore invariant, it may contain no final states
		//dkAut.restoreInvariant();
		//automaton.minimize();
		return dkAut;
	}
	
	private static FAState getFAState(FiniteAutomaton aut, Map<State, FAState> map, State state) {
		FAState faState = map.get(state);
		if(faState == null) {
			faState = aut.createState();
			map.put(state, faState);
		}
		return faState;
	}
	
	// convert dk automaton to a rabit FiniteAutomaton 
	public static FiniteAutomaton convertToRabitAutomaton(dk.brics.automaton.Automaton aut) {
		FiniteAutomaton rabitAut = new FiniteAutomaton();
		Map<State, FAState> map = new HashMap<>();	
		for(State state : aut.getStates()) {
			FAState faState = getFAState(rabitAut, map, state);
			
			for(Transition trans : state.getTransitions()) {
				State succ = trans.getDest();
				FAState faSucc = getFAState(rabitAut, map, succ);
				for(char letter = trans.getMin(); letter <= trans.getMax(); letter ++) {
					rabitAut.addTransition(faState, faSucc, letter + "");
				}
			}
			if(state.isAccept()) {
				rabitAut.F.add(faState);
			}
		}
		FAState init = map.get(aut.getInitialState());
		rabitAut.setInitialState(init);
		return rabitAut;
	}
	
	// Transfers a cn.ios.automaton into a dk.brics.automaton
	// with specific initial and final state.
	public static dk.brics.automaton.Automaton convertToDkAutomaton(Automaton aut, int init, int fin){
		dk.brics.automaton.Automaton dkAut = new dk.brics.automaton.Automaton();
		TIntObjectMap<State> map = new TIntObjectHashMap<>();
		Alphabet alphabet = aut.getAlphabet();
		Queue<Integer> queue = new LinkedList<>();
		State initState = getState(map, init);
		dkAut.setInitialState(initState);
		queue.add(init);
		BitSet visited = new BitSet();
		visited.set(init);
		while(! queue.isEmpty()) {
			int stateNr = queue.poll();
			State state = getState(map, stateNr);
			for (int letter = 0; letter < alphabet.size(); letter ++) {
				BitSet succs = aut.getSuccessors(stateNr, letter);
				int succ =  succs.nextSetBit(0);
				State stateSucc = getState(map, succ);
				state.addTransition(new Transition(alphabet.get(letter).toString().charAt(0),
						stateSucc));
				if(! visited.get(succ)) {
					queue.add(succ);
					visited.set(succ);
				}
			}
		}
		
		getState(map, fin).setAccept(true);
		dkAut.setDeterministic(true);
		dkAut.restoreInvariant();
		dkAut.minimize();
		return dkAut;
	}

	//Adds specific(not general) epsilon transition in an NFA.
	//A only has one accepting state, TODO flawed
	public static dk.brics.automaton.Automaton addEpsilon (dk.brics.automaton.Automaton A) {
		State epsilon = new State();
		epsilon.setAccept(true);
		Set<State> acc = A.getAcceptStates();
		//Only one accepted state.
		if(acc.size() > 1)  {
			System.err.println("multiple final states while add epsilon transitions");
			System.exit(-1);
		}
		
		State accept = acc.iterator().next();
		accept.setAccept(false);
		//Records transitions to be added to epsilon state.
		Set<Transition> transToAcc = new HashSet<Transition>();
		
		for (State s: A.getStates()) {
			for (Transition t: s.getTransitions()){
				if (t.getDest() == accept)
					transToAcc.add(new Transition(t.getMin(), t.getMax(), s));
			}
		}
		
		// first add transitions from epsilon state
		State ini = A.getInitialState();
		for (Transition t : ini.getTransitions())
			epsilon.addTransition(new Transition(t.getMin(), t.getMax(), t.getDest()));
		
		// add transition to epsilon
		for(Transition t: transToAcc)
			t.getDest().addTransition(new Transition(t.getMin(), t.getMax(), epsilon));
		
		return A;
	}

	public static FiniteAutomaton convertToRabitAut(Learner<? extends Acceptor, Boolean> learner) {
		// if it is FDFA based
		if(learner instanceof LearnerFDFA) {
			LearnerFDFA learnerFDFA = (LearnerFDFA)learner;
			
			return BuechiBuilder.build(learnerFDFA, Options.buechiBuildUnder);
		}else {
		//TODO L$ method
			LearnerOmegaBuechi learnerBuechi = (LearnerOmegaBuechi)learner;
			return UtilAutomaton.convertToRabitAutomaton(learnerBuechi.getBuechi());
		}
	}
	
	public static dk.brics.automaton.Automaton convertToDkAutomaton(FiniteAutomaton aut) {
		dk.brics.automaton.Automaton dkAut = new dk.brics.automaton.Automaton();
		TIntObjectMap<State> stateMap = new TIntObjectHashMap<>(); 
		
		for(FAState faState : aut.states) {
			State state = getState(stateMap, faState.id);
			Iterator<String> nextStrIt = faState.nextIt();
			while(nextStrIt.hasNext()) {
				String label = nextStrIt.next();
				char dkLabel = label.charAt(0);
				for(FAState nextFaState : faState.getNext(label)) {
					State nextState = getState(stateMap, nextFaState.id);
					state.addTransition(new Transition(dkLabel, nextState));
				}
			}
		}
		
		for(FAState faState : aut.F) {
			State state = stateMap.get(faState.id);
			state.setAccept(true);
		}
		
		State initState = stateMap.get(aut.getInitialState().id);
		dkAut.setInitialState(initState);
		
		return dkAut;
	}
}
