/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.roll.translator;

import java.util.ArrayList;
import java.util.List;

import automata.FiniteAutomaton;
import cn.ac.ios.automata.Acceptor;
import cn.ac.ios.automata.Automaton;
import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.automata.words.Word;
import cn.ac.ios.learner.Learner;
import cn.ac.ios.learner.fdfa.LearnerFDFA;
import cn.ac.ios.options.Options;
import cn.ac.ios.oracle.BuechiRunner;
import cn.ac.ios.query.Query;
import cn.ac.ios.query.QuerySimple;
import cn.ac.ios.roll.Statistics;
import cn.ac.ios.util.DollarAutomatonBuilder;
import cn.ac.ios.util.Timer;
import cn.ac.ios.util.UtilAutomaton;
import oracle.EqResult;

public abstract class TranslatorFDFA implements Translator {
	
	protected LearnerFDFA learnerFDFA;
	protected Query<EqResult> ceQuery;
	protected dk.brics.automaton.Automaton autOmegaUV;
	protected WordManager contextWord ;
	protected boolean called;
	
	public TranslatorFDFA(Learner<? extends Acceptor, Boolean> learner) {
		assert learner != null ;
		this.learnerFDFA = (LearnerFDFA)learner;
	}
	
	// initialize the translator for query
	public void setQuery(Query<EqResult> query) {
		this.ceQuery = query;
		this.called = false;
		// get deterministic automaton for (u,v)
		Timer timer = new Timer();
		timer.start();
		Word prefix = query.getPrefix();
		Word suffix = query.getSuffix();
		assert prefix != null && suffix != null;
		contextWord = prefix.getContextWord();
		autOmegaUV = DollarAutomatonBuilder.buildDollarAutomaton(prefix, suffix);
		autOmegaUV.setDeterministic(true);
		timer.stop();
		Statistics.timeTranslator += timer.getTimeElapsed();
	}
	
	protected String getPositiveCounterExample(LearnerFDFA learnerFDFA
			, dk.brics.automaton.Automaton autDollar) {
		
		dk.brics.automaton.Automaton dollarFDFAComplement = DollarAutomatonBuilder
				.buildDollarFDFAComplement(learnerFDFA);
		dk.brics.automaton.Automaton autMinus = autDollar.intersection(dollarFDFAComplement);
		assert autMinus != null;
		String ceStr = autMinus.getShortestExample(true);
		if(Options.verbose) System.out.println("in target: " + ceStr);
		return ceStr;
		
	}
	
	protected Query<Boolean> getQuery(String counterexample, boolean result) {
		Timer timer = new Timer();
		timer.start();
		if(Options.verbose) System.out.println("final counterexample " + counterexample);
		int dollarNr = counterexample.indexOf(WordManager.getStringDollar().charAt(0)); //
		Word prefix = getContextWord().getWordFromString(counterexample.substring(0, dollarNr));
		Word period = getContextWord().getWordFromString(counterexample.substring(dollarNr + 1));
		Query<Boolean> query = new QuerySimple<>(prefix, period);
		query.answerQuery(result);
		
		timer.stop();
		Statistics.timeTranslator += timer.getTimeElapsed();
		return query;
	}
	
	public WordManager getContextWord() {
		return contextWord;
	}
	
	@Override
	public boolean canRefine() {
		if(! called) {
			called = true;
			return true;
		}
		// else it must be using optimization treating eq test as the last resort
		Timer timer = new Timer();
		timer.start();
		
		// check whether we can still use current counter example 
		assert ceQuery != null && autOmegaUV != null;
		// construct lower/upper Buechi automaton

		FiniteAutomaton buechi = UtilAutomaton.convertToRabitAut(learnerFDFA);
		List<String> prefix = new ArrayList<String>();
		List<String> suffix = new ArrayList<String>();
		
		for(int letterNr = 0; letterNr < ceQuery.getPrefix().length(); letterNr ++) {
			prefix.add(contextWord.letterToString(ceQuery.getPrefix().getLetter(letterNr)));
		}
		
		for(int letterNr = 0; letterNr < ceQuery.getSuffix().length(); letterNr ++) {
			suffix.add(contextWord.letterToString(ceQuery.getSuffix().getLetter(letterNr)));
		}
		
		boolean accepted = BuechiRunner.isAccepting(buechi, prefix, suffix);

		// (u, v) is in target, not accepted then needs refine again
		boolean result ;
		if (ceQuery.getQueryAnswer().isCeInTarget){
			result = ! accepted;
		}//else
		else {
			result = accepted;
		}
		
		
		timer.stop();
		Statistics.timeTranslator += timer.getTimeElapsed();
		
		return result;
		
	}
	/* another alternative approach for canRefine is to construct the corresponding
	 * Buechi automaton and then check whether (u, v) is accepted accordingly.
	 * This method may need less memory */


}
