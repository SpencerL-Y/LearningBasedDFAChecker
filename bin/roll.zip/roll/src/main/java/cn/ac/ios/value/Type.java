/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.value;
// only supports Boolean, String
//, Object, Double, Integer

public interface Type {
	
	ValueManager getContext();
	
	Type clone();
	
    void setKnownValue(Value object);

    Value getKnownValue();

	default Value newValue() {
		if(getKnownValue() != null) {
			return getKnownValue().clone();
		}else {
			assert false;
			return null;
		}
	}
	
	default Value newValue(int value) {
		Value result = newValue();
		result.set(value);
		return result;
	}
	
	default Value newValue(boolean b) {
		Value result = newValue();
		result.set(b);
		return result;
	}
	
	default Value newValue(String s) {
		Value result = newValue();
		result.set(s);
		return result;
	}
	
	default Value newValue(Object object) {
		assert object != null;
		Value result = newValue();
		result.set(object);
		return result;
	}
	
	default Value newValue(double value) {
		Value result = newValue();
		result.set(value);
		return result;
	}
	
	default Value newValue(Value value) {
        Value result = newValue();
        result.set(value);
        return result;
	}
	
	// tests
	default boolean isBoolean() {
		return false;
	}
	default boolean isInteger() {
		return false;
	}
	default boolean isDouble() {
		return false;
	}
	default boolean isObject() {
		return false;
	}
	default boolean isFraction() {
		return false;
	}
	//gets 
	default Value getZero() {
        assert false;
        return null;
	}
	default Value getOne() {
        assert false;
        return null;
	}
	
    default Value getFalse() {
        assert false;
        return null;
    }

    default Value getTrue() {
        assert false;
        return null;
    }
	
    default Class<?> getUsedClass() {
    	assert false;
    	return null;
    }
    
}
