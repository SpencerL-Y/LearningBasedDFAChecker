/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.learner.fdfa.tree;

import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.automata.words.Word;
import cn.ac.ios.learner.fdfa.LearnerLeading;
import cn.ac.ios.query.MembershipOracle;
import cn.ac.ios.table.ExprValue;

public class LearnerProgressTreePeriodic extends LearnerProgressTree {
	
	public LearnerProgressTreePeriodic(WordManager contextWord
			, MembershipOracle<Boolean> membershipOracle
			, Word label) {
		super(contextWord, membershipOracle, label);
	}

	// do not need learnerLeading
	@Override
	public void setLearnerLeading(LearnerLeading learnerLeading) {
	}
	
	@Override
	protected CeAnalyzer getCeAnalyzerInstance(ExprValue exprValue) {
		return new CeAnalyzerTreePeriodic(exprValue);
	}
	
	private class CeAnalyzerTreePeriodic extends CeAnalyzer {

		public CeAnalyzerTreePeriodic(ExprValue ce) {
			super(ce);
		}

		/** the progress automaton does not depend on the leading automaton */
		@Override
		public void analyze() {
			this.leafBranch = getHashableValueBoolean(isCEAccepting);
			this.nodePrevBranch = getHashableValueBoolean(!isCEAccepting);
			// only has one leaf
			if(tree.getRoot().isLeaf()) {
				this.wordExpr = getExprValueWord(contextWord.getEmptyWord());
				this.nodePrev = tree.getRoot();
				this.wordLeaf = getExprValueWord(exprValue.get());
				return ;
			}
			
			Word wordCE = this.exprValue.get();
			// get the initial state from automaton
		    int letterNr = 0, stateCurr = -1, statePrev = getInitState();
			// starting state is lambda
			for(; letterNr < wordCE.length(); letterNr ++) {
				stateCurr = computeNextState(statePrev, wordCE.getLetter(letterNr));
				Word period = states.get(stateCurr).label;   // S(j)
				period = period.concat(wordCE.getSuffix(letterNr + 1)); // S(j) y[j+1...n]
				boolean resultCurr = processMembershipQuery(label, period);; // u (Sj y[j+1..n])
				if(isCEAccepting != resultCurr) {
					break;
				}
				statePrev = stateCurr; // record S(j)
			}
			
			Word wordPrev = states.get(statePrev).label;         // S(j-1)
			this.wordExpr = getExprValueWord( wordCE.getSuffix(letterNr + 1));  // y[j+1..n]
			this.wordLeaf = getExprValueWord(wordPrev.append(wordCE.getLetter(letterNr))); // S(j-1)y[j]
			this.nodePrev = states.get(stateCurr).node;          // S(j)
		}
		 
	}

}
