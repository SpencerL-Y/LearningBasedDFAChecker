/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.learner.buechi.ldollar;
import java.util.BitSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Set;

import cn.ac.ios.automata.*;
import cn.ac.ios.automata.words.Alphabet;
import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.automata.words.Word;
import cn.ac.ios.options.Options;
import dk.brics.automaton.BasicAutomata;
import dk.brics.automaton.BasicOperations;
import dk.brics.automaton.State;
import dk.brics.automaton.Transition;

public class LDollartoBuchi {
	
	private HashMap<Integer, State> map;			//Records the Integer-State map.
	private HashMap<State, Integer> rmap; 			//Records the State-Integer map.
	private final Automaton LDollar;
	private final dk.brics.automaton.Automaton dkLDollar;
	private BitSet accepted = new BitSet();
	private final WordManager contextWord;
	public LDollartoBuchi (Automaton a, WordManager c){
		LDollar = a;
		contextWord = c;
		dkLDollar = conv();
	}
	
	
	// Transfers a cn.ios.automaton into a dk.brics.automaton with specific initial and
	// final state.
	public dk.brics.automaton.Automaton conv(int ini, int fin){
		dk.brics.automaton.Automaton automaton = new dk.brics.automaton.Automaton();
		HashMap<Integer, State> newMap = new HashMap<Integer, State>();
		Iterator<Integer> it = map.keySet().iterator();
		while(it.hasNext()){
			int key = it.next();
			newMap.put(key, new State());
		}
		it = map.keySet().iterator();
		while(it.hasNext()){
			int key = it.next();	
			State s = map.get(key);
			State newState = newMap.get(key);
			for(Transition t: s.getTransitions()){
				int number = rmap.get(t.getDest());
				newState.addTransition(new Transition(t.getMin(), t.getMax(), newMap.get(number)));
			}
			newMap.put(key, newState);
		}
		automaton.setInitialState(newMap.get(ini));
		newMap.get(fin).setAccept(true);
		automaton.setDeterministic(true);
		automaton.restoreInvariant();
		automaton.minimize();
		return automaton;
	}
	
	// Transfers a cn.ios.automaton into a dk.brics.automaton.
	public dk.brics.automaton.Automaton conv(){
		dk.brics.automaton.Automaton automaton = new dk.brics.automaton.Automaton();
		Alphabet alphabet = LDollar.getAlphabet();
		Queue<Integer> queue = new LinkedList<>();
		int ini =LDollar.getInitialStates().nextSetBit(0);
		queue.add(ini);
		BitSet visited = new BitSet(LDollar.getNumStates());
		State currState = new State();
		map = new HashMap<Integer, State>();
		rmap = new HashMap<State, Integer>();
		map.put(ini, currState);
		rmap.put(currState, ini);
		automaton.setInitialState(currState);
		visited.set(ini);
		while(!queue.isEmpty()){
			int state = queue.poll();
			currState = map.get(state);
			for (int letter = 0; letter < alphabet.size(); letter ++){
				BitSet succs = LDollar.getSuccessors(state, letter);
				//DFA
				int succ = succs.nextSetBit(0);
				if (! visited.get(succ)){
					visited.set(succ);
					queue.add(succ);
					State s = new State();
					map.put(succ, s);
					rmap.put(s, succ);
					}
				currState.addTransition(new Transition(alphabet.get(letter).toString().charAt(0),
						map.get(succ)));
			}
			//sets accepted state
			if(LDollar.isAccepted(state)) {
				currState.setAccept(true);
				accepted.set(state);
			}
		}
		automaton.setDeterministic(true);
		automaton.restoreInvariant();
		//automaton.minimize();
		return automaton;
	}
	
	//Checks if LDollar is contained in A*$A+. Assumes the first letter of the 
	//alphabet is $('\u0024').
	public boolean checkInclusion (){
		dk.brics.automaton.Automaton a = new dk.brics.automaton.Automaton();
		State s1 = new State();
		State s2 = new State();
		State s3 = new State();	
		a.setInitialState(s1);
		s1.addTransition(new Transition(Character.MIN_VALUE, '\u0023',s1));
		s1.addTransition(new Transition('\u0024',s2));
		s1.addTransition(new Transition('\u0025',Character.MAX_VALUE,s1));
		s2.addTransition(new Transition(Character.MIN_VALUE, '\u0023',s3));
		s2.addTransition(new Transition('\u0025',Character.MAX_VALUE,s3));			
		s3.addTransition(new Transition(Character.MIN_VALUE, '\u0023',s3));
		s3.addTransition(new Transition('\u0025',Character.MAX_VALUE,s3));
		s3.setAccept(true);
		a.setDeterministic(true);
		a.restoreInvariant();
		return dkLDollar.subsetOf(a);		
	}
	
	//Constructs the Buchi automaton
	public dk.brics.automaton.Automaton start (){
		Set<State> states = dkLDollar.getStates();
		HashMap<State, State> spairs = new HashMap<State, State>();
		LinkedList<State> worklist = new LinkedList<State>();
		for (State s: states)
			for (Transition t: s.getTransitions())
				if (t.getMin() <= '$' && t.getMax() >= '$')
				{
					spairs.put(s, t.getDest());
					worklist.add(s);
					break;
				}
		//Reset all the accepting states.
		for (int state = accepted.nextSetBit(0); state >= 0; state = accepted.nextSetBit(state + 1))
			map.get(state).setAccept(false);	
		dk.brics.automaton.Automaton result = new dk.brics.automaton.Automaton();
		while (!worklist.isEmpty()){
			State q = worklist.poll();
			//An automaton with original initial state and State q as final state.
			dk.brics.automaton.Automaton Mq = conv(LDollar.getInitialStates().nextSetBit(0),
						rmap.get(q));
			//System.out.println("Mq:" + Mq.toString());
			//An automaton with State q as both initial and final state.
			dk.brics.automaton.Automaton N1 = conv(rmap.get(q), rmap.get(q));
			//System.out.println("N1:" + N1.toString());
			for (int fin = accepted.nextSetBit(0); fin >= 0 ; fin = accepted.nextSetBit(fin + 1)){
				//An automaton with State q`$ as initial state and fin as final state.
				dk.brics.automaton.Automaton N2 = conv (rmap.get(spairs.get(q)), fin);
				//System.out.println("N2:" + N2.toString());
				//An automaton with State q`$ as initial state and fin as final state.
				dk.brics.automaton.Automaton N3 = conv (fin, fin);
				//System.out.println("N3:" + N3.toString());
				dk.brics.automaton.Automaton Nqqf = BasicOperations.intersection(N2, N3);
				//System.out.println("N2.N3:" + Nqqf.toString());
				Nqqf = BasicOperations.intersection(N1, Nqqf);
				Nqqf.minimize();
				//Convert Nq,qf to the automaton that accepts the language of Nq,qf^\omega.
				Nqqf = addEpsilon(Nqqf);
				//System.out.println("Nqqf:" + Nqqf.toString());
				//The correctness should be proved.
				result = BasicOperations.union(result, BasicOperations.concatenate(Mq, Nqqf));
				//System.out.println("result:" + result.toString());
				}
		}
		result.minimize();
		return result;
	}		
	
	public String dktoString(){
			return dkLDollar.toDot();
		}
	
	public String toString(){
		return LDollar.toString();
	}
	
	//Adds specific(not general) epsilon transition in an NFA.
	public dk.brics.automaton.Automaton addEpsilon (dk.brics.automaton.Automaton A){
		State epsilon = new State();
		epsilon.setAccept(true);
		Set<State> acc = A.getAcceptStates();
		//Only one accepted state.
		if (acc.size() > 1) 
			assert false;
		//Records transitions to be added to epsilon state.
		Set<Transition> trans = new HashSet<Transition>();
		for (State accept: acc){
			accept.setAccept(false);
			for (State s: A.getStates())
				for (Transition t: s.getTransitions()){
					if (t.getDest() == accept)
						trans.add(new Transition(t.getMin(), t.getMax(),s));
				}
		}
		// First adds transitions from epsilon state.
		State ini = A.getInitialState();
		for (Transition t : ini.getTransitions())
			epsilon.addTransition(new Transition(t.getMin(), t.getMax(), t.getDest()));
		
		// Then adds transitions to epsilon state.
		for(Transition t: trans)
			t.getDest().addTransition(new Transition(t.getMin(), t.getMax(), epsilon));

		return A;
	}
	
	// Finds a counterexample to refine the hypothesis. 
	public Word findCounterexample (Word prefix, Word suffix, boolean answer){
		// Finds the smallest period of suffix.
		for (int i = 1; i <= suffix.length()/2; i++){
			if (suffix.length() % i == 0){
				Word rep = suffix.getPrefix(i);
				for (int j = 1; j < suffix.length() / i; j++)
					rep = rep.concat(rep);
				if (rep.equals(suffix)) {
					suffix = suffix.getPrefix(i);
					break;
				}
			}
		}
		
		// Shifts prefix to the smallest one.
		while (prefix.getLastLetter() == suffix.getLastLetter()){
			prefix = prefix.getPrefix(prefix.length()-1);
			suffix = suffix.getSuffix(suffix.length()-1).concat(suffix.getPrefix(suffix.length()-1));
		}
		
		if(Options.verbose) System.out.println(prefix.toStringWithAlphabet() + ',' + suffix.toStringWithAlphabet());
		dk.brics.automaton.Automaton result = new dk.brics.automaton.Automaton();
		for (int i = 0; i < suffix.length(); i++){
			dk.brics.automaton.Automaton suf, pre = new dk.brics.automaton.Automaton();
			suf = BasicAutomata.makeString(suffix.toStringWithAlphabet());
			if (! prefix.isEmpty()){
			pre = BasicAutomata.makeString(prefix.toStringWithAlphabet());
			pre = pre.concatenate(suf.repeat());}
			else
				pre = suf.repeat();
			suf = suf.repeat(1);
			Set<State> acc = pre.getAcceptStates();
			if ( acc.size() > 1) assert false;
			for(State s : acc){
				State ini = suf.getInitialState();
				s.setAccept(false);
				s.addTransition(new Transition('$', ini));
			}
			pre.restoreInvariant();
			result = result.union(pre);
			prefix = prefix.append(suffix.getFirstLetter());
			suffix = suffix.getSubWord(1, suffix.length()-1).append(suffix.getFirstLetter());	
		}
		result.minimize();
		if(Options.verbose) System.out.println(result.toString());
		String counterexample = null;
		if (answer){
			counterexample = result.minus(dkLDollar).getShortestExample(true);
		}
		else{
			counterexample = dkLDollar.intersection(result).getShortestExample(true);
		}
		if(Options.verbose) System.out.println(counterexample);
		return contextWord.getWordFromString(counterexample);
	}
}
