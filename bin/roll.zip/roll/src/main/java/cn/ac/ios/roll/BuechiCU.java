/* Written by Yong Li                                                  */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.roll;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;

import automata.FAState;
import automata.FiniteAutomaton;
import cn.ac.ios.automata.Automaton;
import cn.ac.ios.automata.words.Alphabet;
import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.automata.parser.hoa.HanoiParser;
import cn.ac.ios.learner.Learner;
import cn.ac.ios.learner.buechi.ldollar.LearnerOmegaBuechi;
import cn.ac.ios.learner.dfa.table.LearnerDFATable;
import cn.ac.ios.learner.dfa.tree.LearnerDFATree;
import cn.ac.ios.learner.fdfa.LearnerFDFA;
import cn.ac.ios.learner.fdfa.table.LearnerFDFATablePeriodic;
import cn.ac.ios.learner.fdfa.table.LearnerFDFATableRecurrent;
import cn.ac.ios.learner.fdfa.table.LearnerFDFATableSyntactic;
import cn.ac.ios.learner.fdfa.tree.LearnerFDFATreePeriodic;
import cn.ac.ios.learner.fdfa.tree.LearnerFDFATreeRecurrent;
import cn.ac.ios.learner.fdfa.tree.LearnerFDFATreeSyntactic;
import cn.ac.ios.learner.lstar.LearnerLStar;
import cn.ac.ios.options.Options;
import cn.ac.ios.oracle.EquivalenceOracleImpl;
import cn.ac.ios.oracle.MembershipOracleImpl;
import cn.ac.ios.oracle.Minimizer;
import cn.ac.ios.oracle.teacher.Teacher;
import cn.ac.ios.oracle.teacher.TeacherBuechiC;
import cn.ac.ios.oracle.teacher.TeacherBuechiCU;
import cn.ac.ios.oracle.teacher.TeacherDK;
import cn.ac.ios.oracle.teacher.TeacherRabit;
import cn.ac.ios.oracle.teacher.TeacherSample;
import cn.ac.ios.query.EquivalenceOracle;
import cn.ac.ios.query.MembershipOracle;
import cn.ac.ios.query.Query;
import cn.ac.ios.roll.Statistics;
import cn.ac.ios.roll.sampler.FASampler;
import cn.ac.ios.roll.test.AutomatonGenerator;
import cn.ac.ios.roll.translator.Translator;
import cn.ac.ios.roll.translator.TranslatorBuechi;
import cn.ac.ios.roll.translator.TranslatorFDFAUnder;
import cn.ac.ios.roll.translator.TranslatorFDFAOver;
import cn.ac.ios.roll.translator.TranslatorSimple;
import cn.ac.ios.util.AutomatonPrinter;
import cn.ac.ios.util.BuechiBuilder;
import cn.ac.ios.util.InputHelper;
import cn.ac.ios.util.Timer;
import cn.ac.ios.util.UtilAutomaton;
import cn.ac.ios.value.ValueManager;
import dk.brics.automaton.State;
import cn.ac.ios.value.Type;
import cn.ac.ios.value.Value;
import oracle.EqResult;
import oracle.IntersectionCheck;
import oracle.RabitOracle;


/**
 * This is the main class for BuechiC, we have two mode
 * 
 * 1. interactive mode, you can teach BuechiC by yourself
 * 2. automatic automata learning from teacher RABIT tool
 * http://www.languageinclusion.org/doku.php?id=tools
 *
 * TODO add automatic learning for regular language
 */
public class BuechiCU 
{
	private static boolean isOmegaLearning = false;
	private static double ep;
	private static double del;
	private static int numST;
	private static int numTests;
	private static String outputFile = null;
		
    public static void main(String[] args)
    {
//    	try {
//			Thread.sleep(1000*60);
//		} catch (InterruptedException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
    	// parse input arguments
    	for(int i = 0; i < args.length; i ++) {
    		
    		if(args[i].compareTo("-h")==0) {
    			helper();
    		}
    	}
    	
    	if(args.length < 2) {
    		helper();
    	}

    	String autfile = null;
    	// for learning;
    	for(int i = 0; i < args.length; i ++) {
			
			if(args[i].compareTo("-sameq") == 0) {
				Options.teacherSampling = true;
    			Options.modeInteractive = false;
    			Options.modeAutomatic = true;
    			ep = Double.parseDouble(args[i+1]);
    			del = Double.parseDouble(args[i+2]);
    			i += 2;
    			continue;
			}
			
			if(args[i].compareTo("-v")==0){
				Options.verbose=true;
				continue;
			}
			
			if(args[i].compareTo("-out")==0){
				outputFile = args[i+1];
				i += 1;
				continue;
			}
			
			if(args[i].compareTo("-table") == 0) {
    			Options.learnerTree = false;
    			Options.learnerTable = true;
    			continue;
			}
			if(args[i].compareTo("-tree") == 0) {
    			Options.learnerTree = true;
    			Options.learnerTable = false;
    			continue;
			}

			if(args[i].compareTo("-syntactic") == 0) {
				Options.learnerLStar = false;
				Options.learnerMultiplicity = false;
				Options.learnerNFA = false;
				Options.learnerDFA = false;
				Options.learnerLDollar = false;
				Options.learnerPeriodic = false;
				Options.learnerRecurrent = false;
				Options.learnerSyntactic = true;
				isOmegaLearning = true;
				continue;
			}
			if(args[i].compareTo("-recurrent") == 0) {
				Options.learnerLStar = false;
				Options.learnerMultiplicity = false;
				Options.learnerDFA = false;
				Options.learnerNFA = false;
				Options.learnerLDollar = false;
				Options.learnerPeriodic = false;
				Options.learnerRecurrent = true;
				Options.learnerSyntactic = false;
				isOmegaLearning = true;
				continue;
			}
			if(args[i].compareTo("-periodic") == 0) {
				Options.learnerLStar = false;
				Options.learnerMultiplicity = false;
				Options.learnerDFA = false;
				Options.learnerNFA = false;
				Options.learnerLDollar = false;
				Options.learnerPeriodic = true;
				Options.learnerRecurrent = false;
				Options.learnerSyntactic = false;
				isOmegaLearning = true;
				continue;
			}

			if(args[i].compareTo("-sim") == 0) {
				Options.simulationNFA = true;
				continue;
			}
			
			if(args[i].compareTo("-min") == 0) {
				Options.minimizationBuechi = true;
				continue;
			}
			
			if(args[i].compareTo("-lazyeq") == 0) {
				Options.lazyEqCheck = true;
				continue;
			}

			
			if(args[i].compareTo("-samfdfa") == 0) {
				Options.sampleFdfa = true;
				continue;
			}
			
			if(args[i].compareTo("-ldba") == 0) {
				Options.outLDBA = true;
				continue;
			}
			
			if(args[i].endsWith(".ba")) {
				autfile = args[i];
				continue;
			}
			
			if(args[i].endsWith(".hoa")) {
				autfile = args[i];
				continue;
			}
			
			if(args[i].compareTo("-t") == 0) {
				Options.modeTest = true;
				numTests = Integer.parseInt(args[i+1]);
				numST = Integer.parseInt(args[i + 2]);
				i += 2;
				continue;
			}
    	}
    	
    	// check whether we need to output ldba
    	if(Options.outLDBA) {
    		if(! Options.buechiBuildUnder) {
    			System.out.println("Buechi construction is not under construction. No LDBA output.");
    			Options.outLDBA = false;
    		}
    	}
    	
    	Statistics.reset();

		if(Options.modeTest) { // do 20 tests?
			int num = 0;
			for(int n = 0; n < numTests; n ++) {
				FiniteAutomaton aut = AutomatonGenerator.getRandomAutomaton(numST, 3);
				
				try{
					learnInputAutomaton(aut);
					System.out.println("target: " );
					AutomatonPrinter.print(aut, System.out);
					System.out.println("complementation: " );
					AutomatonPrinter.print(Statistics.hypothesis, System.out);
					if(validate(Statistics.hypothesis, aut)) {
						++ num;
					}
				}catch (Exception e)
				{
					e.printStackTrace();
					aut.saveAutomaton("bug.ba");
					System.exit(-1);
				}
				aut.saveAutomaton("example.ba");
				System.out.println("Done for case " + (n + 1));
			}
			System.out.println(num + " out of " + numTests + " cases are correct");
		}else {
    		// performance evaluation process
    		FiniteAutomaton targetAut = loadAutomaton(autfile);
    		Statistics.target = targetAut;
    		Timer timer = new Timer();
    		timer.start();
    		try{
    			learnInputAutomaton(targetAut);
    		}catch(Exception e) {
    			e.printStackTrace();
    		}
    		timer.stop();
    		Statistics.timeTotal = timer.getTimeElapsed();
    		
    		System.out.println("target automaton: ");
    		parser.printHOA(targetAut, System.out);
//    		parser.print(targetAut, System.out);
    		System.out.println("\n");
    		System.out.println("final automaton learned: ");    		
    		if(outputFile == null) parser.printHOA(Statistics.hypothesis, System.out);
    		else {
    			try {
					parser.printHOA(Statistics.hypothesis, new FileOutputStream(new File(outputFile)));
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    		}
//    		parser.print(Statistics.hypothesis, System.out);
//    		parser.printHOA1(Statistics.hypothesis, System.out);
    		//validate(Statistics.hypothesis, Statistics.targetAut);
    		System.out.println("\n\n");
    		Statistics.print();
    		parser.close();
    		
//    		validate(targetAut, Statistics.hypothesis);
//    		IntersectionCheck checker = new IntersectionCheck(targetAut, Statistics.hypothesis);
//			System.out.println("intersection: " + checker.checkEmptiness());
//			parser.print1(Statistics.hypothesis, System.out);
//			parser.print1(targetAut, System.out);
    	}
    	
    }
    
    
    private static HanoiParser parser = null;
    
    private static FiniteAutomaton loadAutomaton(String autfile) {
    	if(autfile.endsWith(".ba")) {
    		return new FiniteAutomaton(autfile);
    	}else {
    		parser = new HanoiParser(autfile);
    		return parser.getAutomaton();
    	}
    }
    
    private static void learnInputAutomaton(FiniteAutomaton aut) {
		ValueManager contextValue = new ValueManager();
		WordManager contextWord = new WordManager(contextValue);
		TeacherBuechiCU teacher = new TeacherBuechiCU(contextWord, aut);
		
		MembershipOracle<Boolean> membershipOracle = teacher;
		LearnerFDFA learner = pickOneLearner(contextWord, membershipOracle);
		doAutomaticMode(teacher, learner);
		teacher.print();
    }

	private static LearnerFDFA pickOneLearner(WordManager contextWord,
    		MembershipOracle<Boolean> membershipOracle) {
    	
    	if(Options.learnerTable) {
    		if(Options.learnerRecurrent) return new LearnerFDFATableRecurrent(contextWord, membershipOracle);
    		if(Options.learnerSyntactic) return new LearnerFDFATableSyntactic(contextWord, membershipOracle);
    		return new LearnerFDFATablePeriodic(contextWord, membershipOracle);

    	}else {
    		
    		if(Options.learnerRecurrent) return new LearnerFDFATreeRecurrent(contextWord, membershipOracle);
    		if(Options.learnerSyntactic) return new LearnerFDFATreeSyntactic(contextWord, membershipOracle);
    		return new LearnerFDFATreePeriodic(contextWord, membershipOracle);
    	}
    }
    
    public static void helper() {
		System.out.println(
				"BuechiC v1 (Buechi Complementation base on Learning)");
		System.out.println(
				"Usage: java -jar BuechiC.jar [aut.ba, aut.hoa] [options]");

		System.out.println("             or: java -jar ROLL.jar aut.ba -table -periodic");
		System.out.println("             or: java -jar ROLL.jar aut.hoa -table -periodic");
		System.out.println("             or: java -jar ROLL.jar -t 3 3 -table -periodic");
		System.out.println("\nOptions:");
		System.out.println("-h: Show this page.");
		System.out.println("-v: Verbose mode.");
		System.out.println("-out filename: Output learned automaton in filename.");
		System.out.println(
				"-t k n: Test BuechiC with k randomly generated Buechi automata of n states.");
		System.out.println(
				"-tree: Use tree-based data structure in the algorithm (Default).");
		System.out.println(
				"-table: Use table-based data structure in the algorithm.");
		System.out.println(
				"-periodic: Use periodic FDFA to learn Omega regular language.");
		System.out.println(
				"-syntactic: Use syntactic FDFA to learn Omega regular language.");
		System.out.println(
				"-recurrent: Use recurrent FDFA to learn Omega regular language.");
//		System.out.println(
//				"-samfdfa: Sampling the FDFA before equivalence check. (Not yet supported)");
		System.out.println(
				"-sim: Use Similation provided by RABIT to reduce automata before intersection of DFAs.");
		System.out.println(
				"-min: Use Minimization provided by RABIT to reduce Buechi automata before equivalence check.");
		System.out.println(
				"-lazyeq: Equivalence check as the last resort. ");
		System.out.println(
				"-ldba: Output the final Buechi as Limit Deterministic Buechi Automaton (with -under). ");
		System.exit(0);
    }
    
    // TODO make full use of counterexample that teacher returned
    private static void doAutomaticMode(Teacher<LearnerFDFA, EqResult, Boolean> teacher
    		, LearnerFDFA learner) {
		System.out.println("Start learning...");
		Timer timer = new Timer();
		timer.start();
		learner.startLearning();
		timer.stop();
		Statistics.timeLearner += timer.getTimeElapsed();
		boolean result = false;
		while(! result ) {
			if(Options.verbose) System.out.println("learner output: " + learner.toString());
			
			Query<EqResult> query = teacher.answerEquivalenceQuery(learner);
			// get out of the loop
			if(query.getQueryAnswer().isEqual == true) {
				Statistics.setLearnerFDFA(learner);
//				if(outputFile != null) Statistics.hypothesis.saveAutomaton(outputFile);
				break;
			}
			
			// lazy equivalence check is implemented here
			Translator translator = new TranslatorFDFAUnder(learner);
			translator.setQuery(query);
			while(translator.canRefine()) {
				Query<Boolean> ceQuery = translator.translate();
				timer.start();
				learner.refineHypothesis(ceQuery);
				timer.stop();
				Statistics.timeLearner += timer.getTimeElapsed();
				if(Options.verbose) System.out.println("learner output: " + learner.toString());
				// if do not set lazy eq check or it is learnerBuechi
				if(! Options.lazyEqCheck) break;
			}

		}
		
		if(Options.outLDBA && (learner instanceof LearnerFDFA)) {
			Statistics.ldba = BuechiBuilder.buildLDBA((LearnerFDFA)learner);
		}
		
		System.out.println("Learning completed...");
    }
    
    private static boolean validate(FiniteAutomaton a, FiniteAutomaton b) {
    	FiniteAutomaton c = new FiniteAutomaton();
    	
    	FAState q = c.createState();
    	for(String letter : a.alphabet) {
    		c.addTransition(q, q, letter);
    	}
    	
    	c.setInitialState(q);
    	c.F.add(q);
    	
    	dk.brics.automaton.Automaton dkA = UtilAutomaton.convertToDkAutomaton(a);
    	dk.brics.automaton.Automaton dkB = UtilAutomaton.convertToDkAutomaton(b);
    	
    	dkA = dkA.union(dkB);
    	
        FiniteAutomaton ck = UtilAutomaton.convertToRabitAutomaton(dkA);
		PrintStream outOld = System.out;
		try {
			PrintStream out = new PrintStream(new FileOutputStream("rabitlog.txt"));
			System.setOut(out);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
        RabitOracle oracle = new RabitOracle(c);
        boolean result = oracle.isEqualBuechi(ck).isEqual;
        System.setOut(outOld);
        System.out.println("Complementation result is " + result);
        
        return result;
    }
  
}
