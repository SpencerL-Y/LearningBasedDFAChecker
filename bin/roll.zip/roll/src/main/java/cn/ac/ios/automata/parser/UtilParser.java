package cn.ac.ios.automata.parser;

import cn.ac.ios.automata.parser.ba.BAParser;
import cn.ac.ios.automata.parser.hoa.HOAParser;

public class UtilParser {
	
	public static Parser prepare(String file, FormatType type) {
		if(type == FormatType.BA) {
			return new BAParser(file);
		}else if(type == FormatType.HOA) {
			return new HOAParser(file);
		}
		
		return null;
	}
	
	//prevent instantiation
	private UtilParser() {
		
	}

}
