package cn.ac.ios.oracle.teacher;

import automata.FiniteAutomaton;
import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.options.Options;
import cn.ac.ios.value.ValueManager;
import oracle.EqResult;

public final class UtilTeacher {
	
	public static Teacher<FiniteAutomaton, EqResult, Boolean> prepareTeacher(FiniteAutomaton target) {
		
		ValueManager valueManager = new ValueManager();
		WordManager wordManager = new WordManager(valueManager);
		Teacher<FiniteAutomaton, EqResult, Boolean> teacher = null;
		
		if(Options.learnerLDollar || Options.learnerPeriodic 
				|| Options.learnerSyntactic || Options.learnerRecurrent) {
			if(Options.teacherSampling) teacher = new TeacherSample(wordManager, target, Options.epsilon, Options.delta);
			else teacher = new TeacherRabit(wordManager, target);
		}else {
			teacher = new TeacherDK(wordManager, target);
		}
		
		Options.wordManager = wordManager;
		return teacher;
	}
	
	private UtilTeacher() {
		
	}

}
