package cn.ac.ios.roll;

import cn.ac.ios.automata.Acceptor;
import cn.ac.ios.automata.Automaton;
import cn.ac.ios.automata.words.Alphabet;
import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.learner.Learner;
import cn.ac.ios.learner.UtilLearner;
import cn.ac.ios.options.Options;
import cn.ac.ios.oracle.EquivalenceOracleImpl;
import cn.ac.ios.oracle.MembershipOracleImpl;
import cn.ac.ios.query.EquivalenceOracle;
import cn.ac.ios.query.MembershipOracle;
import cn.ac.ios.query.Query;
import cn.ac.ios.util.InputHelper;
import cn.ac.ios.value.Type;
import cn.ac.ios.value.Value;
import cn.ac.ios.value.ValueManager;

// interact with user
public class PlayExecution {
	
	public static void execute() {		
		
		// prepare the alphabet
		WordManager wordManager = prepareAlphabet();
		MembershipOracle<Boolean> membershipOracle = new MembershipOracleImpl();
		Learner<? extends Acceptor, Boolean> learner = UtilLearner.prepareLearner(wordManager, membershipOracle);
		
		Options.log.println("Start learning...");
		learner.startLearning();
		boolean result = false;
		while(! result ) {
			Automaton model = (Automaton)learner.getHypothesis();
			EquivalenceOracle<Automaton, Boolean> equivalenceOracle = new EquivalenceOracleImpl();
			result = equivalenceOracle.answerEquivalenceQuery(model);
			if(result == true) break;
			Query<Boolean> ceQuery = null;
			if(Options.learnerLDollar || Options.learnerPeriodic || Options.learnerSyntactic || Options.learnerRecurrent) {
				ceQuery = InputHelper.getOmegaCeWord(wordManager);
			}else {
				ceQuery = InputHelper.getCeWord(wordManager);
			}
			learner.refineHypothesis(ceQuery);
		}
		
		Options.log.println("Learning completed...");
		
	}
	
	
	private static WordManager prepareAlphabet() {
		ValueManager valueManager = new ValueManager();
		WordManager wordManager = new WordManager(valueManager);
		Options.log.println("Please input the number of letters: ");
		int numLetters = InputHelper.getInterger();
		Type typeObject = valueManager.newTypeObject(String.class);
		valueManager.newTypeLetter(String.class);
		Value valueLetter = typeObject.newValue();
		Alphabet alphabet = wordManager.getAlphabet();
		for(int letterNr = 0; letterNr < numLetters; letterNr ++) {
			Options.log.print("Please input the " + (letterNr + 1) + "th letter: ");
			String letter = InputHelper.getLetter();
			valueLetter.set(letter);
			alphabet.add(valueLetter.clone());
		}
		alphabet.setImmutable();
		valueLetter.set("");
		wordManager.setLetterSplitter(valueLetter);
		return wordManager;
	}
	
	
	private PlayExecution() {
		
	}

}
