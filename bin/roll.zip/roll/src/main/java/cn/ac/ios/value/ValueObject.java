/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.value;

class ValueObject implements Value {

	private Object object;
	private final Type type;
	private boolean immutable;
	ValueObject(Type type, Object object) {
		assert type != null;
		assert object == null || type.getUsedClass().isInstance(object);
		this.type = type;
		this.object = object;
	}
	
	ValueObject(Type type) {
		this(type, null);
	}
	
	@Override
	public Value clone() {
		return new ValueObject(type, object);
	}

	@Override
	public Type getType() {
		return type;
	}
	
    public boolean isObject() {
        return true;
    }        
	
	@Override
	public void setImmutable() {
		this.immutable = true;
	}
	@Override
	public boolean isImmutable() {
		return this.immutable;
	}
	
	public <T> T getObject() {
		return (T) object;
	}
	
    @Override
    public void set(Object obj) {
        assert !isImmutable();
        assert obj == null ||
                getType().getUsedClass().isInstance(obj);
        this.object = obj;
    }
    
    public void set(String value) {
        assert !isImmutable();
        assert value == null ||
                getType().getUsedClass().isInstance(value);
        this.object = value;
    }
    
    @Override
    public void set(Value op) {
        assert !isImmutable();
        assert op != null;
        assert op.isObject();
        object = op.getObject();
    }
    
    @Override
    public boolean equals(Object obj) {
        assert obj != null;
        if (!(obj instanceof ValueObject)) {
            return false;
        }
        ValueObject other = (ValueObject) obj;
        return object.equals(other.object);
    }
    
    @Override
    public String toString() {
        return object.toString();
    }
    
    @Override
    public int hashCode() {
    	return object.hashCode();
    }

}
