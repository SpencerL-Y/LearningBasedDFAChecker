package cn.ac.ios.bdd.graph;

import java.util.HashMap;
import java.util.Map;

import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.bdd.BDDManager;
import cn.ac.ios.bdd.Permutation;
import cn.ac.ios.bdd.VariableBDD;
import cn.ac.ios.value.Value;
import dk.brics.automaton.Automaton;
import dk.brics.automaton.State;
import dk.brics.automaton.Transition;
import net.sf.javabdd.BDD;
import net.sf.javabdd.BDDPairing;

/** BDD representation of a finite state automaton */
//TODO
public class IntersectionChecker {
	
	private WordManager wordManager;
	
	private Automaton autA;
	private Automaton autB;
	private BDDManager bdd;
	private VariableBDD varBDDLetter;
	private VariableBDD varBDDAutA;
	private VariableBDD varBDDAutB;
	
	private BuechiBDD autABDD;
	private BuechiBDD autBBDD;
	private Value valueLetter;
	
	public IntersectionChecker(WordManager wordManager
			, Automaton autA, Automaton autB) {
		this.wordManager = wordManager;
		this.autA = autA;
		this.autB = autB;
		this.bdd = new BDDManager(125000, 125000);
		this.valueLetter = wordManager.getContextValue().getTypeLetter().newValue();
	}
	
	private int getLetterIndex(String letter) {
		this.valueLetter.set(letter);
		int index = wordManager.getAlphabet().indexOf(this.valueLetter);
		if(index == -1)  {
			System.err.println("Illegal character letter");
		}
		return index;
	}
	
	public void prepareSymbolic() {
		// prepare for the alphabet
		varBDDLetter = new VariableBDD(bdd, 1, "l", 0, wordManager.getNumLetters()-1);
		// prepare for the states in autA
		varBDDAutA = new VariableBDD(bdd, 2, "s", 0, autA.getNumberOfStates()-1);
		autABDD = prepareAutomaton(autA, varBDDAutA);
		// prepare for the states in autB
		varBDDAutB = new VariableBDD(bdd, 2, "t", 0, autB.getNumberOfStates()-1);
		autBBDD = prepareAutomaton(autB, varBDDAutB);
	}
	
	private Integer getStateID(Map<State, Integer> map, State s) {
		Integer id = map.get(s);
		if(id == null) {
			id = map.size();
			map.put(s, id);
		}
		return id;
	}
	
	public BuechiBDD getBuechiA() {
		return autABDD;
	}
	
	public BuechiBDD getBuechiB() {
		return autBBDD;
	}
	
	private BuechiBDD prepareAutomaton(Automaton aut, VariableBDD var) {
		BuechiBDD buechiBDD = new BuechiBDD(bdd);
		Map<State, Integer> map = new HashMap<>();
		
		BDD states = bdd.getZero();
		BDD transition = bdd.getZero();
		BDD acc = bdd.getZero();
		// initial states
		int initID = getStateID(map, aut.getInitialState());
		buechiBDD.setInitial(var.newValue(0, initID));
		
		Permutation perm = new Permutation(bdd, var.getBDDVariables(0), var.getBDDVariables(1));
		for(State s : aut.getStates()) {
			int stateID = getStateID(map, s);
			BDD sBDD = var.newValue(0, stateID);
			BDD temp = states;
			states = temp.or(sBDD);
			temp.free();
			
			// construct transition relation 
			for(Transition t: s.getTransitions()) {
				State succ = t.getDest();
				int succID = getStateID(map, succ);
				BDD succBDD = var.newValue(1, succID);
				BDD label = bdd.getZero();
				for(char c = t.getMin(); c <= t.getMax(); c ++) {
					int letterNr = getLetterIndex(c + "");
					label = label.orWith(varBDDLetter.newValue(0, letterNr));
				}
				transition = transition.orWith(succBDD.and(sBDD).and(label));
				succBDD.free();
				label.free();
			}
			
			if(s.isAccept()) {
				acc = acc.orWith(sBDD);
			}else {
				sBDD.free();
			}
		}
		
		buechiBDD.setStateSpace(states);
		buechiBDD.setTransition(transition);
		buechiBDD.addAcceptance(acc);
		
		buechiBDD.setPreCube(var.getCube(0));
		buechiBDD.setNextCube(var.getCube(1));
		buechiBDD.setActionCube(varBDDLetter.getCube(0));
		
		buechiBDD.setPermutation(perm);
		
		return buechiBDD;
	}
	

}
