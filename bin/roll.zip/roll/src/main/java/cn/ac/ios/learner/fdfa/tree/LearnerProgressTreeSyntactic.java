/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.learner.fdfa.tree;

import java.util.BitSet;

import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.automata.words.Word;
import cn.ac.ios.learner.tree.ValueNode;

import cn.ac.ios.query.MembershipOracle;

import cn.ac.ios.table.ExprValue;
import cn.ac.ios.table.HashableValue;
import cn.ac.ios.tree.Node;
import cn.ac.ios.tree.TreePrinterBoolean;
import gnu.trove.iterator.TIntObjectIterator;

//TODO: make the code more clear
public class LearnerProgressTreeSyntactic extends LearnerProgressTree {

	public LearnerProgressTreeSyntactic(WordManager contextWord, MembershipOracle<Boolean> membershipOracle,
			Word label) {
		super(contextWord, membershipOracle, label);
	}

	@Override
	protected CeAnalyzer getCeAnalyzerInstance(ExprValue exprValue) {
		return new CeAnalyzerTreeSyntactic(exprValue);
	}
	
	private class CeAnalyzerTreeSyntactic extends CeAnalyzer {

		public CeAnalyzerTreeSyntactic(ExprValue ce) {
			super(ce);
		}

		/** the progress automaton does depend on the leading automaton */
		// need to consider how to apply uv ~ u, since the tree and automaton
		// may not be consistent, but since CeAnalyzer is called, that means
		// the corresponding leading state is reachable from itself.
		@Override
		public void analyze() {
			// By default, first uv ~ u
			HashableValue resultPrev = getHashableValueIntBoolean(state, isCEAccepting, true);
			
			// only has one leaf
			if(tree.getRoot().isLeaf()) {
				this.wordExpr = getExprValueWord(contextWord.getEmptyWord());
				this.nodePrev = tree.getRoot();
				this.wordLeaf = getExprValueWord(exprValue.get());
				this.nodePrevBranch = getHashableValueIntBoolean(state, !isCEAccepting, true);
				this.leafBranch = resultPrev;
				return ;
			}
			
			Word wordCE = this.exprValue.get();
			// get the initial state from automaton
		    int letterNr = 0, stateCurr = -1, statePrev = getInitState();
		    HashableValue resultCurr = null;
			// starting state is lambda
			for(; letterNr < wordCE.length(); letterNr ++) {
				stateCurr = computeNextState(statePrev, wordCE.getLetter(letterNr));
				Word period = states.get(stateCurr).label;   // S(j)
				period = period.concat(wordCE.getSuffix(letterNr + 1)); // S(j) y[j+1...n]
				resultCurr = processMembershipQuery(period);; // u (Sj y[j+1..n])
				// ux != uy (c1 != c2) or m1 != m2
				// ==> q1 != q2 (c) or m1 != m2
				if((! resultPrev.getLeft().equals(resultCurr.getLeft()))
				|| (!resultPrev.getRight().equals(resultCurr.getRight()))) {
					break;
				}
				statePrev = stateCurr;                    // record S(j)
				resultPrev = resultCurr;                  // will change branch
			}
			
			Word wordPrev = states.get(statePrev).label;         // S(j-1)
			this.wordExpr = getExprValueWord( wordCE.getSuffix(letterNr + 1));  // y[j+1..n]
			this.wordLeaf = getExprValueWord(wordPrev.append(wordCE.getLetter(letterNr))); // S(j-1)y[j]
			this.nodePrev = states.get(stateCurr).node;          // S(j)
			this.leafBranch = resultPrev;                        // S(j-1)y[j] branch
			this.nodePrevBranch = resultCurr;                    // S(j) branch
		
		}
		
	}
	
	@Override
	protected HashableValue processMembershipQuery(Word suffix) {
		boolean resultLeft = processMembershipQuery(label, suffix);
		int stateReachByXV = learnerLeading.computeReachState(state, suffix);
		boolean resultRight = state == stateReachByXV;
		return getHashableValueIntBoolean(stateReachByXV, resultLeft, resultRight);
	}
	
	private HashableValue getHashableValueIntBoolean(int state, boolean m, boolean c) {
		return new HashableValueIntBooleanPair(state, m, c);
	}
	
	// rewrite this function

	private Partition findNodePartition(Word word) {
		return findNodePartition(word, tree.getRoot());
	}
	
	private Partition findNodePartition(Word word, Node<ValueNode> nodeCurr) {
		while(! nodeCurr.isLeaf()) {
			Word wordExpr = nodeCurr.getLabel().get();
			HashableValue result = processMembershipQuery(word.concat(wordExpr));
			Node<ValueNode> node = nodeCurr.getChild(result);
			if(node == null) {
				return new Partition(false, nodeCurr, result); // new leaf node
			}
			nodeCurr = node; // possibly we can not find that node
		}
		return new Partition(true, nodeCurr, null);
	}
	
	//TODO be carefull with accepting states
	// should I rewrite updateTree function?
	//TODO make code more clear
	
	@Override
	protected void updatePredecessors() {
		
		TIntObjectIterator<BitSet> iterator = nodeToSplit.getValue().predecessors.iterator();
		Node<ValueNode> parent = nodeToSplit.getParent();
		BitSet letterDeleted = new BitSet();
		while(iterator.hasNext()) {
			iterator.advance();
			int letter = iterator.key();
			BitSet statePrevs = (BitSet)iterator.value().clone(); 
			BitSet stateRemoved = new BitSet(statePrevs.size());
			// when addNode is called, statePrevs will not add states, 
			// but iterator.value() may add new states
			// since we do not care new added states, they are correct
			for(int stateNr = statePrevs.nextSetBit(0)
					; stateNr >= 0
					; stateNr = statePrevs.nextSetBit(stateNr + 1)) {
				ValueNode statePrev = states.get(stateNr);
				Partition partition = findNodePartition(statePrev.label.append(letter), parent);
				if(partition.found) {
					if (partition.node != nodeToSplit) {
						updateTransition(stateNr, letter, partition.node.getValue().id);
						stateRemoved.set(stateNr); // remove this predecessor
					} // change to other leaf node
				}else {
					Node<ValueNode> node = addNode(partition.node, partition.branch
							, getExprValueWord(statePrev.label.append(letter)));
					updateTransition(stateNr, letter, node.getValue().id);
					stateRemoved.set(stateNr);  // remove this predecessor
				}
			}
			BitSet temp = (BitSet)iterator.value().clone(); 
			temp.andNot(stateRemoved);
			if(temp.isEmpty()) {
				letterDeleted.set(letter);
			}else {
				iterator.setValue(temp);
			}
		}
		
		for(int letter = letterDeleted.nextSetBit(0)
				; letter >= 0
				; letter = letterDeleted.nextSetBit(letter + 1)) {
			nodeToSplit.getValue().predecessors.remove(letter);
		}
		
	}
	
	public String toString() {
		return TreePrinterBoolean.toString(tree);
	}
	
	private class Partition {
		boolean found ;
		Node<ValueNode> node;
		HashableValue branch;
		
		public Partition(boolean f, Node<ValueNode> n, HashableValue v) {
			this.found = f;
			this.node = n;
			this.branch = v;
		}
	}
	
	private Node<ValueNode> addNode(Node<ValueNode> parent, HashableValue branch, ExprValue nodeLabel) {
		Node<ValueNode> nodeLeaf = getValueNode(parent, branch, nodeLabel);
		ValueNode stateLeaf =  new ValueNode(states.size(), nodeLabel.get());
		stateLeaf.node = nodeLeaf;
		nodeLeaf.setValue(stateLeaf);
		states.add(stateLeaf); // add new state
		
		parent.addChild(branch, nodeLeaf);
		// test whether this node is accepting
		Word period = nodeLabel.get();
		HashableValue result = processMembershipQuery(period);
//		Boolean isAccepting = result.getLeft();
		if(result.isAccepting()) nodeLeaf.setAcceting();
		
		updateSuccessors(stateLeaf.id, 0, contextWord.getNumLetters() - 1);
		return nodeLeaf;
	}
	
	// may add new leaf node during successor update
	@Override
	protected void updateSuccessors(int stateNr, int letterFrom, int letterTo) {
		assert stateNr < states.size() 
	    && letterFrom >= 0
	    && letterTo < contextWord.getNumLetters();
		
		ValueNode state = states.get(stateNr);
		
		Word label = state.label;
		for(int letter = letterFrom; letter <= letterTo; letter ++) {
			Word wordSucc = label.append(letter);
			Partition nodeSucc = findNodePartition(wordSucc);
			if(nodeSucc.found) {
				updateTransition(stateNr, letter, nodeSucc.node.getValue().id);
			}else {
				Node<ValueNode> node = addNode(nodeSucc.node, nodeSucc.branch, getExprValueWord(wordSucc));
				updateTransition(stateNr, letter, node.getValue().id);
			}
			
		}
		
	}

}
