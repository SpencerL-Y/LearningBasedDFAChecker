/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.value;

class ValueDouble implements Value {

	private double value;
	private final Type type;
	private boolean immutable;
	
	ValueDouble(Type type, double value) {
		assert type != null;
		this.type = type;
		this.value = value;
	}
	
	ValueDouble(Type type) {
		this(type, 0.0);
	}
	
	@Override
	public Value clone() {
		return new ValueDouble(type, value);
	}

	@Override
	public Type getType() {
		return type;
	}
	
	@Override
	public void setImmutable() {
		this.immutable = true;			
	}
	
	@Override
	public boolean isImmutable() {
		return this.immutable;
	}
	
    public void set(double value) {
        assert !isImmutable();
        this.value = value;
    }
    
	public void set(Object value) {
		assert !isImmutable();
		assert value.getClass() == Double.class;
		this.value = (Double)value;
	}
    
    public boolean isZero() {
        return value == 0.0;
    }

    public boolean isOne() {
        return value == 1.0;
    }

    public boolean isDouble() {
        return true;
    }
    
    public void add(Value op1, Value op2) {
        assert op1 != null && op2 != null;
        assert !op1.isBoolean() && !op2.isBoolean(); 
        assert !op1.isObject() && !op2.isObject();
        
        set(op1.getDouble() + op2.getDouble());
    }
    
    public void divide(Value op1, Value op2)  {
        assert op1 != null && op2 != null;
        assert !op1.isBoolean() && !op2.isBoolean(); 
        assert !op1.isObject() && !op2.isObject();
        if(Double.compare(op2.getDouble(), 0) == 0) {
        	System.err.println("divied by 0: "  + op1 + "/" + op2);
        	System.exit(-1);
        }
        set(op1.getDouble() / op2.getDouble());
    }
    
    public void subtract(Value op1, Value op2) {
        assert op1 != null && op2 != null;
        assert !op1.isBoolean() && !op2.isBoolean(); 
        assert !op1.isObject() && !op2.isObject();
        
        set(op1.getDouble() - op2.getDouble());
    }
    
    public void multiply(Value op1, Value op2)  {
        assert op1 != null && op2 != null;
        assert !op1.isBoolean() && !op2.isBoolean(); 
        assert !op1.isObject() && !op2.isObject();
        
        set(op1.getDouble() * op2.getDouble());
    }
    
    public void max(Value op1, Value op2)  {
        assert op1 != null && op2 != null;
        assert !op1.isBoolean() && !op2.isBoolean(); 
        assert !op1.isObject() && !op2.isObject();
        double op ;
        if(op1.getDouble() > op2.getDouble()) {
        	op = op1.getDouble();
        }else {
        	op = op2.getDouble();
        }
        set(op);
    }
    
    public void min(Value op1, Value op2)  {
        double op ;
        if(op1.getDouble() > op2.getDouble()) {
        	op = op2.getDouble();
        }else {
        	op = op1.getDouble();
        }
        set(op);
    }
    
    // sets
    public void set(Value value) {
    	assert !isImmutable();
    	assert value != null;
    	assert !value.isBoolean() && !value.isObject();
    	set(value.getDouble());
    }
    
    
    private double castTo(Value val) {
    	double op = 0;
    	if(val.isDouble()) {
    		op = val.getDouble();
    	}else if(val.isInteger()) {
    		op = val.getInt();
    	}else {
    		assert false : "wrong type to double";
    	}
		return op;
	}

	public void set(int value) {
        assert !isImmutable();
        set((double)value);
    }

    public void set(String value) {
        double op = 0;
        try {
        	op = Double.parseDouble(value);
        }catch(NumberFormatException e) {
        	assert false : value;
        }
        set(op);
    }

    // gets
    public int getInt() {
        return (int)getDouble();
    }
    
    public double getDouble() {
        return value;
    }
    
    @Override
    public String toString() {
    	return "" + value;
    }
    
    @Override
    public boolean equals(Object obj) {
        assert obj != null;
        if (!(obj instanceof ValueDouble)) {
            return false;
        }
        ValueDouble other = (ValueDouble) obj;
        return Double.compare(this.value, other.value) == 0;
    }
    
    @Override
    public int hashCode() {
    	return Double.valueOf(value).hashCode();
    }

}
