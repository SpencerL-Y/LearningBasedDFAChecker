/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.util;

import java.util.ArrayList;
import java.util.BitSet;
import java.util.List;
import java.util.Set;

import cn.ac.ios.automata.Automaton;
import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.automata.words.Word;
import cn.ac.ios.learner.fdfa.LearnerFDFA;
import cn.ac.ios.options.Options;

import dk.brics.automaton.BasicAutomata;
import dk.brics.automaton.State;
import dk.brics.automaton.Transition;
import gnu.trove.map.TIntObjectMap;
import gnu.trove.map.hash.TIntObjectHashMap;

public class DollarAutomatonBuilder {
	
	private static Word getSmallestPeriod(Word period) {
		// from the possible smallest length
		for(int i = 1; i <= period.length() / 2; i ++) {
			// can be divided
			if (period.length() % i == 0) {
				Word rep = period.getPrefix(i);
				// compute the number of repeat
				int num = period.length() / i;
				boolean repeated = true;
				for(int j = 0; j < num; j ++) {
					int pNr = j * i;
					Word p = period.getSubWord(pNr, i);
					if(! p.equals(rep)) {
						repeated = false;
						break;
					}
				}
				// reduce the period
				if(repeated) { 
					period = rep;
					break;
				}
			}
		}
		return period;
	}
	
//	for (int i = 1; i <= suffix.length() / 2; i++) {
//		if (suffix.length() % i == 0) {
//			Word rep = suffix.getPrefix(i);
//			for (int j = 1; j < suffix.length() / i; j++)
//				rep = rep.concat(rep);
//			if (rep.equals(suffix)) {
//				suffix = suffix.getPrefix(i);
//				break;
//			}
//		}
//	}

	// Given word prefix and suffix, we do the shifting operation
	// as well as return the corresponding dk.brics.automaton.
	public static dk.brics.automaton.Automaton buildDollarAutomaton(Word prefix, Word suffix) {
		// Finds the smallest period of suffix.
        suffix = getSmallestPeriod(suffix);
        
		// Shifts prefix to the smallest one.
		while (prefix.getLastLetter() == suffix.getLastLetter()) {
			prefix = prefix.getPrefix(prefix.length() - 1);
			suffix = suffix.getSuffix(suffix.length() - 1).concat(suffix.getPrefix(suffix.length() - 1));
		}

		// System.out.println(prefix.toStringWithAlphabet() + ',' +
		// suffix.toStringWithAlphabet());
		dk.brics.automaton.Automaton result = new dk.brics.automaton.Automaton();
		for (int i = 0; i < suffix.length(); i++) {
			dk.brics.automaton.Automaton suf, pre = new dk.brics.automaton.Automaton();
			suf = BasicAutomata.makeString(suffix.toStringWithAlphabet());
			if (!prefix.isEmpty()) {
				pre = BasicAutomata.makeString(prefix.toStringWithAlphabet());
				pre = pre.concatenate(suf.repeat());
			} else
				pre = suf.repeat();
			suf = suf.repeat(1);
			pre.minimize();
			Set<State> acc = pre.getAcceptStates();
			if (acc.size() > 1)
				System.out.println("Error! More than 1 accepted states!");
			for (State s : acc) {
				State ini = suf.getInitialState();
				s.setAccept(false);
				s.addTransition(new Transition('$', ini));
			}
			pre.restoreInvariant();
			result = result.union(pre);
			prefix = prefix.append(suffix.getFirstLetter());
			suffix = suffix.getSubWord(1, suffix.length() - 1).append(suffix.getFirstLetter());
		}
		result.minimize();
		return result;
	}
	
	
	public static dk.brics.automaton.Automaton buildDollarAutomaton(LearnerFDFA learnerFDFA) {
		if(Options.verbose) learnerFDFA.getHypothesis();
		// L means Leading and P means Progress
		Automaton autL = learnerFDFA.getLeadingAutomaton();
		TIntObjectMap<State> map = new TIntObjectHashMap<>(); 
		dk.brics.automaton.Automaton dkAutL = UtilAutomaton.convertToDkAutomaton(map, autL);
		for(int stateNr = 0; stateNr < autL.getNumStates(); stateNr ++) {
		    Automaton autP = learnerFDFA.getProgressAutomaton(stateNr);
		    dk.brics.automaton.Automaton dkAutLOther = UtilAutomaton.convertToDkAutomaton(autL, stateNr, stateNr);
		    dk.brics.automaton.Automaton dkAutP = UtilAutomaton.convertToDkAutomaton(autP);
		    
		    dk.brics.automaton.Automaton product = dkAutLOther.intersection(dkAutP);
		    product.minimize();
		    if(! product.getAcceptStates().isEmpty()) {
			    State u = map.get(stateNr); // make dollar transitions
			    u.addTransition(new Transition(WordManager.getStringDollar().charAt(0), product.getInitialState()));
		    }
		}
		dkAutL.setDeterministic(true);
		return dkAutL;
	}
	
	public static dk.brics.automaton.Automaton buildDollarFDFAComplement(LearnerFDFA learnerFDFA) {
		if(Options.verbose) learnerFDFA.getHypothesis();
		// L means Leading and P means Progress
		Automaton autL = learnerFDFA.getLeadingAutomaton();
		TIntObjectMap<State> map = new TIntObjectHashMap<>(); 
		dk.brics.automaton.Automaton dkAutL = UtilAutomaton.convertToDkAutomaton(map, autL);
		for(int stateNr = 0; stateNr < autL.getNumStates(); stateNr ++) {
		    Automaton autP = learnerFDFA.getProgressAutomaton(stateNr);
		    dk.brics.automaton.Automaton dkAutLOther = UtilAutomaton.convertToDkAutomaton(autL, stateNr, stateNr);
		    dk.brics.automaton.Automaton dkAutP = UtilAutomaton.convertToDkAutomaton(autP);
		    dkAutP = dkAutP.complement();
		    dk.brics.automaton.Automaton product = dkAutLOther.intersection(dkAutP);
		    product.minimize();
		    if(! product.getAcceptStates().isEmpty()) {
			    State u = map.get(stateNr); // make dollar transitions
			    u.addTransition(new Transition(WordManager.getStringDollar().charAt(0), product.getInitialState()));
		    }
		}
		dkAutL.setDeterministic(true);
		return dkAutL;
	}
	
	public static dk.brics.automaton.Automaton buildDollarNFA(LearnerFDFA learnerFDFA) {
		if(Options.verbose) learnerFDFA.getHypothesis();
		// L means Leading and P means Progress
		Automaton autL = learnerFDFA.getLeadingAutomaton();
		TIntObjectMap<State> map = new TIntObjectHashMap<>(); 
		dk.brics.automaton.Automaton dkAutL = UtilAutomaton.convertToDkAutomaton(map, autL);
		for(int stateNr = 0; stateNr < autL.getNumStates(); stateNr ++) {
		    Automaton autP = learnerFDFA.getProgressAutomaton(stateNr);
		    BitSet accs = autP.getAcceptingStates();
		    List<dk.brics.automaton.Automaton> autAccs = new ArrayList<>();
		    int stateInitP = autP.getInitialStates().nextSetBit(0);
		    for(int accNr = accs.nextSetBit(0); accNr >= 0; accNr = accs.nextSetBit(accNr + 1)) {
		    	dk.brics.automaton.Automaton dkAutP = UtilAutomaton.convertToDkAutomaton(autP, stateInitP, accNr);
		    	dkAutP.minimize();
		    	dk.brics.automaton.Automaton dkAutLOther = UtilAutomaton.convertToDkAutomaton(autL, stateNr, stateNr);
		    	dkAutLOther.minimize();
		    	dk.brics.automaton.Automaton product = dkAutP.intersection(dkAutLOther);
		    	product.minimize();
		    	
		    	if(! product.getAcceptStates().isEmpty()) {
		    		assert product.getAcceptStates().size() == 1;
		    		autAccs.add(product);
		    	}
		    }
		    State u = map.get(stateNr);
		    
		    for(dk.brics.automaton.Automaton aut : autAccs) {
		    	u.addTransition(new Transition(WordManager.getStringDollar().charAt(0), aut.getInitialState()));
		    }
		}
		dkAutL.setDeterministic(false);
		//dkAutL.minimize(); only for DFA
		return dkAutL;
	}

}
