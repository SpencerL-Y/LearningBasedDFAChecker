/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.learner.fdfa.tree;

import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.automata.words.Word;
import cn.ac.ios.learner.fdfa.LearnerLeading;
import cn.ac.ios.learner.fdfa.LearnerProgress;
import cn.ac.ios.query.MembershipOracle;
import cn.ac.ios.query.Query;
import cn.ac.ios.table.ExprValue;
import cn.ac.ios.table.ExprValueWord;
import cn.ac.ios.table.HashableValue;

abstract class LearnerProgressTree extends LearnerOmegaTree implements LearnerProgress {

	protected final Word label; 
	protected LearnerLeading learnerLeading;
	protected int state;
	
	public LearnerProgressTree(WordManager contextWord
			, MembershipOracle<Boolean> membershipOracle
			, Word label) {
		super(contextWord, membershipOracle);
		assert label != null;
		this.label = label;
	}
	
	@Override
	public void startLearning() {
		initializeTree();
	}

	@Override
	public boolean isLeading() {
		return false;
	}

	@Override
	protected boolean processMembershipQuery(ExprValue valueExpr) {
		assert valueExpr instanceof ExprValueWord;
		return processMembershipQuery(label, valueExpr);
	}
	
	// for syntactic and recurrent FDFA, only for
	// computing (m, c) for counter example analysis
	protected HashableValue processMembershipQuery(Word suffix) {
		boolean resultLeft = processMembershipQuery(label, suffix);
		int stateReachByXV = learnerLeading.computeReachState(state, suffix);
		boolean resultRight = state == stateReachByXV;
		return getHashableValueBoolean(resultLeft, resultRight);
	}
	
	// rewrite this function in progress automata
	@Override
	protected boolean processMembershipQuery(Word wordLabel, ExprValue valueExpr) {
		assert valueExpr instanceof ExprValueWord;
		ExprValueWord valueExprWord = (ExprValueWord)valueExpr;
		return processMembershipQuery(label, wordLabel.concat(valueExprWord.get()));
	}

	protected boolean isCEAccepting;
	@Override
	protected ExprValue getCounterExampleWord(Query<Boolean> query) {
		isCEAccepting = query.getQueryAnswer();
		return this.getExprValueWord(query.getSuffix());
	}

	@Override
	public Word getLeadingLabel() {
		return label;
	}

	@Override
	public void setLearnerLeading(LearnerLeading learnerLeading) {
		this.learnerLeading = learnerLeading;
		this.state = learnerLeading.computeReachState(label);
	}

}
