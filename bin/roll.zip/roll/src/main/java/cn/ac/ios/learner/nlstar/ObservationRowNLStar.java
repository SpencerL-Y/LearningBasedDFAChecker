/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.learner.nlstar;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import cn.ac.ios.automata.words.Word;
import cn.ac.ios.table.HashableValue;
import cn.ac.ios.table.ObservationRowAbstract;

// inspired by LearnLib

public class ObservationRowNLStar extends ObservationRowAbstract {

	private int upperId;
	
	// rows for successors
	private ObservationRowNLStar[] succRows;
	
	// covered rows
	// if it is upper row, then only contain covered upper rows
	// otherwise contain all covered rows
	private List<ObservationRowNLStar> coveredRows = null;
	
	// is prime row
	private boolean prime = false;
	
	protected ObservationRowNLStar(Word word) {
		super(word);
	}
	
	public boolean equals(Object o) {
		if(! (o instanceof ObservationRowNLStar)) {
			return false;
		}
		ObservationRowNLStar other = (ObservationRowNLStar)o;
		return word.equals(other.word); // one row one word
	}
	
	// Row1 covers Row2 if Row2(i) implies Row1(i) 
	protected boolean covers(ObservationRowNLStar other) {
		List<HashableValue> otherValues = other.getValues(); 
		assert values.size() == otherValues.size();
		for(int valNr = 0; valNr < values.size(); valNr ++) {
			if((Boolean)otherValues.get(valNr).get() && (! (Boolean)values.get(valNr).get())) {
				return false;
			}
		}
		return true;
	}
	
	protected HashableValue getValue(int index) {
		return this.getValues().get(index);
	}
	
	protected boolean isNewRow() {
		return coveredRows == null;
	}
	
	protected boolean isPrime() {
		return prime;
	}
	
	protected int getUpperId() {
		return upperId;
	}
	
	protected boolean isUpperRow() {
		return (succRows != null);
	}
	
	protected void makeUpperRow(int id, int alphabetSize) {
		this.upperId = id;
		this.succRows = new ObservationRowNLStar[alphabetSize];
	}
	
	// update covered rows from new rows
	protected void updateCoveredRows(List<ObservationRowNLStar> newRows) {
		List<ObservationRowNLStar> oldCovered = coveredRows;
		
		this.coveredRows = new ArrayList<>();
		if(oldCovered != null) {
			addCoveredRows(oldCovered);
		}
		addCoveredRows(newRows);
	}
	
	
	// add new covered rows
	private void addCoveredRows(List<ObservationRowNLStar> rows) {
		for(ObservationRowNLStar row : rows) {
			if(row != this) {
				if(isUpperRow()) { // only add upper covered rows
					if(row.isUpperRow() && covers(row)) {
						coveredRows.add(row);
					}
				}
				else if(covers(row)) { // otherwise add all possible covered rows
					coveredRows.add(row);
				}
			}
		}
	}
	
	protected List<ObservationRowNLStar> getCoveredRows() {
		return coveredRows;
	}
	
	protected boolean checkPrime() {
		if(coveredRows.isEmpty()) {
			prime = true;
		}
		else {
			// first get the union of covered rows
			boolean[] values = new boolean[this.getValues().size()];
			Arrays.fill(values, false);
			for(ObservationRowNLStar covered : coveredRows) {
				if(covered.isUpperRow() || ! this.valuesEqual(covered)) {
					List<HashableValue> coveredValues = covered.getValues();
					for(int valueNr = 0; valueNr < coveredValues.size(); valueNr ++) {
						if((Boolean)coveredValues.get(valueNr).get()) {
							values[valueNr] = true;
						}
					}
				}
			}
			//it is prime if the union of covered rows is equal to itself
			prime = false;
			List<HashableValue> thisValues = this.getValues();
			for(int valueNr = 0; valueNr < thisValues.size(); valueNr ++) {
				if(values[valueNr] != (Boolean)thisValues.get(valueNr).get()) {
					prime = true;
					break;
				}
			}
		}
		
		return prime;
	}

}
