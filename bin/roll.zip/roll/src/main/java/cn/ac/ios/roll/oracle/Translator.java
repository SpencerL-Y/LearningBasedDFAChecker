/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.roll.oracle;

import java.util.BitSet;

import cn.ac.ios.automata.Acceptor;
import cn.ac.ios.automata.Automaton;
import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.automata.words.Word;
import cn.ac.ios.learner.Learner;
import cn.ac.ios.learner.fdfa.LearnerFDFA;
import cn.ac.ios.options.Options;
import cn.ac.ios.query.MembershipOracle;
import cn.ac.ios.query.Query;
import cn.ac.ios.query.QuerySimple;
import cn.ac.ios.roll.Statistics;
import cn.ac.ios.util.AutomatonPrinter;
import cn.ac.ios.util.DollarAutomatonBuilder;

import cn.ac.ios.util.Timer;
import cn.ac.ios.util.UtilAutomaton;
import dk.brics.automaton.State;
import dk.brics.automaton.Transition;
import gnu.trove.map.TIntObjectMap;
import gnu.trove.map.hash.TIntObjectHashMap;
import oracle.EqResult;

/* for counterexample translation, only for FDFA */
//TODO write a criterion that can determine whether we can still use 
// that counterexample
public class Translator {
	
	private static dk.brics.automaton.Automaton autDollar;
	private static WordManager contextWord = null;
	private static int numCalls;
	
	public static void initTranslator(Query<EqResult> query) {
		autDollar = null;
		contextWord = null;
		numCalls = 0;
		Timer timer = new Timer();
		timer.start();
		Word prefix = query.getPrefix();
		Word suffix = query.getSuffix();
		assert prefix != null && suffix != null;
		contextWord = prefix.getContextWord();
		autDollar = DollarAutomatonBuilder.buildDollarAutomaton(prefix, suffix);
		autDollar.setDeterministic(true);
		timer.stop();
		Statistics.timeTranslator += timer.getTimeElapsed();
	}
	
	private static String counterexample = null;
	private static boolean result = false;
	
	public static boolean canRefine(Query<EqResult> query
			, Learner<Acceptor, Boolean> learner
			, MembershipOracle<Boolean> membershipOracle) {
		Timer timer = new Timer();
		timer.start();
		counterexample = null;
		if(! Options.learnerLDollar) {
			if(Options.buechiBuildUnder) {
				// 1. for lower construction
				counterexample = translateLower(query, learner); 
			}else {
				// 2. for upper construction
				counterexample = translateUpper(query, learner, membershipOracle);
			}
			
		}else {
			if(numCalls == 0) {
				counterexample = 
						query.getPrefix().toStringExact() 
						+ WordManager.getStringDollar() + 
						query.getSuffix().toStringExact();
				result = query.getQueryAnswer().isCeInTarget;
			}
		}
		++ numCalls ;
		timer.stop();
		Statistics.timeTranslator += timer.getTimeElapsed();
		return counterexample != null;
	}
	
	
	public static Query<Boolean> translate() {
		assert contextWord != null && counterexample != null;
		
		Timer timer = new Timer();
		timer.start();
		if(Options.verbose) System.out.println("final counterexample " + counterexample);
		int dollarNr = counterexample.indexOf(WordManager.getStringDollar().charAt(0)); //
		Word prefix = contextWord.getWordFromString(counterexample.substring(0, dollarNr));
		Word period = contextWord.getWordFromString(counterexample.substring(dollarNr + 1));
		Query<Boolean> query = new QuerySimple<>(prefix, period);
		query.answerQuery(result);
		
		timer.stop();
		Statistics.timeTranslator += timer.getTimeElapsed();
		
		return query;
	}


	private static String getPositiveCounterExample(LearnerFDFA learnerFDFA) {
		
		dk.brics.automaton.Automaton dollarFDFAComplement = DollarAutomatonBuilder
				.buildDollarFDFAComplement(learnerFDFA);
		dk.brics.automaton.Automaton autMinus = autDollar.intersection(dollarFDFAComplement);
		assert autMinus != null;
		String ceStr = autMinus.getShortestExample(true);
		if(Options.verbose) System.out.println("in target: " + ceStr);
		return ceStr;
		
	}
	
	// -------- this is for lower Buechi automaton ----------------
	private static String translateLower(Query<EqResult> query
			, Learner<Acceptor, Boolean> learner) {
		if(Options.verbose) AutomatonPrinter.print(autDollar, System.out);
		EqResult eqResult = query.getQueryAnswer();
		LearnerFDFA learnerFDFA = (LearnerFDFA)learner;
		//1. build dollar automaton for FDFA
		String ceStr = null;
		if(eqResult.isCeInTarget) {
			// positive Counterexample, (u, v) is in target, not in constructed
			// Buechi, but possibly it is in FDFA, , already normalized
			ceStr = getPositiveCounterExample(learnerFDFA);
		}else {
			// negative Counterexample, (u, v) is not in target, but in FDFA
			// get intersection, already normalized.
			dk.brics.automaton.Automaton dollarFDFA = DollarAutomatonBuilder
					.buildDollarAutomaton(learnerFDFA);
			dk.brics.automaton.Automaton autInter = autDollar.intersection(dollarFDFA);
			assert autInter != null;
			ceStr = autInter.getShortestExample(true);
			if(Options.verbose) System.out.println("Not in target: " + ceStr);
		}
		
		return ceStr;
	}
	
	// --------- this is for upper Buechi automaton ----------------
	private static String translateUpper(Query<EqResult> query
			, Learner<Acceptor, Boolean> learner
			, MembershipOracle<Boolean> membershipOracle) {		
		
		LearnerFDFA learnerFDFA = (LearnerFDFA)learner;
		// for general case 
		if(Options.verbose) AutomatonPrinter.print(autDollar, System.out);
		if(Options.verbose) learnerFDFA.getHypothesis();
		if(query.getQueryAnswer().isCeInTarget) {
			// (u, v) is in L, but it is not in FDFA
			return getPositiveCounterExample(learnerFDFA);
		}else {
			// (u, v) is not in L, but it is in constructed Buechi
			// possibly it is not in FDFA, already normalized.
			return getCorrectNormalizedCounterExample(learnerFDFA, membershipOracle);
		}
		
	}
	
	// decompose x, y, z
	private static int getLastIndexAtFinal(
			dk.brics.automaton.Automaton dkAut, int startNr, String word) {
		int lastNr = -1, currNr = startNr;
		State stateCurr = dkAut.getInitialState();
		// record last accepting index
		if(stateCurr.isAccept()) lastNr = startNr;
		while(currNr < word.length()) {
			State stateNext = stateCurr.step(word.charAt(currNr));
			if(stateNext == null) break;
			if(stateNext.isAccept()) {
				lastNr = currNr;
			}
			stateCurr = stateNext;
			++ currNr;
		}
		
		return lastNr;
	}
	
	private static String getCorrectNormalizedCounterExample(LearnerFDFA learnerFDFA
			, MembershipOracle<Boolean> membershipOracle) {
		
		Word pre = null, suf = null;
		// 1. first build dollar deterministic automaton for (u, v) 
		if(Options.verbose) AutomatonPrinter.print(autDollar, System.out);
		
		// 2. for every final state, we get normalized counterexample
		Automaton autL = learnerFDFA.getLeadingAutomaton();
		TIntObjectMap<State> map = new TIntObjectHashMap<>(); 
		dk.brics.automaton.Automaton dkAutL = UtilAutomaton.convertToDkAutomaton(map, autL);
		
		for(int stateNr = 0; stateNr < autL.getNumStates(); stateNr ++) {
		    Automaton autP = learnerFDFA.getProgressAutomaton(stateNr);
		    BitSet accStates = autP.getAcceptingStates();
		    int stateInitP = autP.getInitialStates().nextSetBit(0);
		    boolean found = false;
		    // for every final state we get the language intersection
		    for(int accNr = accStates.nextSetBit(0); accNr >= 0; accNr = accStates.nextSetBit(accNr + 1)) {
		    	// language for A^u_f
		    	dk.brics.automaton.Automaton dkAutP = UtilAutomaton.convertToDkAutomaton(autP, stateInitP, accNr);
		    	// language for M^u_u
		    	dk.brics.automaton.Automaton dkAutLOther = UtilAutomaton.convertToDkAutomaton(autL, stateNr, stateNr);
		    	// build product for A^u_f and M^u_u
		    	dk.brics.automaton.Automaton product = dkAutP.intersection(dkAutLOther);
		    	if(! product.getAcceptStates().isEmpty()) {
		    		assert product.getAcceptStates().size() == 1;
		    		// add epsilon transition to allow x, concatenate y
		    		product = UtilAutomaton.addEpsilon(product);
		    		// get u state in leading automaton
		    		State u = map.get(stateNr); 
		    		// add Dollar transition
		    		Transition transDollar = new Transition(WordManager.getStringDollar().charAt(0), product.getInitialState());
		    		u.addTransition(transDollar);
		            // find u $ v string
		    		dk.brics.automaton.Automaton dkNFA = autDollar.intersection(dkAutL);
		    		String counterexample = dkNFA.getShortestExample(true);
		    		
		    		// remove duplicate dollar transition
		    		if(counterexample == null) {
		    			u.getTransitions().remove(transDollar);
		    			continue;
		    		}
		    		
		    		found = true;
		    		// get decomposition (u, xyz...) which is not in L
					if(Options.verbose) System.out.println("normalized counterexample " + counterexample);
					
					int dollarNr = counterexample.indexOf(WordManager.getStringDollar().charAt(0)); //
					pre = contextWord.getWordFromString(counterexample.substring(0, dollarNr));
					// must be some x,y,z concatenation
					String period = counterexample.substring(dollarNr + 1);
					
					// build deterministic automaton 
					dk.brics.automaton.Automaton dkAutCE = dkAutP.intersection(dkAutLOther);  
					Word p = learnerFDFA.getProgressStateLabel(stateNr, accNr);
					suf = findCorrectPeriod(dkAutCE, pre, p, period, membershipOracle);
		    	}
		    	if(found) break;
		    }
		    if(found) break;
		}
		return pre.toStringExact() + contextWord.getStringDollar() + suf.toStringExact();
	}
	
	// complex analysis for counter example
	private static Word findCorrectPeriod(dk.brics.automaton.Automaton dkAutCE
			, Word pre, Word p, String period, MembershipOracle<Boolean> membershipOracle) {
		
		int startNr = 0;
		WordManager contextWord = pre.getContextWord();
		Word suf = null;
		//INVARIANT:  Assume that (u, xyz...) is not in L
		while(startNr < period.length()) {
			
			int lastNr = getLastIndexAtFinal(dkAutCE, startNr, period);
			// only one x left, and (u, x) not in L
			Word x = contextWord.getWordFromString(period.substring(startNr, lastNr + 1));
			if(lastNr == period.length() - 1) {
				suf = x;
				break;
			}
			// now it must be at least two period, x, y
			boolean r = membershipOracle.answerMembershipQuery(new QuerySimple<>(pre, x));
			// 1. if (u, x) not in L
			if(! r) { 
				suf = x;
				break;
			}
			// 2. Assume (u, x) in L
			// try (u, pyz..)
			Word yzetc = contextWord.getWordFromString(period.substring(lastNr + 1));
			Word pyzetc = p.concat(yzetc);
			r = membershipOracle.answerMembershipQuery(new QuerySimple<>(pre, pyzetc));
			
			// 2.1 (u, pyz...) is in L, then yz.. can distinguish p and x
			if(r) {
				suf = x.concat(yzetc);
				break;
			}
			// 2.2 (u, pyz...) is not in L, we check (u, yz...)
			r = membershipOracle.answerMembershipQuery(new QuerySimple<>(pre, yzetc));
            
            // (u, yz...) is in L, then check the length of yz...
            if(r) {
            	int lastYNr = getLastIndexAtFinal(dkAutCE, lastNr + 1, period);
            	Word yz = contextWord.getWordFromString(period.substring(lastNr + 1));
            	if(lastYNr == period.length() - 1) {
            		suf = yz.concat(yz); // y distinguish p and y since (u, py) is not in L
            	}else {
            		// there exists z... and yz... can not lead to that accepting state?
            		assert false: "NO ";
            		suf = yz;
            	}
            	break;
            }
            // (u, yz...) is not in L
            startNr = lastNr + 1;
		}
		
		return suf;
	}
}
