package cn.ac.ios.automata;

import java.util.ArrayList;
import java.util.List;

public class FDFA implements Acceptor {
	@Override
	public AccType getAccType() {
		return AccType.FDFA;
	}
	
	public FDFA(DFA leadDFA, List<DFA> proDFAs) {
		assert leadDFA != null;
		assert proDFAs != null;
		this.leadingDFA = leadDFA;
		this.progressDFAs = proDFAs;
	}
	
	private final DFA leadingDFA;
	private final List<DFA> progressDFAs;
	
	public DFA getLeadingDFA() {
		return leadingDFA;
	}
	
	private List<String> labels = new ArrayList<>();
	
	public void setLeadingLabels(List<String> labels) {
		this.labels = labels;
	}
	
	public DFA getProgressDFA(int state) {
		assert state < progressDFAs.size();
		return progressDFAs.get(state);
	}
	
	public int getNumProgressDFA() {
		return progressDFAs.size();
	}
	
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("M: \n");
		builder.append(AutomataExporterDOT.toString(leadingDFA) + "\n");
		for(int index = 0; index < progressDFAs.size(); index ++) {
			builder.append("P" + index + " " + labels.get(index) + "\n");
			builder.append(AutomataExporterDOT.toString(progressDFAs.get(index)) + "\n");
		}
		return builder.toString();
	}
}
