/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.roll.translator;

import java.util.ArrayList;
import java.util.List;

import automata.FiniteAutomaton;
import cn.ac.ios.automata.Acceptor;
import cn.ac.ios.automata.Automaton;
import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.learner.Learner;
import cn.ac.ios.learner.buechi.ldollar.LearnerOmegaBuechi;
import cn.ac.ios.oracle.BuechiRunner;
import cn.ac.ios.query.Query;
import cn.ac.ios.query.QuerySimple;
import cn.ac.ios.roll.Statistics;
import cn.ac.ios.util.Timer;
import cn.ac.ios.util.UtilAutomaton;
import oracle.EqResult;

public class TranslatorBuechi extends TranslatorSimple {

	
	protected LearnerOmegaBuechi learnerOmegaBuechi;
	protected WordManager contextWord ;

	public TranslatorBuechi(Learner<? extends Acceptor, Boolean> learner) {
		super(learner);
		this.learnerOmegaBuechi = (LearnerOmegaBuechi)learner;
	}

	@Override
	public WordManager getContextWord() {
		return contextWord;
	}

	@Override
	public boolean canRefine() {
		if(super.canRefine()) {
			return true;
		}
		
		Timer timer = new Timer();
		timer.start();
		// check whether we can still use current counter example 
		FiniteAutomaton buechi = UtilAutomaton.convertToRabitAutomaton(learnerOmegaBuechi.getBuechi());
		//System.out.println(learnerOmegaBuechi.getBuechi().toDot());
		List<String> prefix = new ArrayList<String>();
		List<String> suffix = new ArrayList<String>();
		
		for(int letterNr = 0; letterNr < ceQuery.getPrefix().length(); letterNr ++) {
			prefix.add(contextWord.letterToString(ceQuery.getPrefix().getLetter(letterNr)));
		}
		
		for(int letterNr = 0; letterNr < ceQuery.getSuffix().length(); letterNr ++) {
			suffix.add(contextWord.letterToString(ceQuery.getSuffix().getLetter(letterNr)));
		}

		//System.out.println(prefix);
		//System.out.println(suffix);
		boolean accepted = BuechiRunner.isAccepting(buechi, prefix, suffix);

		// (u, v) is in target 
		boolean result ;
		if (ceQuery.getQueryAnswer().isCeInTarget){
			result = ! accepted;
		}//else
		else {
			result = accepted;
		}
		
		timer.stop();
		Statistics.timeTranslator += timer.getTimeElapsed();
		
		return result;
	}

	// initialize the translator for query
	@Override
	public void setQuery(Query<EqResult> query) {
		super.setQuery(query);
		this.contextWord = query.getPrefix().getContextWord();
	}

	@Override
	public Query<Boolean> translate() {
		Query<Boolean> query = new QuerySimple<>(ceQuery.getPrefix(), 
				ceQuery.getSuffix());
		query.answerQuery(ceQuery.getQueryAnswer().isCeInTarget);
		return query;
	}

}
