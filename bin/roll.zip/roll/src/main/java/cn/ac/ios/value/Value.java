/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.value;


public interface Value {
	
    final static String SPACE = " ";
    
	Value clone();
	
    String toString();

    Type getType();

    void setImmutable();

    boolean isImmutable();
    
    default boolean isFalse() {
        return isBoolean() && !getBoolean();
    }
    
    default boolean isTrue() {
        return isBoolean() && getBoolean();
    }
    
    default boolean isZero() {
        return false;
    }

    default boolean isOne() {
        return false;
    }

    default boolean isBoolean() {
        return false;
    }

    default boolean isDouble() {
        return false;
    }
    
    default boolean isInteger() {
        return false;
    }
    

    default boolean isObject() {
        return false;
    }        
    
    default boolean isFraction() {
    	return false;
    }
    
    // operations for numbers
    default void add(Value operand1, Value operand2) {
    	assert false;
    }
    
    default void divide(Value operand1, Value operand2)  {
        assert false;
    }
    
    default void subtract(Value operand1, Value operand2) {
        assert false;
    }
    
    default void inverse(Value operand1) {
        assert false;
    }
    
    default void not(Value operand)  {
        assert false;
    }
    
    default void multiply(Value operand1, Value operand2)  {
        assert false;
    }
    
    default void max(Value op1, Value op2)  {
        assert false;
    }
    
    default void min(Value op1, Value op2)  {
        assert false;
    }
    
    default void or(Value operand1, Value operand2) {
        assert false;
    }
    
    default void and(Value operand1, Value operand2) {
        assert false;
    }
    
    default void implies(Value operand1, Value operand2) {
        assert false;
    }
    
    default void iff(Value operand1, Value operand2) {
        assert false;
    }
    
    default ValueManager getContext() {
        return getType().getContext();
    }
    
    // sets
    default void set(Value value) {
        assert false : this + SPACE + getType() + SPACE + getClass();
    }
    
    default void set(boolean value) {
        assert false : this + SPACE + getType();
    }
    
    default void set(int value) {
        assert false : this + SPACE + value + SPACE + getClass();
    }

    default void set(double value) {
        assert false : this + SPACE + getType();
    }
    
    default void set(Object content) {
        assert false : this + SPACE + getType();
    }

    default void set(String value) {
        assert false : this + SPACE + this.getClass();
    }

    // gets
    
    default boolean getBoolean() {
        assert false : this + SPACE + getType() + SPACE + getClass();
        return false;
    }
    
    default int getInt() {
        assert false : this + SPACE + getType() + SPACE + getClass();
        return 0;
    }
    
    default double getDouble() {
        assert false : this + SPACE + getType() + SPACE + getClass();
        return -1.0;
    }

    default <T> T getObject() {
        assert false : this + SPACE + getType() + SPACE + getClass();
        return null;
    }
}
