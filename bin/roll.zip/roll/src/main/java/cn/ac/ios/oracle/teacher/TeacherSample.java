/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.oracle.teacher;

import java.util.ArrayList;
import java.util.List;

import automata.FiniteAutomaton;
import cn.ac.ios.automata.words.Alphabet;
import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.automata.words.Word;
import cn.ac.ios.options.Options;
import cn.ac.ios.oracle.BuechiRunner;
import cn.ac.ios.oracle.Minimizer;
import cn.ac.ios.query.Query;
import cn.ac.ios.query.QuerySimple;
import cn.ac.ios.roll.Statistics;
import cn.ac.ios.roll.sampler.BuechiSampler;
import cn.ac.ios.util.Pair;
import cn.ac.ios.util.Timer;
import cn.ac.ios.value.ValueManager;
import cn.ac.ios.value.Type;
import cn.ac.ios.value.Value;
import oracle.EqResult;

public class TeacherSample implements Teacher<FiniteAutomaton, EqResult, Boolean> {

	private final WordManager contextWord;
	private final FiniteAutomaton automaton;
	private int numEq = 0;
	private final double epsilon ;
	private final double delta;
	
	public TeacherSample(WordManager contextWord
			, FiniteAutomaton targetAut, double ep, double del) {
		assert targetAut != null && contextWord != null;
		this.contextWord = contextWord;
        this.automaton = Minimizer.minimizeBuechi(targetAut, 12);
        this.epsilon = ep;
        this.delta = del;
		// initialize alphabet
		ValueManager contextValue = contextWord.getContextValue();
		Type typeString = contextValue.newTypeLetter(String.class);
		Value valueLetter = typeString.newValue();
		Alphabet alphabet = contextWord.getAlphabet();
		if(Options.learnerLDollar) {
			valueLetter.set(WordManager.getStringDollar());
			alphabet.add(valueLetter.clone());
		}
		for(String letter : targetAut.alphabet) {
			valueLetter.set(letter);
			alphabet.add(valueLetter.clone());
		}
		alphabet.setImmutable();
		valueLetter.set("");
	    contextWord.setLetterSplitter(valueLetter);
	}

	@Override
	public Boolean answerMembershipQuery(Query<Boolean> query) {
		List<String> prefix = new ArrayList<>();
		List<String> suffix = new ArrayList<>();
        
		for(int i = 0; i < query.getPrefix().length(); i ++) {
			prefix.add(contextWord.letterToString(query.getPrefix().getLetter(i)));
		}
		for(int i = 0; i < query.getSuffix().length(); i ++) {
			suffix.add(contextWord.letterToString(query.getSuffix().getLetter(i)));
		}
		
        Timer timer = new Timer();
        timer.start();
        
		boolean result;
		
		if(suffix.isEmpty()) {
			result = false;
		}else {
			result = BuechiRunner.isAccepting(automaton, prefix, suffix);
		}
		
		timer.stop();
		Statistics.timeMembershipQuery += timer.getTimeElapsed();
		++ Statistics.numMembershipQuery; 
		return result;
	}
	
	// 1/epsilon * (ln (1/ (1 - delta)) + ln 2 * numEq)
	private long getNumSamples() {
		double result = (Math.log(1.0/ (1 - delta)) + Math.log(2) * numEq) / epsilon;
		long num = Math.round(result);
		System.out.println("Current number of sampling in Buechi is "
		+ num + " " + (numEq + 1) + " equivalence check...");
		return num;
	}

	@Override
	public Query<EqResult> answerEquivalenceQuery(FiniteAutomaton hypothesis) {
		System.out.println("Resloving equivalence check by Sampling...");
		Timer timer = new Timer();
		hypothesis = Minimizer.minimizeBuechi(hypothesis, 12);
		long numSample = getNumSamples();
		// sampling from the target automaton
		List<String> prefix = null, suffix = null;
	    boolean found = false, isInTarget = false;
		for(long n = 0; n < numSample && (!found) && (automaton.F.size() > 0); n ++) {
			++ Statistics.numSamplingOmegaWord; 
			Pair<List<String>, List<String>> word = BuechiSampler.samplePath(automaton);
			boolean result = BuechiRunner.isAccepting(hypothesis, word.getLeft(), word.getRight());
			if(! result) {
				prefix = word.getLeft();
				suffix = word.getRight();
				found = true;
				isInTarget = true;
			}
		}
		
		// sampling from the hypothesis automaton
		for(long n = 0; n < numSample && (!found) && (hypothesis.F.size() > 0); n ++) {
			++ Statistics.numSamplingOmegaWord; 
			Pair<List<String>, List<String>> word = BuechiSampler.samplePath(hypothesis);
			boolean result = BuechiRunner.isAccepting(automaton, word.getLeft(), word.getRight());
			if(! result) {
				prefix = word.getLeft();
				suffix = word.getRight();
				found = true;
			}
		}
		
		timer.stop();
		Statistics.timeEquivalenceQuery += timer.getTimeElapsed();
		++ Statistics.numEquivalenceQuery;
		Statistics.timeLastEquivalenceQuery = timer.getTimeElapsed();
		
		// increase the eq number
		++ numEq;
		Query<EqResult> query = null;
		EqResult eqResult = new EqResult();
		if(found) {
			String pre = "", suf = "";
			for(String p : prefix) {
				pre += p;
			}
			for(String p : suffix) {
				suf += p;
			}
			Word u = contextWord.getWordFromString(pre);
			Word v = contextWord.getWordFromString(suf);
			
			query = new QuerySimple<>(u, v);
			eqResult.isEqual = false;
			eqResult.isCeInTarget = isInTarget;
		}else {
			query = new QuerySimple<>(contextWord.getEmptyWord(), contextWord.getEmptyWord());
			eqResult.isEqual = true;
		}
		query.answerQuery(eqResult);
		
		System.out.println("Done for equivalence check by Sampling...");
		if(Options.verbose) System.out.println("sample counter example = " + query + " , " + eqResult.isCeInTarget);
		return query;
	}

}
