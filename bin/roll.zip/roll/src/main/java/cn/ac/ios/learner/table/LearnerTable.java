/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.learner.table;

import java.util.ArrayList;
import java.util.List;


import cn.ac.ios.automata.Automaton;
import cn.ac.ios.automata.DFA;
import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.automata.words.Word;
import cn.ac.ios.learner.LearnerType;
import cn.ac.ios.learner.fdfa.LearnerGeneral;

import cn.ac.ios.query.MembershipOracle;
import cn.ac.ios.query.Query;

import cn.ac.ios.table.ExprValue;
import cn.ac.ios.table.HashableValue;
import cn.ac.ios.table.ObservationRow;

/**
 * Learner based on Observation table
 * */
public abstract class LearnerTable implements LearnerGeneral {

	protected final WordManager contextWord;
	protected ObservationTableDFA observationTable;
	protected final MembershipOracle<Boolean> membershipOracle;
	private boolean alreadyStarted = false;
	protected Automaton hypothesis;
	
	public LearnerTable(WordManager contextWord
			, MembershipOracle<Boolean> membershipOracle) {
		assert contextWord != null && membershipOracle != null;
		this.contextWord = contextWord;
		this.membershipOracle = membershipOracle;
		this.observationTable = getTableInstance(contextWord);
	}
		
	protected abstract boolean isOmegaLearning();
	protected boolean isLeading() {
		return false;
	}

	@Override
	public void startLearning() {
		if(alreadyStarted )
			try {
				throw new Exception("Learner should not be started twice");
			} catch (Exception e) {
				e.printStackTrace();
			}
		alreadyStarted = true;
		initializeTable();
	}
	
	protected abstract void prepareRowDFA(ObservationRowDFA row);
	
	protected abstract Query<HashableValue> processMembershipQuery(ObservationRow row, int offset, ExprValue valueExpr);
	
	protected void initializeTable() {
		
		ExprValue exprValue = null;
		Word wordEmpty = contextWord.getEmptyWord();
		
		if(isLeading()) {
			exprValue = getExprValueWord(wordEmpty, wordEmpty);
		}else {
			exprValue = getExprValueWord(wordEmpty);
		}
		
		observationTable.clear();
		ObservationRowDFA row = observationTable.addUpperRow(wordEmpty);
		prepareRowDFA(row);
		observationTable.addColumn(exprValue);
		// add every alphabet
		for(int letterNr = 0; letterNr < this.contextWord.getAlphabet().size(); letterNr ++) {
			ObservationRowDFA lowerRow = observationTable.addLowerRow(contextWord.getLetterWord(letterNr));
			prepareRowDFA(lowerRow);
		}
		
		// ask initial queries for upper table
		processMembershipQueries(observationTable.getUpperTable()
				, 0, observationTable.getColumns().size());
		// ask initial queries for lower table
		processMembershipQueries(observationTable.getLowerTable()
				, 0, observationTable.getColumns().size());
		
		makeTableClosed();
		
	}
	
	protected void processMembershipQueries(List<ObservationRow> rows
			, int colOffset, int length) {
		List<Query<HashableValue>> results = new ArrayList<>();
		List<ExprValue> columns = observationTable.getColumns();
		int endNr = length + colOffset;
		for(ObservationRow row : rows) {
			for(int colNr = colOffset; colNr < endNr; colNr ++) {
				results.add(processMembershipQuery(row, colNr, columns.get(colNr)));
			}
		}
		putQueryAnswers(results);
	}
		
	protected void putQueryAnswers(List<Query<HashableValue>> queries) {
		for(Query<HashableValue> query : queries) {
			putQueryAnswers(query);
		}
	}
	
	protected void putQueryAnswers(Query<HashableValue> query) {
		ObservationRow row = query.getPrefixRow();
		HashableValue result = query.getQueryAnswer();
		assert result != null;
		row.set(query.getSuffixColumn(), result);
	}
	
	protected void makeTableClosed() {
		ObservationRowDFA lowerRow = observationTable.getUnclosedLowerRow();
		
		while(lowerRow != null) {
			// 1. move to upper table
			observationTable.moveRowFromLowerToUpper(lowerRow);
			// 2. add one letter to lower table
			List<ObservationRow> newLowerRows = new ArrayList<>();
			for(int letterNr = 0; letterNr < contextWord.getNumLetters(); letterNr ++) {
				Word newWord = lowerRow.getWord().append(letterNr);
				ObservationRow row = observationTable.getTableRow(newWord); // already existing
				if(row != null) continue;
				ObservationRowDFA newRow = observationTable.addLowerRow(newWord);
				prepareRowDFA(newRow);
				newLowerRows.add(newRow);
			}
			// 3. process membership queries
			processMembershipQueries(newLowerRows, 0, observationTable.getColumns().size());
			lowerRow = observationTable.getUnclosedLowerRow();
		}
		
		constructHypothesis();
	}
	
	protected abstract ExprValue getCounterExampleWord(Query<Boolean> query);

    // return counter example for hypothesis
	@Override
	public void refineHypothesis(Query<Boolean> ceQuery) {
		
		ExprValue exprValue = getCounterExampleWord(ceQuery);
		CeAnalyzer analyzer = getCeAnalyzerInstance(exprValue);
		analyzer.analyze();
		observationTable.addColumn(analyzer.getNewColumn()); // add new experiment
		processMembershipQueries(observationTable.getUpperTable(), observationTable.getColumns().size() - 1, 1);
		processMembershipQueries(observationTable.getLowerTable(), observationTable.getColumns().size() - 1, 1);
		
		makeTableClosed();
		
	}
	
	@Override
	public Automaton getHypothesis() {
		return hypothesis;
	}
	
	protected void constructHypothesis() {
		hypothesis = new DFA(contextWord);
		List<ObservationRow> upperTable = observationTable.getUpperTable();
		
		// add states one by one, ordered by the order of occurences
		// and should in a increased order, maybe change this later
		for(int rowNr = 0; rowNr < upperTable.size(); rowNr ++) {
			
			hypothesis.addNewState(rowNr);
			for(int letter = 0; letter < contextWord.getNumLetters(); letter ++) {
				int succ = getSuccessorRow(rowNr, letter);
				hypothesis.addTransition(letter, succ);
			}
			
			if(!isLeading() && isAccepting(rowNr)) {
				hypothesis.setAccepting();
			}
			
			if(upperTable.get(rowNr).getWord().isEmpty()) {
				hypothesis.setInitial();
			}
			hypothesis.addNewStateEnd();
		}
		
	}
	
	// a state is accepting iff it accepts empty language
	private boolean isAccepting(int state) {
		if(isLeading()) return false;
		ObservationRow stateRow = observationTable.getUpperTable().get(state);
		int emptyNr = observationTable.getColumnIndex(getExprValueWord(contextWord.getEmptyWord()));
		assert emptyNr != -1 : "index -> " + emptyNr;
		return stateRow.getValues().get(emptyNr).isAccepting();
	}
	
	protected int getSuccessorRow(int state, int letter) {
		ObservationRow stateRow = observationTable.getUpperTable().get(state);
		Word succWord = stateRow.getWord().append(letter);

		// search in upper table
		for(int succ = 0; succ < observationTable.getUpperTable().size(); succ ++) {
			ObservationRow succRow = observationTable.getUpperTable().get(succ);
			if(succRow.getWord().equals(succWord)) {
				return succ;
			}
		}
		// search in lower table
		ObservationRow succRow = observationTable.getLowerTableRow(succWord);
		assert succRow != null;
		for(int succ = 0; succ < observationTable.getUpperTable().size(); succ ++) {
			ObservationRow upperRow = observationTable.getUpperTable().get(succ);
			if(succRow.valuesEqual(upperRow)) {
				return succ;
			}
		}
		assert false : "successor values not found";
		return -1;
	}

	@Override
	public LearnerType getLearnerType() {
		return LearnerType.DFA_TABLE;
	}
	
	public String toString() {
		return observationTable.toString();
	}
	
	public Word getStateLabel(int state) {
		return observationTable.getUpperTable().get(state).getWord();
	}
	
	protected abstract CeAnalyzer getCeAnalyzerInstance(ExprValue exprValue);
	
	// counter example analysis
	protected abstract class CeAnalyzer {
		protected ExprValue column;
		protected final ExprValue exprValue; 
		
		public CeAnalyzer(ExprValue exprValue) {
			this.exprValue = exprValue;
		}
		
		public abstract void analyze();
		
		public ExprValue getNewColumn() {
			return column;
		}
	
	}
	
	protected ObservationTableDFA getTableInstance(WordManager contextWord) {
		return new ObservationTableDFADefault(contextWord);
	}
	
	protected class ObservationTableDFADefault extends  ObservationTableDFA {

		protected ObservationTableDFADefault(WordManager contextWord) {
			super(contextWord);
		}

		@Override
		public ObservationRowDFA getRowInstance(Word word) {
			return new ObservationRowDefault(word);
		}
	}
	
	protected class ObservationRowDefault extends ObservationRowDFA {

		protected ObservationRowDefault(Word word) {
			super(word);
		}

		@Override
		public void setLeadingState(int state) {			
		}
		
	}

}
