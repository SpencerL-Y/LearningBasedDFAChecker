/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.learner.nlstar;

import cn.ac.ios.automata.words.WordManager;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import cn.ac.ios.automata.words.Word;
import cn.ac.ios.table.ExprValue;

// make new table for NL*
public class ObservationTableNLStar {

	// upper prime rows
	private final List<ObservationRowNLStar> upperRows = new ArrayList<>(); 
	 // all rows in the table
	private final List<ObservationRowNLStar> allRows = new ArrayList<>();  
	
	// to be added upper rows
	private final List<ObservationRowNLStar> newUppers = new ArrayList<>();  
	// to be added new rows
	private final List<ObservationRowNLStar> newRows = new ArrayList<>();   
	
	//  columns for experiments
	private final List<ExprValue> columns = new ArrayList<>(); 
	//  needs to keep them unique since we add all suffixes of ce to columns
	private final Set<ExprValue> columnsSet = new HashSet<>(); 
	
	private final List<ObservationRowNLStar> upperPrimes = new ArrayList<>();
	
	private final WordManager wordManager ;
	
	protected ObservationTableNLStar(WordManager contextWord) {
		assert contextWord != null;
		this.wordManager = contextWord;
	}

}
