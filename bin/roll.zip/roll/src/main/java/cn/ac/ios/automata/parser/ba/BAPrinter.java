package cn.ac.ios.automata.parser.ba;

import java.io.PrintStream;
import java.util.Iterator;
import java.util.Set;

import automata.FAState;
import automata.FiniteAutomaton;
import cn.ac.ios.options.Options;

public class BAPrinter {
	
	public static String printBA(FiniteAutomaton fa) {
		StringBuilder builder = new StringBuilder();
		
		if(Options.dot) {
			builder.append("//Buechi \n");
			builder.append("digraph {\n");
	        
	        Set<FAState> states = fa.states;
	        for (FAState state : states) {
	        	builder.append("  " + state.id + " [label=\"" +  state.id + "\"");
	            if(fa.F.contains(state)) builder.append(", shape = doublecircle");
	            else builder.append(", shape = circle");
	            builder.append("];\n");
	            for (String label : fa.getAllTransitionSymbols()) {
	            	Set<FAState> succs = state.getNext(label);
	            	if(succs == null) continue;
	            	for(FAState succ : succs) {
	            		builder.append("  " + state.id + " -> " + succ.id + " [label=\"" + label + "\"];\n");
	            	}
	            }
	        }	
	        builder.append("  " + states.size() + " [label=\"\", shape = plaintext];\n");
	        FAState initState = fa.getInitialState();
	        builder.append("  " + states.size() + " -> " + initState.id + " [label=\"\"];\n");
	        builder.append("}\n\n");
		}else {
			// first output initial state
			builder.append("[" + fa.getInitialState().id + "]\n");
			// transitions
			for(FAState from : fa.states) {
				Iterator<String> nextIt = from.nextIt();
				while(nextIt.hasNext()) {
					String label = nextIt.next();
					for(FAState to : from.getNext(label)) {
						builder.append(label + "," + "[" + from.id + "]->[" + to.id + "]\n");
					}
				}
			}
			
			for(FAState f : fa.F) {
				builder.append("[" + f.id + "]\n");
			}
		}


		return builder.toString();
	}
	

}
