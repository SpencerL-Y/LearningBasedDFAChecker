package cn.ac.ios.roll;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import automata.FiniteAutomaton;
import cn.ac.ios.automata.parser.Parser;
import cn.ac.ios.automata.parser.UtilParser;
import cn.ac.ios.automata.parser.ba.BAPrinter;
import cn.ac.ios.options.Options;
import cn.ac.ios.options.UtilOptions;
import cn.ac.ios.roll.test.AutomatonGenerator;
import cn.ac.ios.util.Timer;

/**
 * Regular Omega Language Learning Library
 * 
 * @author Yong Li
 * */
public class ROLL {
	
	
	public static void main(String[] args) {
		// prepare the options
		UtilOptions.prepareOptions(args);
		// select mode to execute
		if(Options.modeTest) {
			runTestMode();
		}else if(Options.modeInteractive) {
			runInteractiveMode();
		}else if(Options.modeAutomatic) {
			runAutomaticMode();
		}else {
			Options.log.err("Incorrect running mode.");
		}
		
	}
	
	private static void runTestMode() {
		
		for(int n = 0; n < Options.numTests; n ++) {
			FiniteAutomaton aut = AutomatonGenerator.getRandomAutomaton(Options.numStatesForTest, 3);
			Statistics.target = aut;
			try{
				AutoExecution.execute(aut);
			}catch (Exception e)
			{
				e.printStackTrace();
				Options.log.err("Exception occured, Learning aborted...");
				aut.saveAutomaton("bug-test.ba");
				System.exit(-1);
			}
			Options.log.print(BAPrinter.printBA(Statistics.hypothesis));
			Options.log.info("Done for case " + (n + 1));
		}
	}
	
	private static void runInteractiveMode() {
		PlayExecution.execute();
	}
	
	private static void runAutomaticMode() {
		Statistics.reset();
		
		Timer timer = new Timer();
		timer.start();
		// prepare the parser
		Parser parser = UtilParser.prepare(Options.inputFile, Options.formatType);
		FiniteAutomaton target = parser.parse();
		Statistics.target = target;
		
		// learn the target automaton
		AutoExecution.execute(target);
		
		timer.stop();
		Statistics.timeTotal = timer.getTimeElapsed();
		// output target automaton
		if(Options.outputFile != null) {
			try {
				parser.print(Statistics.hypothesis, new FileOutputStream(new File(Options.outputFile)));
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else {
			Options.log.println("target automaton:");
			parser.print(Statistics.target, Options.log.getOutputStream());
			Options.log.println("hypothesis automaton:");
			parser.print(Statistics.hypothesis, Options.log.getOutputStream());
		}
		parser.close();

		// output statistics
		Statistics.print();
		
	}

}
