package cn.ac.ios.options;

import cn.ac.ios.automata.parser.FormatType;
import cn.ac.ios.log.Log;

public final class UtilOptions {
	
	public static void prepareOptions(String []args) {
		
		Options.log = new Log(System.out);
		
    	// parse input arguments
    	for(int i = 0; i < args.length; i ++) {
    		if(args[i].compareTo("-h")==0) {
    			printUsage();
    		}
    	}
    	
    	if(args.length < 2) {
    		printUsage();
    	}

    	// for learning;
    	for(int i = 0; i < args.length; i ++) {
    		if(args[i].compareTo("-aut") == 0) {
    			Options.modeInteractive = false;
    			Options.modeAutomatic = true;
    			Options.teacherSampling = false;
    			continue;
    		}
    		if(args[i].compareTo("-int") == 0) {
    			Options.modeInteractive = true;
    			Options.modeAutomatic = false;
    			Options.teacherSampling = false;
    			continue;
    		}
			
			if(args[i].compareTo("-sameq") == 0) {
				Options.teacherSampling = true;
    			Options.modeInteractive = false;
    			Options.modeAutomatic = true;
    			Options.epsilon = Double.parseDouble(args[i+1]);
    			Options.delta = Double.parseDouble(args[i+2]);
    			i += 2;
    			continue;
			}
			
			if(args[i].compareTo("-v")==0){
				Options.verbose=true;
				continue;
			}
			
			if(args[i].compareTo("-out")==0){
				Options.outputFile = args[i+1];
				i += 1;
				continue;
			}
			
			if(args[i].compareTo("-table") == 0) {
    			Options.learnerTree = false;
    			Options.learnerTable = true;
    			continue;
			}
			if(args[i].compareTo("-tree") == 0) {
    			Options.learnerTree = true;
    			Options.learnerTable = false;
    			continue;
			}
			if(args[i].compareTo("-lstar") == 0) {
				Options.learnerLStar = true;
				Options.learnerMultiplicity = false;
				Options.learnerDFA = false;
				Options.learnerNFA = false;
				Options.learnerLDollar = false;
				Options.learnerPeriodic = false;
				Options.learnerRecurrent = false;
				Options.learnerSyntactic = false;
				Options.lazyEqCheck = false;
				continue;
			}
			if(args[i].compareTo("-dfa") == 0) {
				Options.learnerDFA = true;
				Options.learnerLStar = false;
				Options.learnerMultiplicity = false;
				Options.learnerNFA = false;
				Options.learnerLDollar = false;
				Options.learnerPeriodic = false;
				Options.learnerRecurrent = false;
				Options.learnerSyntactic = false;
				Options.lazyEqCheck = false;
				continue;
			}
			if(args[i].compareTo("-ldollar") == 0) {
				Options.learnerLStar = false;
				Options.learnerMultiplicity = false;
				Options.learnerNFA = false;
				Options.learnerDFA = false;
				Options.learnerLDollar = true;
				Options.learnerPeriodic = false;
				Options.learnerRecurrent = false;
				Options.learnerSyntactic = false;
				continue;
			}
			if(args[i].compareTo("-syntactic") == 0) {
				Options.learnerLStar = false;
				Options.learnerMultiplicity = false;
				Options.learnerNFA = false;
				Options.learnerDFA = false;
				Options.learnerLDollar = false;
				Options.learnerPeriodic = false;
				Options.learnerRecurrent = false;
				Options.learnerSyntactic = true;
				continue;
			}
			if(args[i].compareTo("-recurrent") == 0) {
				Options.learnerLStar = false;
				Options.learnerMultiplicity = false;
				Options.learnerDFA = false;
				Options.learnerNFA = false;
				Options.learnerLDollar = false;
				Options.learnerPeriodic = false;
				Options.learnerRecurrent = true;
				Options.learnerSyntactic = false;
				continue;
			}
			if(args[i].compareTo("-periodic") == 0) {
				Options.learnerLStar = false;
				Options.learnerMultiplicity = false;
				Options.learnerDFA = false;
				Options.learnerNFA = false;
				Options.learnerLDollar = false;
				Options.learnerPeriodic = true;
				Options.learnerRecurrent = false;
				Options.learnerSyntactic = false;
				continue;
			}
			
			if(args[i].compareTo("-under") == 0) {
				Options.buechiBuildUnder = true;
				continue;
			}
			if(args[i].compareTo("-sim") == 0) {
				Options.simulationNFA = true;
				continue;
			}
			
			if(args[i].compareTo("-min") == 0) {
				Options.minimizationBuechi = true;
				continue;
			}
			
			if(args[i].compareTo("-over") == 0) {
				Options.buechiBuildUnder = false;
				Options.outLDBA = false;
				continue;
			}

			
			if(args[i].compareTo("-lazyeq") == 0) {
				Options.lazyEqCheck = true;
				continue;
			}

			
			if(args[i].compareTo("-samfdfa") == 0) {
				Options.sampleFdfa = true;
				continue;
			}
			
			if(args[i].compareTo("-ldba") == 0) {
				Options.outLDBA = true;
				continue;
			}
			
			if(args[i].compareTo("-dot") == 0) {
				Options.dot = true;
				continue;
			}
			
			if(args[i].endsWith(".ba")) {
				Options.inputFile = args[i];
				Options.formatType = FormatType.BA;
				continue;
			}
			
			if(args[i].endsWith(".hoa")) {
				Options.inputFile = args[i];
				Options.formatType = FormatType.HOA;
				continue;
			}
			
			if(args[i].compareTo("-test") == 0) {
				Options.modeAutomatic = false;
				Options.modeInteractive = false;
				Options.modeTest = true;
				Options.numTests = Integer.parseInt(args[i+1]);
				Options.numStatesForTest = Integer.parseInt(args[i + 2]);
				i += 2;
				continue;
			}
    	}
    	
    	
    	
	}
	
	
	// private constructor
	private UtilOptions() {
		
	}
	
	
	private static void printUsage() {
		Options.log.println(
				"ROLL v1 (Regular Omega Language Learning) library");
		Options.log.println(
				"Usage: java -jar ROLL.jar [aut.ba, aut.hoa] [options]");

		Options.log.println("Recommended use: java -jar ROLL.jar -int -lstar");
		Options.log.println("             or: java -jar ROLL.jar aut.ba -aut -table -periodic -under");
		Options.log.println("             or: java -jar ROLL.jar aut.hoa -aut -table -periodic -under");
		Options.log.println("             or: java -jar ROLL.jar -test 3 3 -table -periodic -under");
		Options.log.println("\nOptions:");
		Options.log.println("	-h: Show this page.");
		Options.log.println("	-v: Verbose mode.");
		Options.log.println("	-out filename: Output learned automaton in filename.");
		Options.log.println("	-dot: Output automaton in DOT format.");
		Options.log.println(
				"	-test k n: Test ROLL with k randomly generated Buechi automata of n states.");
		Options.log.println(
				"	-int: Play ROLL in an interactive way, you play the role as a teacher.");
		Options.log.println(
				"	-aut: Use RABIT or DK package tool as the teacher. ");
		Options.log.println(
				"	-sameq e d: Sampling as the teacher to check equivalence of two BA automata.\n"
				+ "               e - the probability that equivalence check is not correct\n"
				+ "               d - the probability of the confidence for equivalence check");
		Options.log.println(
				"	-tree: Use tree-based data structure in the algorithm (Default).");
		Options.log.println(
				"	-table: Use table-based data structure in the algorithm.");
		Options.log.println(
				"	-lstar: Use classic L* algorithm.");
		Options.log.println(
				"	-dfa: Use column based DFA learning algorithm.");
		Options.log.println(
				"	-ldollar:  Use CNP algorithm and L$ automata to learn Omega regular language.");
		Options.log.println(
				"	-periodic: Use peridoc FDFA to learn Omega regular language.");
		Options.log.println(
				"	-recurrent: Use recurrent FDFA to learn Omega regular language.");
		Options.log.println(
				"	-syntactic: Use syntactic FDFA to learn Omega regular language.");
		Options.log.println(
				"	-over: Use over Buechi automaton construction for FDFA. (Default)");
		Options.log.println(
				"	-under: Use under Buechi automaton construction for FDFA.");
//		Options.log.println(
//				"-samfdfa: Sampling the FDFA before equivalence check. (Not yet supported)");
		Options.log.println(
				"	-sim: Use Similation provided by RABIT to reduce automata before intersection of DFAs.");
		Options.log.println(
				"	-min: Use Minimization provided by RABIT to reduce Buechi automata before equivalence check.");
		Options.log.println(
				"	-lazyeq: Equivalence check as the last resort. ");
		Options.log.println(
				"	-ldba: Output the final Buechi as Limit Deterministic Buechi Automaton (with -under). ");
		System.exit(0);
	}
}
