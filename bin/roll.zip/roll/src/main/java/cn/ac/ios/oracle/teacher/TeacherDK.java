/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.oracle.teacher;

import algorithms.Options;
import automata.FiniteAutomaton;
import cn.ac.ios.automata.words.Alphabet;
import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.automata.words.Word;
import cn.ac.ios.query.Query;
import cn.ac.ios.query.QuerySimple;
import cn.ac.ios.roll.Statistics;
import cn.ac.ios.util.Timer;
import cn.ac.ios.util.UtilAutomaton;
import cn.ac.ios.value.ValueManager;
import cn.ac.ios.value.Type;
import cn.ac.ios.value.Value;
import dk.brics.automaton.Automaton;
import dk.brics.automaton.BasicOperations;
import oracle.EqResult;

// currently only for NFA and DFA
// TODO
public class TeacherDK implements Teacher<FiniteAutomaton, EqResult, Boolean> {

	private final WordManager contextWord;
	private final Automaton automaton;
	
	public TeacherDK(WordManager contextWord, FiniteAutomaton targetAut) {
		assert contextWord != null && targetAut != null;
		this.contextWord = contextWord;
		// initialize alphabet
		ValueManager contextValue = contextWord.getContextValue();
		Type typeString = contextValue.newTypeLetter(String.class);
		Value valueLetter = typeString.newValue();
		Alphabet alphabet = contextWord.getAlphabet();
		for(String letter : targetAut.alphabet) {
			valueLetter.set(letter);
			alphabet.add(valueLetter.clone());
		}
		alphabet.setImmutable();
		valueLetter.set("");
	    contextWord.setLetterSplitter(valueLetter);
	    automaton = UtilAutomaton.convertToDkAutomaton(targetAut);
	    automaton.determinize();
	}
	
	@Override
	public Boolean answerMembershipQuery(Query<Boolean> query) {
        Timer timer = new Timer();
        timer.start();
        
		Word word = query.getQueriedWord();
		String strWord = word.toStringExact();
		boolean result = BasicOperations.run(automaton, strWord);
		
		timer.stop();
		Statistics.timeMembershipQuery += timer.getTimeElapsed();
		++ Statistics.numMembershipQuery; 
		return result;
	}

	@Override
	public Query<EqResult> answerEquivalenceQuery(FiniteAutomaton aut) {
		System.out.println("Resloving equivalence check by DK...");
		Timer timer = new Timer();
		timer.start();
		Automaton dkAut = UtilAutomaton.convertToDkAutomaton(aut);
		Automaton autInter = dkAut.clone().minus(automaton.clone());
		String counterexample = autInter.getShortestExample(true);
		EqResult result = new EqResult();
		Query<EqResult> query = null;
		Word prefix = contextWord.getEmptyWord();
		
		if(counterexample != null) {
			result.isCeInTarget = false;
			result.isEqual = false;
			prefix = contextWord.getWordFromString(counterexample);
		}else {
			autInter = automaton.clone().minus(dkAut);
			counterexample = autInter.getShortestExample(true);
			if(counterexample != null) {
				result.isCeInTarget = true;
				result.isEqual = false;
				prefix = contextWord.getWordFromString(counterexample);
			}else {
				result.isCeInTarget = false;
				result.isEqual = true;
			}
		}
		
		query = new QuerySimple<>(prefix, contextWord.getEmptyWord());
        query.answerQuery(result);
		timer.stop();
		Statistics.timeEquivalenceQuery += timer.getTimeElapsed();
		++ Statistics.numEquivalenceQuery;
		System.out.println("Done for equivalence check by DK...");
		if(Options.verbose) System.out.println("dk counter example = " + query);
		return query;
	}

}
