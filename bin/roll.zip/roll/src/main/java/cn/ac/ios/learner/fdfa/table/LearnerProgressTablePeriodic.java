/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.learner.fdfa.table;

import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.automata.words.Word;
import cn.ac.ios.learner.fdfa.LearnerLeading;
import cn.ac.ios.query.MembershipOracle;
import cn.ac.ios.query.Query;
import cn.ac.ios.table.ExprValue;
import cn.ac.ios.table.HashableValue;
import cn.ac.ios.table.ObservationRow;

public class LearnerProgressTablePeriodic extends LearnerProgressTable {

	public LearnerProgressTablePeriodic(WordManager contextWord
			, MembershipOracle<Boolean> membershipOracle
			, Word label) {
		super(contextWord, membershipOracle, label);
	}


	@Override
	protected Query<HashableValue> processMembershipQuery(ObservationRow row, int offset, ExprValue valueExpr) {
		Word suffix = row.getWord();
		Word expr = valueExpr.get();
		suffix = suffix.concat(expr);
		boolean result = processMembershipQuery(row, label, suffix, offset);
		Query<HashableValue> query = getQuerySimple(row, label, suffix, offset);
		query.answerQuery(getHashableValueBoolean(result));
		return query;
	}
	
	public void setLearnerLeading(LearnerLeading learnerLeading) {
	}

}
