/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.learner.fdfa.tree;


import java.util.Collections;
import java.util.List;

import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.automata.words.Word;
import cn.ac.ios.learner.fdfa.LearnerLeading;
import cn.ac.ios.query.MembershipOracle;
import cn.ac.ios.query.Query;
import cn.ac.ios.table.ExprValue;
import cn.ac.ios.table.ExprValueWordPair;

public class LearnerLeadingTree extends LearnerOmegaTree implements LearnerLeading {

	public LearnerLeadingTree(WordManager contextWord, MembershipOracle<Boolean> membershipOracle) {
		super(contextWord, membershipOracle);
	}

	@Override
	public boolean isLeading() {
		return true;
	}

	@Override
	protected boolean processMembershipQuery(Word label, ExprValue valueExpr) {
		assert valueExpr instanceof ExprValueWordPair;
		ExprValueWordPair valueExprPair = (ExprValueWordPair) valueExpr;
		return processMembershipQuery(label.concat(valueExprPair.getLeft()), valueExprPair.getRight());
	}

	@Override
	protected ExprValue getCounterExampleWord(Query<Boolean> query) {
		isCEAccepting = query.getQueryAnswer();
		return this.getExprValueWord(query.getPrefix(), query.getSuffix());
	}

	// already normalized counterexample
	@Override
	protected CeAnalyzer getCeAnalyzerInstance(ExprValue exprValue) {
		return new CeAnalyzerTree(exprValue);
	}
	
	private class CeAnalyzerTree extends CeAnalyzer {

		public CeAnalyzerTree(ExprValue ce) {
			super(ce);
		}

		@Override
		public void analyze() {		
			this.leafBranch = getHashableValueBoolean(isCEAccepting);
			this.nodePrevBranch = getHashableValueBoolean(!isCEAccepting);
			// only has one leaf
			if(tree.getRoot().isLeaf()) {
				this.wordExpr = getExprValueWord(contextWord.getEmptyWord(), this.exprValue.getRight());
				this.nodePrev = tree.getRoot();
				this.wordLeaf = getExprValueWord(exprValue.getLeft());
				stateNew = exprValue.getLeft();
				return ;
			}
			
			Word wordCE = this.exprValue.getLeft();
			// get the initial state from automaton
		    int letterNr = 0, stateCurr = -1, statePrev = getInitState();
			// starting state is lambda
			for(; letterNr < wordCE.length(); letterNr ++) {
				stateCurr = computeNextState(statePrev, wordCE.getLetter(letterNr));
				Word prefix = states.get(stateCurr).label;   // S(j)
				prefix = prefix.concat(wordCE.getSuffix(letterNr + 1)); // S(j) x[j+1...n]
				Word suffix = exprValue.getRight();
				boolean resultCurr = processMembershipQuery(prefix, suffix); // (Sj x[j+1..n], y)
				if(isCEAccepting != resultCurr) {
					break;
				}
				statePrev = stateCurr;                    // record S(j)
			}
			Word wordPrev = states.get(statePrev).label;         // S(j-1)
			Word wordPrefix = wordCE.getSuffix(letterNr + 1);    // x[j+1...n]
			Word wordSuffix = exprValue.getRight();              // y
			this.wordExpr = getExprValueWord(wordPrefix, wordSuffix);  // (x[j+1..n], y)
			this.wordLeaf = getExprValueWord(wordPrev.append(wordCE.getLetter(letterNr))); // S(j-1)x[j]
			this.nodePrev = states.get(stateCurr).node;          // S(j)
			stateNew = wordPrev.append(wordCE.getLetter(letterNr));
		}
		
	}

	private Word stateNew;
	
	@Override
	public List<Word> getNewStates() {
		return Collections.singletonList(stateNew);
	}

}
