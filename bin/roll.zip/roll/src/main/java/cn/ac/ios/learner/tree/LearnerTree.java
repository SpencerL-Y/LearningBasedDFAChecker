/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.learner.tree;

import java.util.ArrayList;
import java.util.BitSet;
import java.util.List;

import cn.ac.ios.automata.Automaton;
import cn.ac.ios.automata.DFA;
import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.automata.words.Word;
import cn.ac.ios.learner.Learner;
import cn.ac.ios.learner.LearnerType;
import cn.ac.ios.learner.fdfa.LearnerGeneral;
import cn.ac.ios.query.MembershipOracle;
import cn.ac.ios.query.Query;
import cn.ac.ios.table.ExprValue;
import cn.ac.ios.table.ExprValueWord;
import cn.ac.ios.table.ExprValueWordPair;
import cn.ac.ios.table.HashableValue;
import cn.ac.ios.table.HashableValueBoolean;

import cn.ac.ios.tree.Node;
import gnu.trove.iterator.TIntObjectIterator;

/**
 * Learner based on Classification tree
 * */
public abstract class LearnerTree implements LearnerGeneral {

	protected WordManager contextWord;
	protected MembershipOracle<Boolean> membershipOracle;
	protected TreeImpl tree;
	private boolean alreadyStarted = false;
	protected Automaton hypothesis;
	
	public LearnerTree(WordManager contextWord,
			MembershipOracle<Boolean> membershipOracle) {
		assert contextWord != null && membershipOracle != null;
		this.contextWord = contextWord;
		this.membershipOracle = membershipOracle;
	}
	
	@Override
	public LearnerType getLearnerType() {
		return LearnerType.DFA_TREE;
	}
	
	public abstract boolean isOmegaLearning();
	
	public abstract boolean isLeading();

	@Override
	public void startLearning() {
		if(alreadyStarted)
			try {
				throw new Exception("Learner should not be started twice");
			} catch (Exception e) {
				e.printStackTrace();
			}
		alreadyStarted = true;
		initializeTree();
	}

	protected void initializeTree() {
		
		Word wordEmpty = contextWord.getEmptyWord();
		ExprValue label = getExprValueWord(wordEmpty);
		Node<ValueNode> root = getValueNode(null, null, label);  
		tree = new TreeImpl(root);
		tree.setLamdaLeaf(root);
		boolean isAccepting = false;
		
		if(isOmegaLearning())  {
			if(! isLeading()) {
				isAccepting = processMembershipQuery(wordEmpty, getExprValueWord(wordEmpty));
			}
		}else {
			isAccepting = processMembershipQuery(wordEmpty, wordEmpty);
		}
		
		if(isAccepting) {
			root.setAcceting();
		}
		states.clear();
		ValueNode stateLamda = new ValueNode(states.size(), wordEmpty);
		states.add(stateLamda);    // add it to states list
		stateLamda.node = root;    // relate to node
		root.setValue(stateLamda); // update node value
		
		updateSuccessors(stateLamda.id, 0, contextWord.getNumLetters() - 1);
		nodeToSplit = null;
		constructHypothesis();
	}

	protected abstract boolean processMembershipQuery(Word label, ExprValue valueExpr); // for leading
	protected abstract boolean processMembershipQuery(ExprValue valueExpr);  // for progress
	protected abstract boolean processMembershipQuery(Word row, Word column); // for regular
	

	protected Node<ValueNode> nodeToSplit;
	
	@Override
	public Automaton getHypothesis() {
		return hypothesis;
	}
	
	protected void constructHypothesis() {

		// construct hypothesis according to KV tree
		if (nodeToSplit != null) {
			updatePredecessors();
		}
		
		hypothesis = new DFA(contextWord);
		
		for(ValueNode state : states) {
			hypothesis.addNewState(state.id);
			for(int letter = 0; letter < contextWord.getNumLetters(); letter ++) {
				hypothesis.addTransition(letter, state.getSuccessor(letter));
			}
			if(state.node.isAccepting()) {
				hypothesis.setAccepting();
			}
			if(state.label.isEmpty()) {
				hypothesis.setInitial();
			}
			hypothesis.addNewStateEnd();
		}

	}
	
	// needs to check , s <- a - t then t has a successor s 
	protected void updatePredecessors() {
		
		TIntObjectIterator<BitSet> iterator = nodeToSplit.getValue().predecessors.iterator();
		Node<ValueNode> parent = nodeToSplit.getParent();
		BitSet letterDeleted = new BitSet();
		while(iterator.hasNext()) {
			iterator.advance();
			int letter = iterator.key();
			BitSet statePrevs = iterator.value();
			BitSet stateLeft = (BitSet) statePrevs.clone();
			for(int stateNr = statePrevs.nextSetBit(0)
					; stateNr >= 0
					; stateNr = statePrevs.nextSetBit(stateNr + 1)) {
				ValueNode statePrev = states.get(stateNr);
				Node<ValueNode> nodeOther = sift(statePrev.label.append(letter), parent);
				if (nodeOther != nodeToSplit) {
					updateTransition(stateNr, letter, nodeOther.getValue().id);
					stateLeft.clear(stateNr);
				}
			}
			if(stateLeft.isEmpty()) {
				letterDeleted.set(letter);
			}else {
				iterator.setValue(stateLeft);
			}
		}
		
		for(int letter = letterDeleted.nextSetBit(0)
				; letter >= 0
				; letter = letterDeleted.nextSetBit(letter + 1)) {
			nodeToSplit.getValue().predecessors.remove(letter);
		}
		
	}
	
	/**
	 * For regular language, just return counterexample word
	 * For Omega language:
	 *    1> leading automaton , will be a pair (x, y)
	 *    2> progress automaton , will be a counterexample word
	 **/
	protected abstract ExprValue getCounterExampleWord(Query<Boolean> query);

	@Override
	public void refineHypothesis(Query<Boolean> query) {
		ExprValue wordCE = getCounterExampleWord(query);
	    nodeToSplit = updateTree(wordCE);
	    constructHypothesis();
	}

	
	protected Node<ValueNode> getValueNode(Node<ValueNode> parent, HashableValue branch, ExprValue label) {
		return new NodeImpl(parent, branch, label);
	}
	
	// updates for tree
    protected List<ValueNode> states = new ArrayList<>();
    
	// get corresponding 
    protected Node<ValueNode> sift(Word word) {
 		return sift(word, tree.getRoot());
	}
	
	protected Node<ValueNode> sift(Word word, Node<ValueNode> nodeCurr) {
		while(! nodeCurr.isLeaf()) {
			ExprValue exprValue = nodeCurr.getLabel();
			boolean result = processMembershipQuery(word, exprValue);
			nodeCurr = nodeCurr.getChild(getHashableValueBoolean(result));
		}
		return nodeCurr;
	}

	// word will never be empty word
	protected Node<ValueNode> updateTree(ExprValue exprValue) { 
		
		CeAnalyzer analyzer = getCeAnalyzerInstance(exprValue);
		analyzer.analyze();
		
		// replace nodePrev with new experiment node nodeExpr 
		// and two child r[1..length-1] and nodePrev
		
		ExprValue wordExpr = analyzer.getNodeExpr();
		Node<ValueNode> nodePrev = analyzer.getNodeToSplit();
		Node<ValueNode> parent = nodePrev.getParent();
		
		// new experiment word
		boolean rootChanged = false;
		Node<ValueNode> nodeExpr = getValueNode(parent, nodePrev.fromBranch(), wordExpr); // replace nodePrev
		if(parent != null) {
			parent.addChild(nodePrev.fromBranch(), nodeExpr);
		}else { // became root node
			tree = new TreeImpl(nodeExpr);
			rootChanged = true;
		}
		
		// state for r[1..length-1]
		HashableValue branchNodeLeaf = analyzer.getLeafBranch();
		HashableValue branchNodePrev = analyzer.getNodeSplitBranch();
		Node<ValueNode> nodeLeaf = getValueNode(nodeExpr, branchNodeLeaf, analyzer.getNodeLeaf());
		ValueNode stateLeaf =  new ValueNode(states.size(), analyzer.getNodeLeaf().get());
		stateLeaf.node = nodeLeaf;
		nodeLeaf.setValue(stateLeaf);
		states.add(stateLeaf); // add new state
		
		Node<ValueNode> nodePrevNew = getValueNode(nodeExpr, branchNodePrev, nodePrev.getLabel());
		nodePrevNew.setValue(nodePrev.getValue()); // To update
		nodePrevNew.getValue().node = nodePrevNew; // update node
		
		nodeExpr.addChild(branchNodeLeaf, nodeLeaf);
		nodeExpr.addChild(branchNodePrev, nodePrevNew);
		
		// update outgoing transitions for nodeLeaf
		updateSuccessors(stateLeaf.id, 0, contextWord.getNumLetters() - 1);
				
		// needs to be changed
		if(rootChanged) {
			if(!isLeading()) {
				if(! nodePrev.isAccepting()) nodeLeaf.setAcceting();
				else nodePrevNew.setAcceting();
			}
		}else {
			if(nodePrev.isAccepting()) {
				nodeLeaf.setAcceting();
				nodePrevNew.setAcceting();
			}
		}

		
		Word wordNodePrev = nodePrevNew.getLabel().get();
		if(wordNodePrev.isEmpty()) {
			tree.setLamdaLeaf(nodePrevNew);
		}
		
		return nodePrevNew;
	}
	
	protected void updateSuccessors(int stateNr, int letterFrom, int letterTo) {
		assert stateNr < states.size() 
	    && letterFrom >= 0
	    && letterTo < contextWord.getNumLetters();
		
		ValueNode state = states.get(stateNr);
		
		Word label = state.label;
		for(int letter = letterFrom; letter <= letterTo; letter ++) {
			Word wordSucc = label.append(letter);
			Node<ValueNode> nodeSucc = sift(wordSucc);
			updateTransition(stateNr, letter, nodeSucc.getValue().id);
		}
		
	}
	
	protected void updateTransition(int from, int letter, int to) {
		assert from < states.size() 
		    && to < states.size() 
		    && letter < contextWord.getNumLetters();
		
		states.get(from).addSuccessor(letter, to);
		states.get(to).addPredecessor(from, letter);
	}
	
	protected abstract CeAnalyzer getCeAnalyzerInstance(ExprValue exprValue);
	
	// analyze counterexample
	protected abstract class CeAnalyzer {
		
		protected final ExprValue exprValue; 
		protected Node<ValueNode> nodePrev = tree.getLamdaLeaf();
		protected ExprValue wordExpr;
		protected ExprValue wordLeaf;
		protected HashableValue leafBranch;
		protected HashableValue nodePrevBranch;
		
		
		public CeAnalyzer(ExprValue ce) {
			this.exprValue = ce;
		}
		
		// find prefix whose successor needs to be added
		public abstract void analyze();
		
		public ExprValue getNodeLeaf() {
			return wordLeaf;
		}
		
		public ExprValue getNodeExpr() {
			return wordExpr;
		}
		
		public Node<ValueNode> getNodeToSplit() {
			return nodePrev;
		}
		
		public HashableValue getLeafBranch() {
			return leafBranch;
		}
		
		public HashableValue getNodeSplitBranch() {
			return nodePrevBranch;
		}
		
	}
	
	public String toString() {
		return tree.toString();
	}
	
	
	public Word getStateLabel(int state) {
		return states.get(state).label;
	}

}
