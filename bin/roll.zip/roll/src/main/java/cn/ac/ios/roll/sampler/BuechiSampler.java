/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.roll.sampler;

import java.util.ArrayList;
import java.util.BitSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

import automata.FAState;
import automata.FiniteAutomaton;
import cn.ac.ios.util.Pair;

public class BuechiSampler {
	
	// in this function, we start at the initial state and 
	// pick every successor with
	// equal probability until we reach a final state and a lasso
	private static Map<Integer, Integer> sMap = null;
			
	public static Pair<List<String>, List<String>> sampleUniform(FiniteAutomaton aut) {
		f = null;
		sMap = new HashMap<>();
		FAState curr = aut.getInitialState();
		
		List<String> prefix = new ArrayList<>();
		List<String> suffix = new ArrayList<>();
		List<String> word = new ArrayList<>();
		while(true) {
			
			List<String> temp = sampleOnePath(curr, aut.F);
			// add current word
			for(String lab : temp ) {
				word.add(lab);
			}
			
			// if current final state has been visited before
			if (sMap.containsKey(f.id)) {
				break;
			}
			
			// else this final state has not been visited yet
			// record the index of label to the final state
			sMap.put(f.id, word.size() - 1);

			curr = f;

		}
		
		int labelNr = sMap.get(f.id);
		for(int n = 0; n <= labelNr ; n ++) {
			prefix.add(word.get(n));
		}
		for(int n = labelNr + 1; n < word.size(); n ++) {
			suffix.add(word.get(n));
		}
		
		return new Pair<>(prefix, suffix);
	}
	
	
	// sample a path from s to a state t in ts uniformly
	public static List<String> sampleOnePath(FAState s, Set<FAState> ts) {
		
		List<String> path = new ArrayList<>();
		
		FAState curr = s;
		
		while(true) {
			// go to a final state and the length of path is at least one
			if(ts.contains(curr) && path.size() > 0) break;
			Pair<String, FAState> next = pickNextState(curr);
			curr = next.getRight();
			path.add(next.getLeft());
			
		}
		
		f = curr;
		
		return path;
	}
	
	private static FAState f; // the final state
	
	private static Pair<String, FAState> pickNextState(FAState s) {
		
		//uniformly pick the successor
		List<FAState> sNext = new ArrayList<>();
		Iterator<FAState> iter = s.getNext().iterator();
		while(iter.hasNext()) {
			sNext.add(iter.next());
		}
		
		// pick a state randomly
		int sNr = ThreadLocalRandom.current().nextInt(0, sNext.size());
		FAState succ = sNext.get(sNr);
		
		String label = null;
		
		Iterator<String> preIt = succ.preIt();
		while(preIt.hasNext()) {
			label = preIt.next();
			if(succ.getPre(label).contains(s)) {
				break;
			}
		}
		
		return new Pair<>(label, succ);
	}
	
	// make sure that all SCCs that can not reach final states are deleted
	// this is a sample method which produces shorter paths on average
	public static Pair<List<String>, List<String>> samplePath(FiniteAutomaton aut) {
		
		boolean fVisited = false;
		BitSet visited = new BitSet(aut.states.size()); // all states visited
		BitSet fins = new BitSet(); // final states visited
		FAState curr = aut.getInitialState();
		// record the first label index of state id
		Map<Integer, Integer> sMap = new HashMap<>(); 
		List<String> word = new ArrayList<>();     // the omega word 
		List<Integer> states = new ArrayList<>(); // the corresponding run
		int prefixEndNr = -1;
		visited.set(curr.id);
		states.add(curr.id);
		sMap.put(curr.id, -1);  // initial state has prefix -1
		if(aut.F.contains(curr)) fins.set(curr.id);
		while(true) {
			
			Pair<String, FAState> pair = pickNextState(curr);
			FAState s = pair.getRight();
			word.add(pair.getLeft());
			states.add(s.id);
			// this state is a final state
			if(aut.F.contains(s)) {
				//check whether it has already been visited
				fVisited = true;
				fins.set(s.id);
				if(sMap.get(s.id) != null) {
					prefixEndNr = sMap.get(s.id);
					break;
				}
			}
			// we already have visited s and a final state in the loop
			if(visited.get(s.id) && fVisited) {
				// now check whether the loop contains final state
				int index = sMap.get(s.id);
				boolean found = false;
				for(FAState fs : aut.F) {
					Integer n = sMap.get(fs.id);
					if(n != null && n.intValue() >= index) {
						found = true;
						break;
					}
				}
				
				if(found) {
					prefixEndNr = sMap.get(s.id);
					break;
				}
			}
			// record current index
			// for regular states, just keep the first appearance
			if(! sMap.containsKey(s.id)) sMap.put(s.id, word.size() - 1);
			visited.set(s.id);
			curr = s;
		}
		
		// now we compute whether there exists shorter loop
		// s --- s --- s -- f1 -- s
		// sometimes, this could reduce the length of the loop considerably
		int sRepeat = states.get(prefixEndNr + 1);
		// if it is not a final state
		if(! fins.get(sRepeat)) {
			int n = states.size() - 2;
			boolean foundF = false;
			while(n >= prefixEndNr + 1) {
				if(foundF && (states.get(n) == sRepeat)) {
					prefixEndNr = n - 1;
					break;
				}
				// either is not sRepeat or no final states
				if(fins.get(states.get(n))) foundF = true;
				n --;
			}
		}
		
		// compute the ultimate periodic word (u, v)
		List<String> prefix = new ArrayList<>();
		List<String> suffix = new ArrayList<>();
		
		for(int n = 0; n <= prefixEndNr ; n ++) {
			prefix.add(word.get(n));
		}
		
		for(int n = prefixEndNr + 1; n < word.size(); n ++) {
			suffix.add(word.get(n));
		}
		
		return new Pair<>(prefix, suffix);
	}

}
