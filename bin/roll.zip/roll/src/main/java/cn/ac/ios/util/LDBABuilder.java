/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.util;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Set;

import dk.brics.automaton.Automaton;
import dk.brics.automaton.State;
import dk.brics.automaton.StatePair;
import dk.brics.automaton.Transition;
import gnu.trove.map.TObjectIntMap;
import gnu.trove.map.hash.TObjectIntHashMap;

public class LDBABuilder {
	
	private Automaton aut;
	
	public LDBABuilder(Automaton aut) {
		this.aut = aut;
	}

	// build buechi for a given DFA, which has only one accepting state
	// and L(aut) = N sucht that N+ = N
	public Automaton buildBuechi() {
		aut.removeDeadTransitions();
		Set<State> accs = aut.getAcceptStates();
		if(accs.size() != 1) {
			System.err.println("Not one accepting state");
			System.exit(-1);
		}
		TObjectIntMap<State> map = new TObjectIntHashMap<>();
		int num = 0;
		for(State s : aut.getStates()) {
			map.put(s, num);
			num ++;
		}
		// state q is -1 * n + q , (p, q) is p * n + q, while <q> is (n+1)* n + q
		State acc = accs.iterator().next();
		State init = aut.getInitialState();
		LinkedList<SPair> worklist = new LinkedList<SPair>();
		Automaton c = new Automaton();
		HashMap<SPair, State> mapc = new HashMap<>();
		SPair sip = new SPair(init, null, map);
		worklist.add(sip);
		
		State initc = new State();
		mapc.put(sip, initc);
		c.setInitialState(initc);
		
		while(worklist.size() > 0) {
			SPair w = worklist.removeFirst();
			// q
			if(w.getRight() == null) {
				State q = w.getLeft();
				State qc = mapc.get(w);
				Set<Transition> trs = q.getTransitions();
				if(q != acc) {
					for(Transition tr : trs) {
						State succ = tr.getDest();
						SPair sp = new SPair(succ, null, map);
						State sc = mapc.get(sp);
						if(sc == null) {
							sc = new State();
							worklist.add(sp);
							mapc.put(sp, sc);
						}
						qc.addTransition(new Transition(tr.getMin(), tr.getMax(), sc));
					}
				}else {
					// we know that q is accepting state
					for(Transition tr : trs) {
						State succ = tr.getDest();
						for(char letter = tr.getMin(); letter <= tr.getMax(); letter ++) {
							State sua = init.step(letter);
							SPair sp = null;
							if(sua != null) {
								sp = new SPair(sua, succ, map);
							}else {
								sp = new SPair(null, succ, map);
							}
							State sc = mapc.get(sp);
							if(sc == null) {
								sc = new State();
								worklist.add(sp);
								mapc.put(sp, sc);
							}
							qc.addTransition(new Transition(letter, sc));
						}
					}
				}
			}
			
			// <q>
			if(w.getLeft() == null) {
				State q = w.getRight();
				State qc = mapc.get(w);
				Set<Transition> trs = q.getTransitions();
				if(q != acc) {
					for(Transition tr : trs) {
						State succ = tr.getDest();
						SPair sp = new SPair(null, succ, map);
						State sc = mapc.get(sp);
						if(sc == null) {
							sc = new State();
							worklist.add(sp);
							mapc.put(sp, sc);
						}
						qc.addTransition(new Transition(tr.getMin(), tr.getMax(), sc));
					}
				}else {
					// we know that q is accepting state
					for(Transition tr : trs) {
						State succ = tr.getDest();
						for(char letter = tr.getMin(); letter <= tr.getMax(); letter ++) {
							State sua = init.step(letter);
							SPair sp = null;
							if(sua != null) {
								sp = new SPair(sua, succ, map);
							}else {
								sp = new SPair(null, succ, map);
							}
							State sc = mapc.get(sp);
							if(sc == null) {
								sc = new State();
								worklist.add(sp);
								mapc.put(sp, sc);
							}
							qc.addTransition(new Transition(letter, sc));
						}
					}
				}
			}
			// (p, q)
			
			if(w.getLeft() != null && w.getRight() != null) {
				
				State p = w.getLeft();
				State q = w.getRight();
				
				State qc = mapc.get(w);
				
				Set<Transition> trs = q.getTransitions();
				
				for(Transition tr : trs) {
					State succ = tr.getDest();
					for(char letter = tr.getMin(); letter <= tr.getMax(); letter ++) {
						State sup = p.step(letter);
						SPair sp = null;
						if(sup == null) {
							sp = new SPair(null, succ, map);
						}else if(p != acc) {
							sp = new SPair(sup, succ, map);
						}else {
							State sui = init.step(letter);
							if(sui == null) {
								sp = new SPair(null, succ, map);
							}else {
								sp = new SPair(sui, succ, map);
							}
						}
						State sc = mapc.get(sp);
						if(sc == null) {
							sc = new State();
							worklist.add(sp);
							mapc.put(sp, sc);
						}
						qc.addTransition(new Transition(letter, sc));
					}
				}	
			}
		}
		
		SPair spacc = new SPair(acc, acc, map);
		State accc = mapc.get(spacc);
		accc.setAccept(true);
		return c;
	}
	
	// use it in product
	private class SPair extends Pair<State, State> {

		private TObjectIntMap<State> map;
		
		public SPair(State left, State right, TObjectIntMap<State> map) {
			super(left, right);
			this.map = map;
		}
		
		public boolean equals(Object obj) {
			if(obj instanceof SPair) {
				SPair pair = (SPair)obj;
				if(getLeft() != pair.getLeft()) return false;
				if(getRight() != pair.getRight()) return false;
				return true;
			}
			return false;
		}
		
		public String toString() {

			if(getLeft() != null && getRight() == null) {
				return "" + map.get(getLeft());
			}
			if(getLeft() == null && getRight() != null) {
				return "<" + map.get(getRight()) + ">";
			}
			if(getLeft() != null && getRight() != null) {
				return "(" + map.get(getLeft()) + ", " + map.get(getRight()) + ")";
			}
			return "";
		}
		
		public int hashCode() {
			
			int num = map.size();

			if(getLeft() != null && getRight() == null) {
				return map.get(getLeft()) - num;
			}
			
			if(getLeft() == null && getRight() != null) {
				return num * (num + 1) + map.get(getRight());
			}
			
			if(getLeft() != null && getRight() != null) {
				return num * map.get(getLeft()) +  map.get(getRight());
			}
			
			return 0;

		}
		
	}

}
