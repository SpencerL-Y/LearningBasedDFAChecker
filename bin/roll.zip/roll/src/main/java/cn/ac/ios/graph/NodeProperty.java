/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.graph;

import cn.ac.ios.value.ValueManager;
import cn.ac.ios.value.Type;
import cn.ac.ios.value.Value;

public interface NodeProperty {
	
	Graph getGraph();
	
	Value get();
	
	Type getType();
	
	void set(Value value);
	
    default void set(Object object) {
        assert object != null;
        assert false : getClass();
    }  
    
    default void set(int value)  {
        assert false : getClass();
    }  
	
    default boolean getBoolean()  {
        Value value = get();
        assert value.isBoolean();
        return value.getBoolean();
    }
    
    default int getInt()  {
        Value value = get();
        assert value.isInteger();
        return value.getInt();
    }
    
    default <T> T getObject()  {
        Value value = get();
        assert value.isObject() : value + " " + value.getType();
        return value.getObject();
    }
    
    default ValueManager getContextValue() {
        return getGraph().getValueManager();
    }

}
