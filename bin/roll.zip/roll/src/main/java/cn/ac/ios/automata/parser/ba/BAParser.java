package cn.ac.ios.automata.parser.ba;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.Iterator;

import automata.FAState;
import automata.FiniteAutomaton;
import cn.ac.ios.automata.parser.Parser;

public class BAParser implements Parser {

	private final String baFile;
	
	public BAParser(String file) {
		baFile = file;
	}

	@Override
	public FiniteAutomaton parse() {
		try {
			FileInputStream inputStream = new FileInputStream(new File(baFile));
			JBAParser parser = new JBAParser(inputStream);
			return parser.parse();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public void print(FiniteAutomaton fa, OutputStream out) {
		PrintStream printer = new PrintStream(out);
		printer.print(BAPrinter.printBA(fa));
	}

	@Override
	public void close() {		
	}

}
