/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.options;


import cn.ac.ios.automata.parser.FormatType;
import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.log.Log;

// this is class meant for command line usage

public final class Options {
	
	// mode 
	public static boolean modeInteractive = false;
	public static boolean modeAutomatic = false;
	public static boolean modeTest = false;
	
	// data structure used in learning algorithm
	public static boolean learnerTree = false;
	public static boolean learnerTable = false;
	
	// ------------- omega regular language learning algorithms
	// FDFA learning
	public static boolean learnerPeriodic = false;    // FDFA periodic method
	public static boolean learnerRecurrent = false;   // FDFA recurrent method
	public static boolean learnerSyntactic = false;   // FDFA syntactic method
	
	// buechi learning algorithm by CNP and L$
	public static boolean learnerLDollar = false;
	
	// ------------- regular language learning algorithms
	// DFA learning algorithm
	public static boolean learnerLStar = false;
	public static boolean learnerDFA = false;
	
	
	// Buechi construction method for FDFA
	public static boolean buechiBuildUnder = false;
	
	//  sampling before equivalence check
	public static boolean sampleFdfa = false;
	
	// use rabit minimize NFA
	public static boolean simulationNFA = false;
	
	// use rabit minimization for Buechi
	public static boolean minimizationBuechi = false;
	
	// whether we need to output the corresponding LDBA, only for lower
	public static boolean outLDBA = false;
	// lazy for equivalence check, this means that
	// equivalence check will be avoided as much as possible
	public static boolean lazyEqCheck = false;
	

	

	
	// sampling as teacher
	public static boolean teacherSampling = false;
	
	// information output
	public static boolean verbose = false;
	
	// output format
	public static boolean dot = false;
	
	
	// -----------  universal accessed objects -------------------
	// log information
	public static Log log;
	
	// manger for words
	public static WordManager wordManager;
	
	// ----- arguments for sampling
	public static double epsilon;
	public static double delta;
	
	
	// ----- input and output file
	public static String inputFile;
	public static String outputFile;
	
	// ----- arguments for testing
	public static int numTests;
	public static int numStatesForTest;
	
	// ----- input BA format
	public static FormatType formatType;
	

	// Things TODO
	public static boolean learnerMultiplicity = false;
	public static boolean learnerNFA = false;
	

}
