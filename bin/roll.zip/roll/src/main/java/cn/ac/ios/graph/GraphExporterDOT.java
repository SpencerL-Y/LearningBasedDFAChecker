/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.graph;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.Set;

import cn.ac.ios.value.Value;


public class GraphExporterDOT {
    public static void export(Graph graph, OutputStream stream) {
        PrintStream out = new PrintStream(stream);
        Set<Object> graphProperties = graph.getGraphProperties();
        for (Object property : graphProperties) {
        	out.print("// ");
        	Value value = graph.getGraphProperty(property);
        	out.print(property + "=" + value);
        	out.println();
        }
        out.println("digraph {");
        Set<Object> nodeProperties = graph.getNodeProperties();
        Set<Object> edgeProperties = graph.getEdgeProperties();
        for (int node = 0; node < graph.getNumNodes(); node++) {
            graph.queryNode(node);
            out.print("  " + node + " [label=\"");
            int propNr = 0;
            for (Object property : nodeProperties) {
                Value value = graph.getNodeProperty(property).get();
                out.print(property + "=" + value);
                if (propNr < nodeProperties.size() - 1) {
                    out.print(",");
                }
                propNr++;
            }
            out.println("\"];");
        }
        out.println();
        for (int node = 0; node < graph.getNumNodes(); node++) {
            graph.queryNode(node);
            int numSucc = graph.getNumSuccessors();
            for (int succNr = 0; succNr < numSucc; succNr++) {
                int succ = graph.getSuccessorNode(succNr);
                out.print("  " + node + " -> " + succ + " [label=\"");
                int propNr = 0;
                for (Object property : edgeProperties) {
                    EdgeProperty prop = graph.getEdgeProperty(property);
                    Value value = prop.get(succNr);
                    out.print(property + "=" + value);
                    if (propNr < edgeProperties.size() - 1) {
                        out.print(",");
                    }
                    propNr++;
                }
                out.println("\"];");
            }
        }

        out.println("}");
    }
    
    public static String toString(Graph graph) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try {
            export(graph, out);
            return out.toString();
        } catch (Exception e) {
            return "ERROR";
        }
    }

}
