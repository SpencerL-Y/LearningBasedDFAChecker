/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.oracle;

import java.util.ArrayList;
import java.util.List;

import automata.FiniteAutomaton;
import cn.ac.ios.util.UtilAutomaton;
import dk.brics.automaton.Automaton;
import dk.brics.automaton.State;
import dk.brics.automaton.Transition;
import oracle.AutomatonBuilder;
import oracle.EmptinessCheck;
import oracle.Membership;
import oracle.ProductBuilder;

public class BuechiRunner {
	
	// input a list of string (letters) of prefix 
	// a list of strings (letters) of suffix
	public static boolean isAccepting(FiniteAutomaton aut
			, List<String> prefix, List<String> suffix) {
		Membership checker = new Membership(aut);
		return checker.checkMembership(prefix, suffix);
	}
	
	public static boolean isAccepting(FiniteAutomaton aut
			, String pre, String suf) {
		Membership checker = new Membership(aut);
		
		List<String> prefix = new ArrayList<>(), suffix = new ArrayList<>();
		
		for(int i = 0; i < pre.length(); i ++) {
			prefix.add(pre.substring(i, i + 1));
		}
		
		for(int i = 0; i < suf.length(); i ++) {
			suffix.add(suf.substring(i, i + 1));
		}
		
		return checker.checkMembership(prefix, suffix);
	}
	
//	public static boolean checkEmptiness(Automaton aut1, Automaton aut2) {
//		Automaton product = aut1.intersection(aut2);
//		FiniteAutomaton rabitPro = UtilAutomaton.convertToRabitAutomaton(product);
//		EmptinessCheck checker = new EmptinessCheck(rabitPro);
//		return checker.isEmpty();
//	}
	
//	// prefix may be empty string
//	public static Automaton buildDkAutomaton(List<String> prefix, List<String> suffix) {
//		Automaton c = new Automaton();
//		State init = new State();
//		c.setInitialState(init);
//		State curr = init;
//		State acc = null;
//		int j ;
//		
//		if(prefix.size() == 0) {
//			init.setAccept(true);
//			acc = init;
//		}else {
//			
//			acc = new State();
//			acc.setAccept(true);
//			j = prefix.size() - 1;
//			
//			for(int i = 0; i < j; i ++) {
//				State s = new State();
//				curr.addTransition(new Transition(prefix.get(i).charAt(0), s));
//				curr = s;
//			}
//			
//			curr.addTransition(new Transition(prefix.get(j).charAt(0), acc));
//			
//		}
//
//		curr = acc;
//		j = suffix.size() - 1;
//		
//		for(int i = 0; i < j; i ++) {
//			State s = new State();
//			curr.addTransition(new Transition(suffix.get(i).charAt(0), s));
//			curr = s;
//			curr.setAccept(true);
//		}
//		
//		curr.addTransition(new Transition(suffix.get(j).charAt(0), acc));
//		
//		return c;
//	}

}
