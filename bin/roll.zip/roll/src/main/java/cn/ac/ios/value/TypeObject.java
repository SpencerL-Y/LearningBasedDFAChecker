/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.value;

class TypeObject  implements Type {

	private final ValueManager contextValue;
	private Value knownValue = null;
	private Class<?> usedClass;
	
	TypeObject(ValueManager contextValue, Value known
			, Class<?> usedClass) {
		
		assert contextValue != null;
		assert usedClass != null;
		
		this.contextValue = contextValue;
		this.usedClass = usedClass;
		if(known != null)  {
			this.knownValue = known.clone();
			this.knownValue.setImmutable();
		}
	}
	
	public Value newValue() {
        if (getKnownValue() != null) {
            return getKnownValue().clone();
        } else {
            return new ValueObject(this);
        }
	}
	
	@Override
	public ValueManager getContext() {
		return contextValue;
	}

	@Override
	public Type clone() {
		return new TypeObject(contextValue, knownValue, usedClass);
	}

	@Override
	public void setKnownValue(Value obj) {
		assert obj != null;
		
		this.knownValue = obj.clone();
		this.knownValue.setImmutable();
	}

	@Override
	public Value getKnownValue() {
		return knownValue;
	}

	@Override
	public boolean isObject() {
		return true;
	}
	
	public Class<?> getUsedClass() {
		return usedClass;
	}
	
    public boolean equals(Object obj) {
    	if(! (obj instanceof TypeObject)) {
    		return false;
    	}
    	TypeObject typeObject = (TypeObject)obj;
    	return typeObject.getUsedClass() == usedClass;
    }
    
    public String toString() {
    	return usedClass.toString();
    }
}
