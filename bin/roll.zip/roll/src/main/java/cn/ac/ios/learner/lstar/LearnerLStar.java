/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.learner.lstar;

import java.util.ArrayList;
import java.util.BitSet;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;

import cn.ac.ios.automata.Automaton;
import cn.ac.ios.automata.DFA;
import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.automata.words.Word;
import cn.ac.ios.learner.Learner;
import cn.ac.ios.learner.LearnerType;
import cn.ac.ios.query.MembershipOracle;
import cn.ac.ios.query.Query;
import cn.ac.ios.query.QuerySimple;
import cn.ac.ios.table.ExprValue;
import cn.ac.ios.table.ObservationRow;
import cn.ac.ios.table.HashableValue;

/**
 * From the paper "Learning Regular Sets from Queries and Counterexamples"
 * */

public final class LearnerLStar implements Learner<Automaton, Boolean> {

	private final WordManager contextWord;
	private ObservationTableLStar observationTable;
	private final MembershipOracle<Boolean> membershipOracle;
	private boolean alreadyStarted = false;
	
	public LearnerLStar(WordManager contextWord
			, MembershipOracle<Boolean> membershipOracle) {
		assert contextWord != null && membershipOracle != null;
		this.contextWord = contextWord;
		this.membershipOracle = membershipOracle;
		this.observationTable = new ObservationTableLStar(contextWord);
		// add every alphabet
		for(int letterNr = 0; letterNr < this.contextWord.getAlphabet().size(); letterNr ++) {
			observationTable.addLowerRow(contextWord.getLetterWord(letterNr));
		}
	}

	@Override
	public void startLearning() {
		if(alreadyStarted )
			try {
				throw new Exception("Learner should not be started twice");
			} catch (Exception e) {
				e.printStackTrace();
			}
		alreadyStarted = true;
		
		// ask initial queries for upper table
		processMembershipQueries(observationTable.getUpperTable()
				, 0, observationTable.getColumns().size());
		// ask initial queries for lower table
		processMembershipQueries(observationTable.getLowerTable()
				, 0, observationTable.getColumns().size());
		
		makeTableComplete();
	}
	
	private void processMembershipQueries(List<ObservationRow> rows
			, int colOffset, int length) {
		List<Query<Boolean>> membershipQueries = new ArrayList<>();
		List<ExprValue> columns = observationTable.getColumns();
		int endNr = length + colOffset;
		for(ObservationRow row : rows) {
			for(int colNr = colOffset; colNr < endNr; colNr ++) {
				membershipQueries.add(new QuerySimple<>(row, row.getWord(), columns.get(colNr).get(), colNr));
			}
		}
		processMembershipQueries(membershipQueries);
	}
	
	private void processMembershipQueries(List<Query<Boolean>> queries) {
		membershipOracle.answerMembershipQueries(queries);
		for(Query<Boolean> query : queries) {
			Boolean result = query.getQueryAnswer();
			assert result != null;
			ObservationRow row = query.getPrefixRow();
			row.set(query.getSuffixColumn(), observationTable.getHashableValueByBool(result));
		}
	}
	
	// main loop for L* algorithm 
	// try to make table complete
	// a table is complete when it is both closed and consistent
	private void makeTableComplete() {
		boolean ready = false;
		while(! ready) {
			ready = makeTableClosed();
			ready = ready && makeTableConsistent();  
		}
	}
	
	private boolean makeTableClosed() {
		ObservationRow lowerRow = observationTable.getUnclosedLowerRow();
		boolean isClosed = lowerRow == null;
		
		while(lowerRow != null) {
			// 1. move to upper table
			observationTable.moveRowFromLowerToUpper(lowerRow);
			// 2. add one letter to lower table
			List<ObservationRow> newLowerRows = new ArrayList<>();
			for(int letterNr = 0; letterNr < contextWord.getNumLetters(); letterNr ++) {
				Word newWord = lowerRow.getWord().append(letterNr);
				newLowerRows.add(observationTable.addLowerRow(newWord));
			}
			// 3. process membership queries
			processMembershipQueries(newLowerRows, 0, observationTable.getColumns().size());
			lowerRow = observationTable.getUnclosedLowerRow();
		}
		
		return isClosed;
	}
	
	private boolean makeTableConsistent() {
		Word suffix = observationTable.getInconsistentColumn();
		boolean isConsistent = suffix == null;
		
		while(suffix != null) {
			// 1. add to columns
			int columnIndex = observationTable.addColumn(observationTable.getExprValueByWord(suffix));
			// 2. add result of new column to upper table
			processMembershipQueries(observationTable.getUpperTable(), columnIndex, 1);
			// 3. process membership queries
			processMembershipQueries(observationTable.getLowerTable(), columnIndex, 1);
			suffix = observationTable.getInconsistentColumn();
		}
		
		return isConsistent;
	}

    // return counter example for hypothesis
	@Override
	public void refineHypothesis(Query<Boolean> ceQuery) {
		Word ceWord = ceQuery.getQueriedWord();
		
		// get all prefixes that are not in upper table
		LinkedHashSet<Word> prefixes = getAllValidPrefixes(ceWord);
		// get lower prefix row and new rows
		List<ObservationRow> existRows = new ArrayList<>();
		List<ObservationRow> newRows = new ArrayList<>();
		for(Word prefix : prefixes) {
			ObservationRow lowerRow = observationTable.getLowerTableRow(prefix);
			if(lowerRow == null) { // check existence of current prifix
				newRows.add(observationTable.addUpperRow(prefix));
			}else {
				existRows.add(lowerRow);
			}
		}
		
		// move existing rows from lower table to upper table
		for(ObservationRow row : existRows) {
			observationTable.moveRowFromLowerToUpper(row);
		}
		
		// ask membership for new added rows
		List<ObservationRow> newLowerRows = addLowerRowsFromRowsWithExtension(existRows);
		newLowerRows.addAll(addLowerRowsFromRowsWithExtension(newRows));
		processMembershipQueries(newRows, 0, observationTable.getColumns().size());
		processMembershipQueries(newLowerRows, 0, observationTable.getColumns().size());
		
		makeTableComplete();
	}
	
	// input S, add S.A
	private List<ObservationRow> addLowerRowsFromRowsWithExtension(List<ObservationRow> rows) {
		List<ObservationRow> lowerRows = new LinkedList<>();
		for(ObservationRow row : rows) {
			for(int letter = 0; letter < contextWord.getNumLetters(); letter ++) {
				Word word = row.getWord().append(letter);
				ObservationRow tableRow = observationTable.getTableRow(word); 
				if(tableRow == null) { // check existence
					tableRow = observationTable.addLowerRow(word);
					lowerRows.add(tableRow);
				}
			}
		}
		return lowerRows;
	}
	
	// get all prefixes of counter example which are not in the upper table
	private LinkedHashSet<Word> getAllValidPrefixes(Word word) {
		LinkedHashSet<Word> prefixes = new LinkedHashSet<>();
		for(int length = 1; length <= word.length() ; length ++) {
			Word prefix = word.getSubWord(0, length);
			boolean valid = true;
			//search upper table
			for(ObservationRow row : observationTable.getUpperTable()) {
				Word upperWord = row.getWord();
				if(upperWord.equals(prefix)) {
					valid = false;
					break;
				}
			}
			if(valid) prefixes.add(prefix);
		}
		return prefixes;
	}
	

	@Override
	public Automaton getHypothesis() {
		Automaton dfa = new DFA(contextWord);
		List<ObservationRow> upperTable = observationTable.getUpperTable();
		
		// add states one by one, ordered by the order of occurences
		// and should in a increased order, maybe change this later
		Queue<Integer> queue = new LinkedList<>();
		queue.add(0);
		BitSet visited = new BitSet(upperTable.size());
		visited.set(0);
		int counter = 0;
		Map<Integer, Integer> stateMap = new HashMap<>();
		stateMap.put(0, counter);
		
		// get all distinguished rows in upper table
		Map<List<HashableValue>, Integer> valuesMap = new HashMap<>();
		for(int rowNr = 0; rowNr < upperTable.size(); rowNr ++) {
			List<HashableValue> values = upperTable.get(rowNr).getValues();
			if(valuesMap.containsKey(values)) continue;
			valuesMap.put(values, rowNr);
		}
		
		while(! queue.isEmpty()) {
			int state = queue.poll();
			dfa.addNewState(stateMap.get(state));
			for(int letter = 0; letter < contextWord.getNumLetters(); letter ++) {
				List<HashableValue> succValues = getSuccessorValues(state, letter);
				if(succValues != null) {
					Integer succ = valuesMap.get(succValues);
					assert succ != null;
					if(! visited.get(succ)) {
						queue.add(succ);
						visited.set(succ);
						stateMap.put(succ, ++ counter);
					}
					dfa.addTransition(letter, stateMap.get(succ));
				}
			}
			if(isAccepting(state)) {
				dfa.setAccepting();
			}
			if(upperTable.get(state).getWord().isEmpty()) {
				dfa.setInitial();
			}
			dfa.addNewStateEnd();
		}
		
		return dfa;
	}
	
	// a state is accepting iff it accepts empty language
	private boolean isAccepting(int state) {
		ObservationRow stateRow = observationTable.getUpperTable().get(state);
		int emptyNr = observationTable.getColumnIndex(observationTable.getExprValueByWord(contextWord.getEmptyWord()));
		assert emptyNr != -1;
		return stateRow.getValues().get(emptyNr).get();
	}
	
	private List<HashableValue> getSuccessorValues(int state, int letter) {
		ObservationRow stateRow = observationTable.getUpperTable().get(state);
		Word succWord = stateRow.getWord().append(letter);

		// search in upper table
		for(int succ = 0; succ < observationTable.getUpperTable().size(); succ ++) {
			ObservationRow succRow = observationTable.getUpperTable().get(succ);
			if(succRow.getWord().equals(succWord)) {
				return succRow.getValues();
			}
		}
		// search in lower table
		ObservationRow succRow = observationTable.getLowerTableRow(succWord);
		assert succRow != null;
		for(int succ = 0; succ < observationTable.getUpperTable().size(); succ ++) {
			ObservationRow upperRow = observationTable.getUpperTable().get(succ);
			if(succRow.valuesEqual(upperRow)) {
				return succRow.getValues();
			}
		}
		assert false : "successor values not found";
		return null;
	}

	@Override
	public LearnerType getLearnerType() {
		return LearnerType.LSTAR;
	}
	
	public String toString() {
		return observationTable.toString();
	}

}
