package cn.ac.ios.bdd.graph;

import java.util.ArrayList;
import java.util.List;

import cn.ac.ios.bdd.BDDManager;
import cn.ac.ios.bdd.Permutation;
import cn.ac.ios.bdd.VariableBDD;
import cn.ac.ios.util.Pair;
import net.sf.javabdd.BDD;
import net.sf.javabdd.BDDPairing;
//TODO
public class BuechiBDD {
	
	private BDD init;
	private BDD states;
	private BDD transition;
	private List<BDD> accs;
	private BDD preCube;
	private BDD nextCube;
	private BDD actionCube;
	private final BDDManager bdd;
	
	private Permutation nextToPres;
	
	public BuechiBDD(BDDManager bdd) {
		assert bdd != null;
		this.bdd = bdd;
		accs = new ArrayList<>();
	}
	
	public void setInitial(BDD init) {
		this.init = init;
	}
	
	public void setTransition(BDD trans) {
		this.transition = trans;
	}
	
	public void setStateSpace(BDD states) {
		this.states = states;
	}
	
	public void setPreCube(BDD cube) {
		this.preCube = cube;
	}
	
	public void setNextCube(BDD cube) {
		this.nextCube = cube;
	}
	
	public void setActionCube(BDD cube) {
		this.actionCube = cube;
	}
	
	public void addAcceptance(BDD dd) {
		this.accs.add(dd);
	}
	
	
	public void setPermutation(Permutation pair) {
		this.nextToPres = pair;
	}
	
	public BDD getInitial() {
		return init;
	}
	
	public BDD getTransition() {
		return transition;
	}
	
	public BDD getStateSpace() {
		return states;
	}
	
	public List<BDD> getAcceptance() {
		return accs;
	}
	
	public BDD getPreCube() {
		return this.preCube;
	}
	
	public BDD getNextCube() {
		return this.nextCube;
	}
	
	public BDD getActionCube() {
		return this.preCube;
	}
	
	public Permutation getPermutation() {
		return nextToPres;
	}
	
	public BDDManager getBDDManager() {
		return bdd;
	}
	
	public BuechiBDD and(BuechiBDD other) {
		BuechiBDD product = new BuechiBDD(bdd);
		if(actionCube != other.actionCube) {
			System.err.println("The alphabets are not the same");
			System.exit(-1);
		}
		
		product.setActionCube(actionCube);
		product.setPreCube(preCube.and(other.preCube));
		product.setNextCube(nextCube.and(other.nextCube));
		
		// set permutation
		List<BDD> pres = new ArrayList<>();
		List<BDD> next = new ArrayList<>();
		for(int index = 0; index < nextToPres.getPresVars().size(); index ++) {
			pres.add(nextToPres.getPresVars().get(index));
		}
		for(int index = 0; index < other.nextToPres.getPresVars().size(); index ++) {
			pres.add(other.nextToPres.getPresVars().get(index));
		}
		
		for(int index = 0; index < nextToPres.getNextVars().size(); index ++) {
			next.add(nextToPres.getNextVars().get(index));
		}
		for(int index = 0; index < other.nextToPres.getNextVars().size(); index ++) {
			next.add(other.nextToPres.getNextVars().get(index));
		}
		
		product.setPermutation(new Permutation(bdd, pres, next));

		product.setInitial(init.and(other.init));
		product.setStateSpace(exploreStateSpace());
		product.setTransition(transition.and(other.transition));
		product.accs.addAll(accs);
		product.accs.addAll(other.accs);

		return product;
	}
	
	private BDD exploreStateSpace() {
		BDD preNodes = bdd.getZero();
		BDD states = init;
		BDD trans = transition.exist(actionCube);
		while(! states.equals(preNodes)) {
			preNodes = states;
			states = next(states, trans, preCube, nextToPres);
		}
		preNodes.free();
		return states;
		
	}
	
	// no actions in transition
	private BDD next(BDD nodes, BDD trans, BDD presCube, Permutation swap) {
		BDD image = nodes.and(trans).exist(presCube);
		return image.replaceWith(swap.getBDDPairing());
	}
	
	// no actions in transition
	private BDD pre(BDD nodes, BDD trans, BDD presCube, Permutation swap) {
		BDD nextCube = presCube.replace(swap.getBDDPairing());
		BDD image = trans.and(nodes.replace(swap.getBDDPairing())).exist(nextCube);
		nextCube.free();
		return image;
	}
	
	public Pair<List<BDD>, List<BDD>> getOneWord() {
		return null;
	}
	
	

	
	public void close() {
		
		init.free();
		states.free();
		transition.free();
		for(BDD acc: accs) {
			acc.free();
		}
		actionCube.free();
		preCube.free();
		nextCube.free();
		
		for(BDD dd : nextToPres.getNextVars()) {
			dd.free();
		}
		
		for(BDD dd : nextToPres.getPresVars()) {
			dd.free();
		}

	}
	

}
