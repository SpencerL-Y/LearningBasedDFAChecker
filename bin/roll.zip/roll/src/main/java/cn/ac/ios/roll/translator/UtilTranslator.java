package cn.ac.ios.roll.translator;

import cn.ac.ios.automata.Acceptor;
import cn.ac.ios.learner.Learner;
import cn.ac.ios.learner.buechi.ldollar.LearnerOmegaBuechi;
import cn.ac.ios.learner.fdfa.LearnerFDFA;
import cn.ac.ios.options.Options;
import cn.ac.ios.query.MembershipOracle;

public final class UtilTranslator {
	
	// select a translator for the learner
    public static Translator prepareTranslator(Learner<? extends Acceptor, Boolean> learner
    		, MembershipOracle<Boolean> membershipOracle) {
    	if(learner instanceof LearnerFDFA && Options.buechiBuildUnder) {
    		return new TranslatorFDFAUnder(learner);
    	}
    	if(learner instanceof LearnerFDFA && !Options.buechiBuildUnder) {
    		return new TranslatorFDFAOver(learner, membershipOracle);
    	}
    	if(learner instanceof LearnerOmegaBuechi) {
    		return new TranslatorBuechi(learner);
    	}
    	return new TranslatorSimple(learner);
    }

}
