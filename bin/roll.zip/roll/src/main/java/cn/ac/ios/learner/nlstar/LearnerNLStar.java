/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.learner.nlstar;

import cn.ac.ios.automata.Automaton;
import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.learner.Learner;
import cn.ac.ios.learner.LearnerType;
import cn.ac.ios.query.MembershipOracle;
import cn.ac.ios.query.Query;

/**
 * From the paper "Angluin-Style Learning of NFA"
 * */

public class LearnerNLStar implements Learner<Automaton, Boolean> {

	private final WordManager contextWord;
	private ObservationTableNLStar observationTable;
	private final MembershipOracle<Boolean> membershipOracle;
	
	private boolean alreadyStarted = false;
	
	public LearnerNLStar(WordManager contextWord, MembershipOracle<Boolean> membershipOracle) {
		assert contextWord != null && membershipOracle != null;
		this.contextWord = contextWord;
		this.membershipOracle = membershipOracle;
		this.observationTable = new ObservationTableNLStar(contextWord);
		// add every alphabet
		for(int letterNr = 0; letterNr < this.contextWord.getAlphabet().size(); letterNr ++) {
//			observationTable.addLowerRow(contextWord.getLetterWord(letterNr));
		}
	}
	
	@Override
	public LearnerType getLearnerType() {
		return LearnerType.NLSTAR;
	}

	@Override
	public void startLearning() {
		if(alreadyStarted )
			try {
				throw new Exception("Learner should not be started twice");
			} catch (Exception e) {
				e.printStackTrace();
			}
		alreadyStarted = true;
		// initialize table
		
		makeTableComplete();
	}

	@Override
	public Automaton getHypothesis() {
		return null;
	}

	@Override
	public void refineHypothesis(Query<Boolean> query) {
	}
	
	private void makeTableComplete() {
		
	}
	
	private boolean makeTableClosed() {
		return false;
	}
	
	private boolean makeTableConsistent() {
		return false;
	}

}
