/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.learner.fdfa.tree;

import cn.ac.ios.table.HashableValue;
import cn.ac.ios.util.Pair;

/** only used for syntactic tree */
class HashableValueIntBooleanPair implements HashableValue {
	
	private int valueInt;       // corresponding state in leading automaton
	private boolean valueLeft;  // m -> u (xv)^\omega \in L 
	private boolean valueRight; // c -> u xv ~ u
	
	public HashableValueIntBooleanPair(int valueInt, boolean left, boolean right) {
		this.valueInt  = valueInt;
		this.valueLeft = left;
		this.valueRight = right;
	}

	// q1 != q2, return false
	// q1 = q2 ==> c1 == c2
	// m1 != m2 && (c1 || c2) implies two branch are different
	@Override
	public boolean valueEqual(HashableValue rvalue) {
		assert rvalue instanceof HashableValueIntBooleanPair;
		HashableValueIntBooleanPair other = (HashableValueIntBooleanPair)rvalue;
		if(valueInt != other.getInt()) return false;   // different branch
		if(! valueRight) return true;                  // same branch
		return valueLeft == (Boolean)other.getLeft();  // same branch or not
	}

	@SuppressWarnings("unchecked")
	@Override
	public Pair<Boolean, Boolean> get() {
		return new Pair<>(valueLeft, valueRight);
	}
	
	public boolean equals(Object obj) {
		if(obj instanceof HashableValueIntBooleanPair) {
			HashableValueIntBooleanPair pair = (HashableValueIntBooleanPair)obj;
			return valueEqual(pair);
		}
		return false;
	}
	
	public String toString() {
		return "(" +  valueInt 
				+ ", " + (valueLeft ? "+" : "-")
				+ ", " + (valueRight? "+" : "-") 
				+ ")";
	}
	
	@Override
	public int hashCode() {
		int value = valueInt * 2 + (valueLeft ? 0 : 1);
		return value;
	}

	@Override
	public boolean isPair() {
		return true;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Boolean getLeft() {
		return valueLeft;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Boolean getRight() {
		return valueRight;
	}

	@Override
	public boolean isAccepting() {
		return valueLeft && valueRight;
	}
	
	public int getInt() {
		return valueInt;
	}

}
