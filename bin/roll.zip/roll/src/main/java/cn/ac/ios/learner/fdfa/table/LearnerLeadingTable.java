/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.learner.fdfa.table;

import java.util.ArrayList;
import java.util.List;

import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.automata.words.Word;
import cn.ac.ios.learner.fdfa.LearnerLeading;
import cn.ac.ios.query.MembershipOracle;
import cn.ac.ios.query.Query;
import cn.ac.ios.table.ExprValue;
import cn.ac.ios.table.ExprValueWordPair;
import cn.ac.ios.table.HashableValue;
import cn.ac.ios.table.ObservationRow;

public class LearnerLeadingTable extends LearnerOmegaTable implements LearnerLeading {

	public LearnerLeadingTable(WordManager contextWord, MembershipOracle<Boolean> membershipOracle) {
		super(contextWord, membershipOracle);
	}
	
	@Override
	protected boolean isLeading() {
		return true;
	}

	@Override
	protected Query<HashableValue> processMembershipQuery(ObservationRow row, int offset, ExprValue valueExpr) {
		assert valueExpr instanceof ExprValueWordPair;
		Word prefix = row.getWord();
		Word left = valueExpr.getLeft();
		prefix = prefix.concat(left);
		Word suffix = valueExpr.getRight();
		boolean result = processMembershipQuery(row, prefix, suffix, offset);
		Query<HashableValue> query = getQuerySimple(row, prefix, suffix, offset);
		query.answerQuery(getHashableValueBoolean(result));
		return query;
	}

	private boolean isCEAccepting;
	// already normalized form
	@Override
	protected ExprValue getCounterExampleWord(Query<Boolean> query) {
		isCEAccepting = query.getQueryAnswer();
		return this.getExprValueWord(query.getPrefix(), query.getSuffix());
	}

	@Override
	protected CeAnalyzer getCeAnalyzerInstance(ExprValue exprValue) {
		return new CeAnalyzerTable(exprValue);
	}

	private int numStatesPrev;
	
	private class CeAnalyzerTable extends CeAnalyzer {
		
		public CeAnalyzerTable(ExprValue exprValue) {
			super(exprValue);
		}

		// process counter example 
		@Override
		public void analyze() {
			
			Word wordCE = exprValue.getLeft();
			Word period = exprValue.getRight();
			boolean resultPrev = isCEAccepting, resultCurr;
			int stateCurr, statePrev = getInitState();
			for(int letterNr = 0; letterNr < wordCE.length(); letterNr ++) {
				stateCurr = computeNextState(statePrev, wordCE.getLetter(letterNr));
				Word prefix = getStateLabel(stateCurr);
                Word suffix = wordCE.getSuffix(letterNr + 1);
				prefix = prefix.concat(suffix);
				resultCurr = processMembershipQuery(null, prefix, period, 0);
				if(resultPrev != resultCurr) {
					column = getExprValueWord(suffix, exprValue.getRight());
					break;
				}
				statePrev = stateCurr;
			}
			
			// record current states number
			numStatesPrev = observationTable.getUpperTable().size();
		}
		
	}

	@Override
	public List<Word> getNewStates() {
		List<Word> newStates = new ArrayList<>(); 
		List<ObservationRow> upperTable = observationTable.getUpperTable();
		for(int stateNr = numStatesPrev 
				; stateNr < upperTable.size()
				; stateNr ++) {
			newStates.add(upperTable.get(stateNr).getWord());
		}
		return newStates;
	}

}
