/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.roll.translator;


import cn.ac.ios.automata.Acceptor;
import cn.ac.ios.learner.Learner;
import cn.ac.ios.options.Options;
import cn.ac.ios.query.Query;
import cn.ac.ios.roll.Statistics;
import cn.ac.ios.util.AutomatonPrinter;
import cn.ac.ios.util.DollarAutomatonBuilder;
import cn.ac.ios.util.Timer;
import oracle.EqResult;

public class TranslatorFDFAUnder extends TranslatorFDFA {
	
	public TranslatorFDFAUnder(Learner<? extends Acceptor, Boolean> learner) {
		super(learner);
	}


	@Override
	public Query<Boolean> translate() {
		Timer timer = new Timer();
		timer.start();
		String counterexample = translateLower();
		timer.stop();
		Statistics.timeTranslator += timer.getTimeElapsed();
		return getQuery(counterexample, ceQuery.getQueryAnswer().isCeInTarget);
	}
	
	// -------- this is for lower Buechi automaton ----------------
	private String translateLower() {
		if(Options.verbose) AutomatonPrinter.print(autOmegaUV, System.out);
		EqResult eqResult = ceQuery.getQueryAnswer();
		
		String ceStr = null;
		if(eqResult.isCeInTarget) {
			// positive Counterexample, (u, v) is in target, not in constructed
			// Buechi, but possibly it is in FDFA, , already normalized
			ceStr = getPositiveCounterExample(learnerFDFA, autOmegaUV);
		}else {
			// negative Counterexample, (u, v) is not in target, but in FDFA
			// get intersection, already normalized.
			dk.brics.automaton.Automaton dollarFDFA = DollarAutomatonBuilder
					.buildDollarAutomaton(learnerFDFA);
			dk.brics.automaton.Automaton autInter = autOmegaUV.intersection(dollarFDFA);
			assert autInter != null;
			ceStr = autInter.getShortestExample(true);
			if(Options.verbose) System.out.println("Not in target: " + ceStr);
		}
		
		return ceStr;
	}


}
