/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.value;

class ValueInteger implements Value {

	private int value;
	private final Type type;
	private boolean immutable;

	ValueInteger(Type type, int value) {
		assert type != null;
		this.type = type;
		this.value = value;
	}

	ValueInteger(Type type) {
		this(type, 0);
	}

	@Override
	public Value clone() {
		return new ValueInteger(type, value);
	}

	@Override
	public Type getType() {
		return type;
	}
	
	public boolean isInteger() {
		return true;
	}

	public void set(int value) {
		assert !isImmutable();
		this.value = value;
	}
	
	public void set(Object value) {
		assert !isImmutable();
		assert value.getClass() == Integer.class;
		this.value = (Integer)value;
	}

	public void set(Value value) {
		assert !isImmutable();
		assert value != null;
		assert !value.isBoolean() && !value.isObject();
		set(value.getInt());
	}

	private double castTo(Value val) {
		double op = 0;
		if (val.isInteger()) {
			op = val.getInt();
		} else if (val.isDouble()) {
			op = (int) val.getDouble();
		} else {
			assert false : "wrong type to double";
		}
		return op;
	}

	@Override
	public void setImmutable() {
		this.immutable = true;
	}

	@Override
	public boolean isImmutable() {
		return this.immutable;
	}

	public void add(Value op1, Value op2) {
		assert op1 != null && op2 != null;
		assert !op1.isBoolean() && !op2.isBoolean();
		assert !op1.isObject() && !op2.isObject();

		set(op1.getInt() + op2.getInt());
	}

	public void divide(Value op1, Value op2) {
		assert op1 != null && op2 != null;
		assert !op1.isBoolean() && !op2.isBoolean();
		assert !op1.isObject() && !op2.isObject();
		if (op2.getInt() == 0) {
			System.err.println("divied by 0: " + op1 + "/" + op2);
			System.exit(-1);
		}
		set(op1.getInt() / op2.getInt());
	}

	public void subtract(Value op1, Value op2) {
		assert op1 != null && op2 != null;
		assert !op1.isBoolean() && !op2.isBoolean();
		assert !op1.isObject() && !op2.isObject();

		set(op1.getInt() - op2.getInt());
	}

	public void multiply(Value op1, Value op2) {
		assert op1 != null && op2 != null;
		assert !op1.isBoolean() && !op2.isBoolean();
		assert !op1.isObject() && !op2.isObject();

		set(op1.getInt() * op2.getInt());
	}

	public void max(Value op1, Value op2) {
		assert op1 != null && op2 != null;
		assert !op1.isBoolean() && !op2.isBoolean();
		assert !op1.isObject() && !op2.isObject();
		int op;
		if (op1.getInt() > op2.getInt()) {
			op = op1.getInt();
		} else {
			op = op2.getInt();
		}
		set(op);
	}

	public void min(Value op1, Value op2) {
		int op;
		if (op1.getInt() > op2.getInt()) {
			op = op2.getInt();
		} else {
			op = op1.getInt();
		}
		set(op);
	}
	
    // gets
    public int getInt() {
        return value;
    }
    
    public double getDouble() {
        return value;
    }
    
    @Override
    public String toString() {
    	return value + "";
    }
    
    @Override
    public boolean equals(Object obj) {
        assert obj != null;
        if (!(obj instanceof ValueInteger)) {
            return false;
        }
        ValueInteger other = (ValueInteger) obj;
        return this.value == other.value;
    }
    
    @Override
    public int hashCode() {
    	return value;
    }

}
