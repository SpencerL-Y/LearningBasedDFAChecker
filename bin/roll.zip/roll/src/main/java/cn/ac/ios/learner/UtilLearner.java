package cn.ac.ios.learner;

import cn.ac.ios.automata.Acceptor;
import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.learner.buechi.ldollar.LearnerOmegaBuechi;
import cn.ac.ios.learner.dfa.table.LearnerDFATable;
import cn.ac.ios.learner.dfa.tree.LearnerDFATree;
import cn.ac.ios.learner.fdfa.table.LearnerFDFATablePeriodic;
import cn.ac.ios.learner.fdfa.table.LearnerFDFATableRecurrent;
import cn.ac.ios.learner.fdfa.table.LearnerFDFATableSyntactic;
import cn.ac.ios.learner.fdfa.tree.LearnerFDFATreePeriodic;
import cn.ac.ios.learner.fdfa.tree.LearnerFDFATreeRecurrent;
import cn.ac.ios.learner.fdfa.tree.LearnerFDFATreeSyntactic;
import cn.ac.ios.learner.lstar.LearnerLStar;
import cn.ac.ios.options.Options;
import cn.ac.ios.query.MembershipOracle;

public final class UtilLearner {
	
	public static Learner<? extends Acceptor, Boolean> prepareLearner(WordManager wordManager,
    		MembershipOracle<Boolean> membershipOracle) {
    	
    	if(Options.learnerTable) {
    		if(Options.learnerLStar) return new LearnerLStar(wordManager, membershipOracle);
    		if(Options.learnerDFA) return new LearnerDFATable(wordManager, membershipOracle);
    		if(Options.learnerPeriodic) return new LearnerFDFATablePeriodic(wordManager, membershipOracle);
    		if(Options.learnerRecurrent) return new LearnerFDFATableRecurrent(wordManager, membershipOracle);
    		if(Options.learnerSyntactic) return new LearnerFDFATableSyntactic(wordManager, membershipOracle);
    		if(Options.learnerLDollar) return new LearnerOmegaBuechi(wordManager, membershipOracle, false);
    	}else {
    		if(Options.learnerLStar) {
    			Options.log.err("LStar does not support Tree-based Algorithm.");
    			System.exit(-1);
    		}
    		if(Options.learnerDFA) return new LearnerDFATree(wordManager, membershipOracle);
    		if(Options.learnerPeriodic) return new LearnerFDFATreePeriodic(wordManager, membershipOracle);
    		if(Options.learnerRecurrent) return new LearnerFDFATreeRecurrent(wordManager, membershipOracle);
    		if(Options.learnerSyntactic) return new LearnerFDFATreeSyntactic(wordManager, membershipOracle);
    		if(Options.learnerLDollar) return new LearnerOmegaBuechi(wordManager, membershipOracle, true);
    	}
    	return null;
    }
	
	
	private UtilLearner() {
		
	}

}
