/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import automata.FAState;
import automata.FiniteAutomaton;
import gnu.trove.map.TIntObjectMap;
import gnu.trove.map.TObjectIntMap;
import gnu.trove.map.hash.TIntObjectHashMap;
import gnu.trove.map.hash.TObjectIntHashMap;
import jhoafparser.ast.AtomAcceptance;
import jhoafparser.ast.AtomLabel;
import jhoafparser.ast.BooleanExpression;
import jhoafparser.consumer.HOAConsumer;
import jhoafparser.consumer.HOAConsumerException;
import jhoafparser.parser.HOAFParser;
import jhoafparser.parser.generated.ParseException;

public class HanoiParser implements HOAConsumer {
	
	// this class only allow the writtable letters
	
	private FiniteAutomaton automaton;
	private TIntObjectMap<FAState> stateMap = new TIntObjectHashMap<>();
	private TObjectIntMap<String> atomMap = new TObjectIntHashMap<>();
	private List<String> letterArr = new ArrayList<>();
	public HanoiParser(String name) {
		automaton = new FiniteAutomaton();
		initializeAlphabet();
		try {
			InputStream fileInputStream = new FileInputStream(name);
			HOAFParser.parseHOA(fileInputStream, this);
		} catch (ParseException e) {
			e.printStackTrace();
		} catch(FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	private void initializeAlphabet() {
		   for(char c = 'a' ; c < 'a' + 26; c ++) {
			   letterArr.add("" + c);
		   }
		   for(char c = 'A' ; c < 'A' + 26; c ++) {
			   letterArr.add("" + c);
		   }
		   for(char c = 32;  c < 'A'; c ++) {
			   if(c == '$' || Character.isSpaceChar(c)) continue;
			   letterArr.add("" + c);
		   }
		   for(char c = 'Z' + 1;  c < 'a'; c ++) {
			   letterArr.add("" + c);
		   }
		   for(char c = 'z' + 1; c < 127; c ++) {
			   letterArr.add("" + c);
		   }
	}
	
	private Integer getValue(String atom) {
		
		if(atomMap.containsKey(atom)) {
			return atomMap.get(atom);
		}
		
		int index = atomMap.size();
		atomMap.put(atom, index);
		
		return index;
	}
	
	private String getLetter(Integer index) {
        if(index >= letterArr.size()) {
        	System.err.println("do not allow too many letters");
        	System.exit(-1);
        }
		return letterArr.get(index);
	}
	
	public FiniteAutomaton getAutomaton() {
		return automaton;
	}

	@Override
	public boolean parserResolvesAliases() {
		return false;
	}

	@Override
	public void notifyHeaderStart(String version) throws HOAConsumerException {
		
	}

	@Override
	public void setNumberOfStates(int numberOfStates) throws HOAConsumerException {
		for(int stateNr = 0; stateNr < numberOfStates; stateNr ++) {
			stateMap.put(stateNr, automaton.createState());
		}
	}

	private BitSet inits = new BitSet();
	@Override
	public void addStartStates(List<Integer> stateConjunction) throws HOAConsumerException {
		assert stateConjunction.size() == 1 : "only allow one initial state one time";
		int initNr = stateConjunction.get(0);
		inits.set(initNr);
	}

	@Override
	public void addAlias(String name, BooleanExpression<AtomLabel> labelExpr) throws HOAConsumerException {
		
	}

	@Override
	public void setAPs(List<String> aps) throws HOAConsumerException {
		// we do not care its actual atomic propositions
	}

	@Override
	public void setAcceptanceCondition(int numberOfSets, BooleanExpression<AtomAcceptance> accExpr)
			throws HOAConsumerException {
         assert numberOfSets == 1 ;
         // this is Buchi acceptance conditions
	}

	@Override
	public void provideAcceptanceName(String name, List<Object> extraInfo) throws HOAConsumerException {
		
	}

	@Override
	public void setName(String name) throws HOAConsumerException {
	}

	@Override
	public void setTool(String name, String version) throws HOAConsumerException {		
	}

	@Override
	public void addProperties(List<String> properties) throws HOAConsumerException {
	}

	@Override
	public void addMiscHeader(String name, List<Object> content) throws HOAConsumerException {
		
	}

	@Override
	public void notifyBodyStart() throws HOAConsumerException {
		
	}

	private BooleanExpression<AtomLabel> labelExpr = null;
	@Override
	public void addState(int id, String info, BooleanExpression<AtomLabel> labelExpr, List<Integer> accSignature)
			throws HOAConsumerException {
		// only need to consider the labels of this state
		if(accSignature != null && accSignature.size() > 0) {
			automaton.F.add(stateMap.get(id));
		}
		// in case that they add labels on state
		this.labelExpr = labelExpr;
	}

	@Override
	public void addEdgeImplicit(int stateId, List<Integer> conjSuccessors, List<Integer> accSignature)
			throws HOAConsumerException {
		
		String atom = labelExpr.toString();
		FAState source = stateMap.get(stateId); 
		FAState target = stateMap.get(conjSuccessors.get(0));
        Integer index = getValue(atom);
		automaton.addTransition(source, target, getLetter(index));
		
	}

	@Override
	public void addEdgeWithLabel(int stateId, BooleanExpression<AtomLabel> labelExpr, List<Integer> conjSuccessors,
			List<Integer> accSignature) throws HOAConsumerException {
		assert conjSuccessors.size() == 1: "only allow one successors";
		if(conjSuccessors.size() != 1) {
			System.err.println("successor conjunction does not allowed");
			System.exit(-1);
		}
		if(labelExpr != null ) {  
			addTransition(stateId, labelExpr.toString(), conjSuccessors.get(0));
		}else {
			addTransition(stateId, this.labelExpr.toString(), conjSuccessors.get(0));
		}
		
	}
	
	private void addTransition(int sourceId, String atom, int targetId) {
		FAState source = stateMap.get(sourceId); 
		FAState target = stateMap.get(targetId);
        Integer index = getValue(atom);
		automaton.addTransition(source, target, getLetter(index));
	}

	@Override
	public void notifyEndOfState(int stateId) throws HOAConsumerException {
		labelExpr = null;
	}

	@Override
	public void notifyEnd() throws HOAConsumerException {	
		// so check multiple initial state
		FAState initState = null;
		if(inits.cardinality() > 1) {
			initState = automaton.createState();
			for(int stateNr = inits.nextSetBit(0)
					; stateNr >= 0
					; stateNr = inits.nextSetBit(stateNr + 1)) {
				FAState state = stateMap.get(stateNr);
				Iterator<String> nextStrIt = state.nextIt();
				while(nextStrIt.hasNext()) {
					String label = nextStrIt.next();
					Set<FAState> succStates = state.getNext(label);
					for(FAState succState : succStates) {
						automaton.addTransition(initState, succState, label);
					}
				}
			}
		}else {
			initState = stateMap.get(inits.nextSetBit(0));
		}
		automaton.setInitialState(initState);
	}

	@Override
	public void notifyAbort() {		
	}

	@Override
	public void notifyWarning(String warning) throws HOAConsumerException {		
	}

}
