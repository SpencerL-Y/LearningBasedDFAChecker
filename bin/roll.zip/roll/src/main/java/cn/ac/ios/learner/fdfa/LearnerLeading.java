/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.learner.fdfa;

import java.util.List;

import cn.ac.ios.automata.words.Word;

import cn.ac.ios.query.Query;
import cn.ac.ios.table.ExprValue;

public interface LearnerLeading extends LearnerGeneral {
	
	List<Word> getNewStates();

	
	default ExprValue normalize(Query<Boolean> query) {
		Word wordLeft = query.getPrefix();
		Word wordRight = query.getSuffix();
		Word wordPeriod = wordRight;
		int stateCurr, statePrev = computeReachState(getHypothesis().getInitialStates().nextSetBit(0), wordLeft);
		stateCurr = computeReachState(statePrev, wordRight);
		int i, j = 1;
		for(i = 1; i + i + 1 <= getHypothesis().getNumStates() + 1; i ++) {
			if(stateCurr == statePrev) break;   // get out the loop
			wordLeft = wordLeft.concat(wordRight);     // i
			statePrev = computeReachState(statePrev, wordRight);
			for(j = i + 1; i + j <= getHypothesis().getNumStates() + 1; j ++ ) {
				Word period = wordPeriod.concat(wordRight); // j
				stateCurr = computeReachState(statePrev, period);
				wordPeriod = period;
				if(stateCurr == statePrev) {
					break;
				}
			}
		}
		
		return getExprValueWord(wordLeft, wordPeriod);
	}
	
}
