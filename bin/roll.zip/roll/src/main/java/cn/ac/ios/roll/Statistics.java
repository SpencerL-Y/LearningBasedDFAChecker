/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.roll;

import java.util.ArrayList;
import java.util.List;

import automata.FiniteAutomaton;
import cn.ac.ios.automata.Acceptor;
import cn.ac.ios.automata.Automaton;
import cn.ac.ios.learner.Learner;
import cn.ac.ios.learner.buechi.ldollar.LearnerOmegaBuechi;
import cn.ac.ios.learner.fdfa.LearnerFDFA;
import cn.ac.ios.options.Options;
import cn.ac.ios.oracle.Minimizer;
import cn.ac.ios.util.AutomatonPrinter;

public class Statistics {
	
	public static void reset() {
		
//		numStatesTarget = 0;
//		numTransTarget = 0;
		
//		numStatesHypothesis = 0;
		numTransHypothesis = 0;
		
		numMembershipQuery = 0;
		numEquivalenceQuery = 0;
		
		numStatesLeading = 0;
		numStatesProgress = null;
		
		timeMembershipQuery = 0;
		timeEquivalenceQuery = 0;
		timeTranslator = 0;
		timeLearner = 0;
		timeTotal = 0;
		
		numSamplingOmegaWord = 0;
		
	}
	
//	public static int numStatesTarget ;  // number of states in target automaton
//	public static int numTransTarget ;   // number of transitions in target automaton
	
//	public static int numStatesHypothesis ; // number of states in hypothesis
	public static int numTransHypothesis  ; // number of transitions in hypothesis
	
	public static int numMembershipQuery ; // number of membership query
	public static int numEquivalenceQuery ; // number of equivalence query
	
	public static int numStatesLeading; // number of states in leading automaton
	public static List<Integer> numStatesProgress; // number of states in progress automata
	
	
	public static long timeMembershipQuery ; // milliseconds used in membership query 
	public static long timeEquivalenceQuery ;// milliseconds used in equivalence query
	public static long timeLastEquivalenceQuery; // time for last eq check
	public static long timeTotal; // milliseconds used in learning
	public static long timeTranslator; // milliseconds used in CE translation
	public static long timeLearner; // milliseconds used in FDFA learner
	
	public static long timeLearnerLeading; // milliseconds used in FDFA learner for leading automaton
	public static long timeLearnerProgress; // milliseconds used in FDFA learner for progress automata
	
	public static long timeMinimizationBuechi; // milliseconds used in Buechi minimization before eq check
	public static long timeSampling; //milliseconds used in sampling
	public static int numMembershipSampling; // number of membership queries in sampling
	public static int numSamplingSucceeded; // number of sampling succeeded
	public static int numSamplingTried; // number of sampling we tried
	
	// sampling as the teacher
	public static long numSamplingOmegaWord;
	
	// store automaton information
	public static FiniteAutomaton target; // target automaton
	public static FiniteAutomaton hypothesis; // final hypothesis
	public static FiniteAutomaton ldba ; // LDBA output
	
	public static void print() {

		Options.log.println("");
		Options.log.println("");
		Options.log.println("#T.S = " + target.states.size() + "    //#states of target");
		Options.log.println("#T.T = " + target.trans + "    //#transitions of target");
		
		Options.log.println("#H.S = " + hypothesis.states.size() + "    //#states of learned automaton");
//		Options.log.println("#H.T = " + numTransHypothesis + "    //#transitions of learned automaton");
		Options.log.println("#H.T = " + hypothesis.trans + "    //#transitions of learned automaton");
		

		int numTotal = numStatesLeading;
		Options.log.println("#L.S = " + numStatesLeading + "    // #states of leading automaton or L$");
		Options.log.print("#P.S = [" );
		for(Integer numStates : numStatesProgress) {
			Options.log.print(numStates + ", ");
			numTotal += numStates;
		}
		Options.log.println(" ]    // #states of each progress automaton");
		// total number of the states in final FDFA
		Options.log.println("#F.S = " + numTotal + "    // #L.S + #P.S");
		
		if(Options.outLDBA && ldba != null) {
			Options.log.println("#LDBA.S = " + ldba.states.size() + "    // #states of LDBA");
			Options.log.println("#LDBA.T = " + ldba.trans + "     // #transitions of LDBA");
		}
		
		Options.log.println("#MQ = " + numMembershipQuery + "    // #membership query");
		Options.log.println("#EQ = " + numEquivalenceQuery + "    // #equivalence query");
		
		if(Options.teacherSampling) {
			Options.log.println("#ST.W = " + numSamplingOmegaWord);
		}
		
		Options.log.println("#TMQ = " + timeMembershipQuery + " (ms)" + "    // time for membership queries");
		Options.log.println("#TEQ = " + timeEquivalenceQuery + " (ms)" + "    // time for equivalence queries");
		Options.log.println("#TLEQ = " + timeLastEquivalenceQuery + " (ms)" + "    // time for the last equivalence query");
		Options.log.println("#TTR = " + timeTranslator + " (ms)" + "    // time for the translator");
		
		Options.log.println("#TLR = " + timeLearner + " (ms)" + "    // time for the learner");
		Options.log.println("#TLRL = " + timeLearnerLeading + " (ms)"  + "    // time for the learning leading automaton" );
		Options.log.println("#TLRP = " + timeLearnerProgress + " (ms)" + "    // time for the learning progress automata" );
		
		if(Options.sampleFdfa) {
			Options.log.println("#MQ.S = " + numMembershipSampling);
			Options.log.println("#SA.T = " + numSamplingTried);
			Options.log.println("#SA.S = " + numSamplingSucceeded);
			Options.log.println("#TSA = " + timeSampling);
		}
		
		Options.log.println("#TMB = " + timeMinimizationBuechi + " (ms)" + "    // time for minimizing Buechi automata");
		
		Options.log.println("#TTO = " + timeTotal + " (ms)" + "    //total time for learning Buechi automata");
		
		
//		Options.log.println("target automaton: ");
//		AutomatonPrinter.print(targetAut, Options.log);
			
//		Options.log.println("final automaton learned: ");
//		AutomatonPrinter.print(hypothesis, Options.log);
//		Options.log.println("minimized automaton: ");
//		FiniteAutomaton minAut = Minimizer.minimizeBuechi(hypothesis, 12);
//		Options.log.println("#MH.S = " + minAut.states.size());
//		Options.log.println("#MH.T = " + minAut.trans);
//		AutomatonPrinter.print(minAut, Options.log);
		
//		if(Options.outLDBA && ldba != null) {
//			Options.log.println("final LDBA learned: ");
//			AutomatonPrinter.print(ldba, Options.log);
//		}
		
	}
	
	public static void setLearnerFDFA(Learner<? extends Acceptor, Boolean> learner) {
		numStatesProgress = new ArrayList<>();
		if(learner instanceof LearnerFDFA) {
			LearnerFDFA learnerFDFA = (LearnerFDFA)learner;
			numStatesLeading = learnerFDFA.getLeadingAutomaton().getNumStates();
			for(int autNr = 0; autNr < learnerFDFA.getNumProgressAutomata(); autNr ++) {
				numStatesProgress.add(learnerFDFA.getProgressAutomaton(autNr).getNumStates());
			}
		}else {
			LearnerOmegaBuechi learnerBuechi = (LearnerOmegaBuechi)learner;
			numStatesLeading = learnerBuechi.getLDollarLearner().getHypothesis().getNumStates();
		}
	}
	

}
