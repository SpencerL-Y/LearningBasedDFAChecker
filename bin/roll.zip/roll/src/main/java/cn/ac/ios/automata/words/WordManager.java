/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.automata.words;

import cn.ac.ios.value.ValueManager;
import cn.ac.ios.value.Type;
import cn.ac.ios.value.Value;

public final class WordManager {
	
	private final Word epsilon;
	private final Alphabet alphabet;
	private final ValueManager contextValue ;
	private Value letterSplitter ; /* used to parse an input string */
	private static final String SYM_DOLLAR = "$";
//	private final Value valueEpsilon ;
	
	public WordManager(ValueManager contextValue) {
		assert contextValue != null;
		this.contextValue = contextValue;
		this.epsilon = new WordEmpty(this);
		this.alphabet = new AlphabetSimple();
//		this.valueEpsilon = contextValue.newTypeObject(String.class).newValue("ϵ");
	}
	
	public Alphabet getAlphabet() {
		return alphabet;
	}
	
	public Word getEmptyWord() {
		return epsilon;
	}
	
	public Word getLetterWord(int letter) {
		return new WordLetter(this, letter);
	}
	
//	public Value getLetterEpsilon() {
//		return valueEpsilon;
//	}
	
	public int getNumLetters() {
		return alphabet.size();
	}
	
	public Word getArrayWord(int ... word) {
		return new WordArray(this, word);
	}
	
	public void setLetterSplitter(Value splitter) {
		letterSplitter = splitter.clone();
	}
	
	public int addNewLetter(Value letter) {
		alphabet.add(letter);
		return alphabet.indexOf(letter);
	}
	
	public ValueManager getContextValue() {
		return contextValue;
	}
	
	public static String getStringDollar() {
		return SYM_DOLLAR;
	}
	
	public Word getWordFromString(String string, String splitter) {
		assert string != null ;
		Type typeLetter = contextValue.getTypeLetter();
		Value valueLetter = typeLetter.newValue();
		String[] wordStr = string.split(splitter);
		int[] word = new int[wordStr.length];
		for(int index = 0; index < wordStr.length; index ++) {
			valueLetter.set(wordStr[index]);
			int letter = alphabet.indexOf(valueLetter);
			if(letter == -1) return null;
			word[index] = letter;
		}
		
		return getArrayWord(word);
	}
	
	public Word getWordFromString(String string) {
		assert string != null ;
		if(string.equals("")) return epsilon;
		String splitter = letterSplitter.getObject();
		return getWordFromString(string, splitter);
	}
	
	public String letterToString(int letter) {
		return alphabet.get(letter).toString();
	}

}
