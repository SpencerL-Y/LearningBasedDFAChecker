package cn.ac.ios.automata.parser;

public enum FormatType {
	
	BA,  // Buechi format proposed by RABIT
	 
	HOA  // Hanoi Omega Automata Format
 
}
