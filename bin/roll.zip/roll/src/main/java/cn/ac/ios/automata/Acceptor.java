package cn.ac.ios.automata;

/**
 * Acceptor for regular (omega) language 
 * */
public interface Acceptor {
	
	AccType getAccType();
	
	default FDFA asFDFA() {
		return (FDFA)this;
	}
	
	default DFA asDFA() {
		return (DFA)this;
	}
	
	default NFA asNFA() {
		return (NFA)this;
	}
	// and so on

}
