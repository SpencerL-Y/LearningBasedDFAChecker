package cn.ac.ios.roll;

import automata.FiniteAutomaton;
import cn.ac.ios.automata.Acceptor;
import cn.ac.ios.learner.Learner;
import cn.ac.ios.learner.UtilLearner;

import cn.ac.ios.learner.fdfa.LearnerFDFA;

import cn.ac.ios.log.Log;
import cn.ac.ios.options.Options;
import cn.ac.ios.oracle.Minimizer;
import cn.ac.ios.oracle.teacher.Teacher;
import cn.ac.ios.oracle.teacher.UtilTeacher;

import cn.ac.ios.query.Query;
import cn.ac.ios.roll.translator.Translator;

import cn.ac.ios.roll.translator.UtilTranslator;
import cn.ac.ios.util.BuechiBuilder;
import cn.ac.ios.util.Timer;
import cn.ac.ios.util.UtilAutomaton;
import oracle.EqResult;

// automatic execution with RABIT

public final class AutoExecution {
	
	public static void execute(FiniteAutomaton target) {
		
		Teacher<FiniteAutomaton, EqResult, Boolean> teacher = UtilTeacher.prepareTeacher(target);
		
		Learner<? extends Acceptor, Boolean> learner = UtilLearner.prepareLearner(Options.wordManager, teacher);
		
		Translator translator = UtilTranslator.prepareTranslator(learner, teacher);
		
		executeLearningLoop(learner, teacher, translator);
		
	}
    
    private static void executeLearningLoop(Learner<? extends Acceptor, Boolean> learner
    		, Teacher<FiniteAutomaton, EqResult, Boolean> teacher
    		, Translator translator) {
    	
		Log log = Options.log;
		
		// execute the learning loop
		log.info("Start learning...");

		Timer timer = new Timer();
		timer.start();
		learner.startLearning();
		timer.stop();
		Statistics.timeLearner += timer.getTimeElapsed();
		
		boolean result = false;
		while(! result ) {
			log.verbose("learner output: " + learner.toString());
			
			FiniteAutomaton hypothesis = UtilAutomaton.convertToRabitAut(learner);;
			
			// whether to minimize the automaton before ask equivalence
			if(Options.minimizationBuechi) {
				timer.start();
				// maybe we can set the number of step to look ahead
				hypothesis = Minimizer.minimizeBuechi(hypothesis, 12);
				timer.stop();
				Statistics.timeMinimizationBuechi += timer.getTimeElapsed();
			}
			
			// answer the equivalence query
			Query<EqResult> query = teacher.answerEquivalenceQuery(hypothesis);

			// get out of the loop
			if(query.getQueryAnswer().isEqual == true) {
				Statistics.setLearnerFDFA(learner);
				Statistics.hypothesis = hypothesis;
				break;
			}
			
			// lazy equivalence check is implemented here
			translator.setQuery(query);
			while(translator.canRefine()) {
				Query<Boolean> ceQuery = translator.translate();
				timer.start();
				learner.refineHypothesis(ceQuery);
				timer.stop();
				Statistics.timeLearner += timer.getTimeElapsed();
				log.verbose("learner output: " + learner.toString());
				// if do not set lazy eq check or it is learnerBuechi
				if(! Options.lazyEqCheck) break;
			}

		}
		
		if(Options.outLDBA && (learner instanceof LearnerFDFA)) {
			Statistics.ldba = BuechiBuilder.buildLDBA((LearnerFDFA)learner);
		}
		
		log.info("Learning completed...");
    }
	
	
	private AutoExecution() {
		
	}
	
	

}
