/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.learner.kvtree;


import java.util.ArrayList;
import java.util.BitSet;

import java.util.List;


import cn.ac.ios.automata.Automaton;
import cn.ac.ios.automata.DFA;
import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.automata.words.Word;
import cn.ac.ios.learner.Learner;
import cn.ac.ios.learner.LearnerType;
import cn.ac.ios.query.MembershipOracle;
import cn.ac.ios.query.Query;
import cn.ac.ios.query.QuerySimple;
import cn.ac.ios.table.ExprValue;
import cn.ac.ios.table.ExprValueWord;
import cn.ac.ios.table.HashableValue;
import cn.ac.ios.table.HashableValueBoolean;
import cn.ac.ios.tree.LCA;
import cn.ac.ios.tree.Node;

import gnu.trove.iterator.TIntObjectIterator;
import gnu.trove.map.TIntIntMap;
import gnu.trove.map.TIntObjectMap;
import gnu.trove.map.hash.TIntIntHashMap;
import gnu.trove.map.hash.TIntObjectHashMap;


public class LearnerTreeKV implements Learner<Automaton, Boolean> {

	private WordManager contextWord;
	private MembershipOracle<Boolean> membershipOracle;
	private TreeKV<State> treeKV;
	private boolean alreadyStarted = false;
	private Automaton hypothesis;
	
	public LearnerTreeKV(WordManager contextWord,
			MembershipOracle<Boolean> membershipOracle) {
		assert contextWord != null && membershipOracle != null;
		this.contextWord = contextWord;
		this.membershipOracle = membershipOracle;
	}
	
	@Override
	public LearnerType getLearnerType() {
		return LearnerType.TREEKV;
	}

	@Override
	public void startLearning() {
		if(alreadyStarted)
			try {
				throw new Exception("Learner should not be started twice");
			} catch (Exception e) {
				e.printStackTrace();
			}
		alreadyStarted = true;
	}
	
	// later may be changed
	private boolean processMembershipQuery(Word word, Word expr) {
		Query<Boolean> query = new QuerySimple<>(word, expr);
		return membershipOracle.answerMembershipQuery(query);
	}
	

	private Node<State> nodeToUpdate;
	
	
	@Override
	public Automaton getHypothesis() {
		return hypothesis;
	}
	
	protected Automaton constructHypothesis() {
		if(hypothesis == null) {
			hypothesis = initializeHypothesis();
		}else {
			// construct hypothesis according to KV tree
			if(nodeToUpdate == null) {
				initializeStates();
			}else {
				// only need to update one state
				updatePredecessors();
			}
			hypothesis = constructHypothesisFromStates();
		}
		return hypothesis;
	}
	
	private Automaton constructHypothesisFromStates() {
		Automaton dfa = new DFA(contextWord);
		
		for(State state : states) {
			dfa.addNewState(state.id);
			for(int letter = 0; letter < contextWord.getNumLetters(); letter ++) {
				dfa.addTransition(letter, state.getSuccessor(letter));
			}
			if(state.node.isAccepting()) {
				dfa.setAccepting();
			}
			if(state.label.isEmpty()) {
				dfa.setInitial();
			}
			dfa.addNewStateEnd();
		}
		
		return dfa;
	}
	
	private void updatePredecessors() {
		
		TIntObjectIterator<BitSet> iterator = nodeToUpdate.getValue().predecessors.iterator();
		Node<State> parent = nodeToUpdate.getParent();
		while(iterator.hasNext()) {
			iterator.advance();
			int letter = iterator.key();
			BitSet statePrevs = iterator.value();
			BitSet stateLeft = (BitSet) statePrevs.clone();
			for(int stateNr = statePrevs.nextSetBit(0)
					; stateNr >= 0
					; stateNr = statePrevs.nextSetBit(stateNr + 1)) {
				State statePrev = states.get(stateNr);
				Node<State> nodeOther = sift(statePrev.label.append(letter), parent);
				if (nodeOther != nodeToUpdate) {
					updateTransition(stateNr, letter, nodeOther.getValue().id);
					stateLeft.clear(stateNr);
				}
			}
			if(stateLeft.isEmpty()) {
				iterator.remove();
			}else {
				iterator.setValue(stateLeft);
			}
		}
		
	}

	private void initializeStates()   {
		for( State stateCurr : states ) {
			Word label = stateCurr.label;
			for(int letter = 0; letter < contextWord.getNumLetters(); letter ++) {
				Word wordSucc = label.append(letter);
				State stateSucc = sift(wordSucc).getValue();
				stateSucc.addPredecessor(stateCurr.id, letter);
				stateCurr.addSuccessor(letter, stateSucc.id);
			}
		}
	}

	@Override
	public void refineHypothesis(Query<Boolean> query) {
		if(treeKV == null) {
			initializeKVTree(query.getQueriedWord());
		}else {
			nodeToUpdate = updateKVTree(query.getQueriedWord());
		}
	}
	
	protected HashableValue getHashableValueBoolean(boolean value) {
		return new HashableValueBoolean(value);
	}
	
	protected ExprValue getExprValueWord(Word word) {
		return new ExprValueWord(word);
	}
	
	protected Node<State> getNodeBinaryState(Node<State> parent, HashableValue branch, Word label) {
		return new NodeBinary<State>(parent, branch, getExprValueWord(label));
	}
	
	private void initializeKVTree(Word wordCE) {
		Node<State> root = getNodeBinaryState(null, null,contextWord.getEmptyWord()); 
		treeKV = new TreeKV<State>(root);
		boolean isAccepted = hypothesis.isAccepted(contextWord.getEmptyWord());
		
		Node<State> nodeLamda = getNodeBinaryState(root
				, getHashableValueBoolean(isAccepted), contextWord.getEmptyWord());
		
		State stateLamda = states.get(0);
		stateLamda.node = nodeLamda;
		nodeLamda.setValue(stateLamda);
		
		Node<State> nodeCE = getNodeBinaryState(root, getHashableValueBoolean(!isAccepted), wordCE);
		State stateCE =  new State(states.size(), wordCE);
		states.add(stateCE);
		stateCE.node = nodeCE;
		nodeCE.setValue(stateCE);
		
		root.addChild(getHashableValueBoolean(isAccepted), nodeLamda);
		root.addChild(getHashableValueBoolean(!isAccepted), nodeCE);
		
		if(isAccepted) {
			nodeLamda.setAcceting();
		}else {
			nodeCE.setAcceting();
		}
	
		treeKV.setLamdaLeaf(nodeLamda);
	}
	
	// state should keep node info
	private Automaton initializeHypothesis() {

		Word wordEmpty = contextWord.getEmptyWord();
		// ask membership for empty word 
		boolean result = processMembershipQuery(wordEmpty, wordEmpty);
		// construct single state with self loops
		Automaton dfa = new DFA(contextWord);
		dfa.addNewState(0);
		dfa.setInitial();
		if(result) dfa.setAccepting();
		State initState = new State(0, wordEmpty);
		states.add(initState);
		for(int letter = 0; letter < contextWord.getNumLetters(); letter ++) {
			dfa.addTransition(letter, 0);
		}
		dfa.addNewStateEnd();
		
		return dfa;
	}
	
	// updates for KV tree
    private List<State> states = new ArrayList<>();
	// get corresponding 
	private Node<State> sift(Word word) {
 		return sift(word, treeKV.getRoot());
	}
	
	private Node<State> sift(Word word, Node<State> nodeCurr) {
		while(! nodeCurr.isLeaf()) {
			ExprValue exprValue = nodeCurr.getLabel();
			Boolean result = processMembershipQuery(word, exprValue.get());
			nodeCurr = nodeCurr.getChild(getHashableValueBoolean(result));
		}

		return nodeCurr;
	}


	// word will never be empty word
	private Node<State> updateKVTree(Word word) { 
		
		CeAnalyzer analyzer = new CeAnalyzer(word);
		analyzer.analyze();
		
		Node<State> nodeCurr = analyzer.nodeCurr,
				    nodePrev = analyzer.nodePrev;
		int length = analyzer.length;
		
		// update KV tree
		// get common ancestor for nodeCurr and stateCurr.node
		LCA<State> lca = treeKV.getLCA(nodeCurr, analyzer.stateCurr.node);
		
		HashableValue branchNodeLeaf, branchNodePrev ;
		if (lca.firstChild == nodeCurr) {
			branchNodeLeaf = lca.firstBranch;
			branchNodePrev = lca.secondBranch;
		}else {
			branchNodeLeaf = lca.secondBranch;
			branchNodePrev = lca.firstBranch;
		}
		
		// replace nodePrev with new experiment node nodeExpr 
		// and two child r[1..length-1] and nodePrev
		
		Word wordExpr = lca.commonAncestor.getLabel().get();
		Node<State> parent = nodePrev.getParent();
		// new experiment word
		wordExpr = word.getLetterWord(word.getLetter(length - 1)).concat(wordExpr); 
		
		Node<State> nodeExpr = getNodeBinaryState(parent, nodePrev.fromBranch(), wordExpr); // replace nodePrev
		parent.addChild(nodePrev.fromBranch(), nodeExpr);
		
		// state for r[1..length-1]
		Node<State> nodeLeaf = getNodeBinaryState(nodeExpr, branchNodeLeaf, word.getPrefix(length - 1));
		State stateLeaf =  new State(states.size(), word.getPrefix(length - 1));
		stateLeaf.node = nodeLeaf;
		nodeLeaf.setValue(stateLeaf);
		states.add(stateLeaf); // add new state
		
		Node<State> nodePrevNew = getNodeBinaryState(nodeExpr, branchNodePrev, nodePrev.getLabel().get());
		nodePrevNew.setValue(nodePrev.getValue()); // To update
		nodePrevNew.getValue().node = nodePrevNew; // update node
		
		nodeExpr.addChild(branchNodeLeaf, nodeLeaf);
		nodeExpr.addChild(branchNodePrev, nodePrevNew);
		
		// update transitions for nodeLeaf
		int letter = word.getLetter(length - 1);
		updateSuccessors(stateLeaf.id, 0, letter - 1);
		updateSuccessors(stateLeaf.id, letter + 1, contextWord.getNumLetters() - 1);
		stateLeaf.addSuccessor(letter, nodeCurr.getValue().id);
		nodeCurr.getValue().addPredecessor(stateLeaf.id, letter);
		
		if(nodePrev.isAccepting()) {
			nodeLeaf.setAcceting();
			nodePrevNew.setAcceting();
		}
		
		return nodePrevNew;
	}
	
	private void updateSuccessors(int stateNr, int letterFrom, int letterTo) {
		assert stateNr < states.size() 
	    && letterFrom >= 0
	    && letterTo < contextWord.getNumLetters();
		
		State state = states.get(stateNr);
		
		Word label = state.label;
		for(int letter = letterFrom; letter <= letterTo; letter ++) {
			Word wordSucc = label.append(letter);
			Node<State> nodeSucc = sift(wordSucc);
			updateTransition(stateNr, letter, nodeSucc.getValue().id);
		}
		
	}
	
	
	private int computeNextState(int state, int letter) {
		return hypothesis.getSuccessors(state, letter).nextSetBit(0);
	}
	
	private void updateTransition(int from, int letter, int to) {
		assert from < states.size() 
		    && to < states.size() 
		    && letter < contextWord.getNumLetters();
		
		states.get(from).addSuccessor(letter, to);
		states.get(to).addPredecessor(from, letter);
	}
	
	// right now, we can store state information in the leaves
    // needs to store incoming nodes, in order to reduce the
	// number of membership queries
	// outgoing nodes to construct hypothesis
	private final class State {
		public final int id;
		public Node<State> node;
		public final Word label;  // is this needed?
		public TIntObjectMap<BitSet> predecessors;
		public TIntIntMap successors;
		
		public State(int id, Word label) {
			this.id = id;
			this.label = label;
			predecessors = new TIntObjectHashMap<>();
			successors = new TIntIntHashMap();
		}
		
		public void addPredecessor(int source, int letter) {
			if(predecessors.containsKey(letter)) {
				BitSet states = predecessors.get(letter);
				states.set(source);
			}else {
				BitSet states = new BitSet();
				states.set(source);
				predecessors.put(letter, states);
			}
		}
		
		public void addSuccessor(int letter, int target) {
			successors.put(letter, target);
		}
		
		public int getSuccessor(int letter) {
			if(successors.containsKey(letter)) 
			  return successors.get(letter);
			assert false : "no such letter key";
			return -1;
		}
		
		public String toString() {
			return id + " : " + label.toStringWithAlphabet();
		}
	}
	
	// analyze counterexample
	private class CeAnalyzer {
		
		public final Word wordCE; 
		public Node<State> nodePrev = treeKV.getLamdaLeaf();
		public Node<State> nodeCurr = null;
		public State stateCurr = null;
		
		public int length;
		
		public CeAnalyzer(Word wordCE) {
			this.wordCE = wordCE;
		}
		
		// find prefix whose successor needs to be added
		public void analyze() {
			 // get the initial state from automaton
			int stateIndex = hypothesis.getInitialStates().nextSetBit(0);
			
			for(length = 1; length <= wordCE.length(); length ++) {
				Word prefix = wordCE.getPrefix(length);
				nodeCurr = sift(prefix);
				Word wordNodeLabel = nodeCurr.getLabel().get();
				stateIndex = computeNextState(stateIndex, wordCE.getLetter(length - 1));
				stateCurr = states.get(stateIndex);
				if(wordNodeLabel.equals(stateCurr.label)) {
					nodePrev = nodeCurr;
					continue;
				}else {
					break;
				}
			}
		}
	}
	
	public String toString() {
		return treeKV.toString();
	}
	
}
