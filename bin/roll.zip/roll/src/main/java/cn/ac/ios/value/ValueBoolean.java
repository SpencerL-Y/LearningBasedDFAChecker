/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.value;


class ValueBoolean implements Value {

	private boolean value;
	private final Type type;
	private boolean immutable = true;
	
	ValueBoolean(Type type, boolean value) {
		assert type != null;
		this.type = type;
		this.value = value;
	}
	
	ValueBoolean(Type type) {
		this(type, false);
	}
	
	@Override
	public Value clone() {
		return new ValueBoolean(type, value);
	}

	@Override
	public Type getType() {
		return type;
	}
	@Override
	public void setImmutable() {
		immutable = true;
	}
	
	@Override
	public boolean isImmutable() {
		return immutable;
	}
	
    public boolean getBoolean() {
        return value;
    }

    public boolean isBoolean() {
        return true;
    }
    
    public void not(Value operand)  {
    	assert operand != null;
    	assert operand.isBoolean();
    	
    	set(! operand.getBoolean());
    }
    
    public void set(boolean value) {
    	assert ! isImmutable();
    	this.value = value;
    }
    
    public void set(Value value) {
    	assert value != null && ! isImmutable();
    	assert value.isBoolean();
    	
    	set(value.getBoolean());
    }
    
	public void set(Object value) {
		assert !isImmutable();
		assert value.getClass() == Boolean.class;
		this.value = (Boolean)value;
	}
    
    @Override
    public void set(String string) {
        assert string != null;
        value = Boolean.parseBoolean(string);
    }
    
    public void or(Value op1, Value op2) {
    	assert op1 != null && op1.isBoolean();
    	assert op2 != null && op2.isBoolean();
    	
    	set(op1.getBoolean() || op2.getBoolean());
    }
    
    public void and(Value op1, Value op2) {
    	assert op1 != null && op1.isBoolean();
    	assert op2 != null && op2.isBoolean();
    	
    	set(op1.getBoolean() && op2.getBoolean());    
    }
    
    public void implies(Value op1, Value op2) {
    	assert op1 != null && op1.isBoolean();
    	assert op2 != null && op2.isBoolean();
    	
    	set(!op1.getBoolean() || op2.getBoolean());  
    }
    
    public void iff(Value op1, Value op2) {
    	assert op1 != null && op1.isBoolean();
    	assert op2 != null && op2.isBoolean();
    	
    	set(!op1.getBoolean() == op2.getBoolean()); 
    }
    
    @Override
    public String toString() {
    	return Boolean.toString(value);
    }
    
    @Override
    public boolean equals(Object obj) {
        assert obj != null;
        if (!(obj instanceof ValueBoolean)) {
            return false;
        }
        ValueBoolean other = (ValueBoolean) obj;
        return this.value == other.value;
    }
    
    @Override
    public int hashCode() {
    	return value ? 1 : 0;
    }
    
}
