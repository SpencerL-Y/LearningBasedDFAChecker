package cn.ac.ios.automata.parser;

import gnu.trove.map.hash.TObjectCharHashMap;

/**
 * Key-Value pair <String, Character >
 * */
public class LetterMap extends TObjectCharHashMap<String> {
	
	
}
