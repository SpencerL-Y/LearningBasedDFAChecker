/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.automata;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.BitSet;

import cn.ac.ios.automata.words.Alphabet;

public class AutomataExporterDOT {//doublecircle
    public static void export(Automaton automata, OutputStream stream) {

        PrintStream out = new PrintStream(stream);
        AccType modelType = automata.getAccType();
        out.println("//" + modelType);
        out.println("digraph {");
        int startNode = automata.getNumStates();
        for (int node = 0; node < automata.getNumStates(); node++) {
            out.print("  " + node + " [label=\"" + node + "\"");
            if(automata.isAccepted(node)) out.print(", shape = doublecircle");
            else out.print(", shape = circle");
            out.println("];");
        }	
        out.println("  " + startNode + " [label=\"\", shape = plaintext];");
        out.println();
        BitSet initStates = automata.getInitialStates();
        Alphabet alphabet = automata.getAlphabet();
        for (int node = 0; node < automata.getNumStates(); node++) {
        	if(initStates.get(node)) {
        		out.println("  " + startNode + " -> " + node + " [label=\"\"];");
        	}
        	for(int letter = -1; letter < alphabet.size(); letter ++) {
        		BitSet succs = automata.getSuccessors(node, letter);
        		for(int succ = succs.nextSetBit(0); succ >= 0; succ = succs.nextSetBit(succ + 1)) {
        			out.println("  " + node + " -> " + succ + " [label=\"" + alphabet.get(letter) + "\"];");
        		}
        	}
        }

        out.println("}");
    }
    
    public static String toString(Automaton automata) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try {
            export(automata, out);
            return out.toString();
        } catch (Exception e) {
            return "ERROR";
        }
    }
}
