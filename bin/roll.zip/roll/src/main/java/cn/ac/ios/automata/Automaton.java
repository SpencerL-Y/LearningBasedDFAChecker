/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.automata;

import java.util.BitSet;

import cn.ac.ios.automata.words.Alphabet;
import cn.ac.ios.automata.words.Word;

// currently only support for DFA, NFA, BUECHI
public interface Automaton extends Acceptor {
	
	Alphabet getAlphabet();
	
	int getNumStates();
	
	BitSet getInitialStates();
	
	default int getInitialState() {
		return getInitialStates().nextSetBit(0);
	}
	
	default boolean isAccepted(Word word) {
		return isAccepted(computeReachedStates(word));
	}
	
	BitSet getSuccessors(int state, int letter);
	
	default int getSuccessor(int state, int letter) {
		return getSuccessors(state, letter).nextSetBit(0);
	}
	
	default boolean isAccepted(int state, Word word) {
		BitSet startStates = new BitSet(getNumStates());
		startStates.set(state);
		return isAccepted(computeReachedStates(startStates, word));
	}
	
	default BitSet computeReachedStates(Word word) {
		return computeReachedStates(getInitialStates(), word);
	}
	
	default int computeReachedState(Word word) {
		return computeReachedState(getInitialState(), word);
	}
	
	default int computeReachedState(int startState, Word word) {
		int currentState = startState;
		int index = 0;
		while(index < word.length()) {			
			currentState = getSuccessor(currentState, word.getLetter(index));
			++ index;
		}
		return currentState;
	}
	
	default BitSet computeReachedStates(BitSet startStates, Word word) {
		BitSet currentStates = startStates;
		
		int index = 0;
		while(index < word.length()) {
			BitSet nextStates = new BitSet(getNumStates());
			for(int stateNr = currentStates.nextSetBit(0)
					; stateNr >= 0
					; stateNr = currentStates.nextSetBit(stateNr + 1)) {
				nextStates.or(getSuccessors(stateNr, word.getLetter(index)));
			}
			currentStates = nextStates;
			++ index;
		}
		
		return currentStates;
	}
	
	default boolean isAccepted(BitSet states) {
		for(int stateNr = states.nextSetBit(0)
				; stateNr >= 0
				; stateNr = states.nextSetBit(stateNr + 1)) {
			if(isAccepted(stateNr)) return true;
		}
		return false;
	}
	
	BitSet getAcceptingStates();
	
	boolean isAccepted(int state);
	
	// add states
	void addNewState(int number);
	void addTransition(int letter, int to);
	void addTransition(int letter, BitSet tos);
	void setAccepting();
	void setInitial();
	void addNewStateEnd();
	

}
