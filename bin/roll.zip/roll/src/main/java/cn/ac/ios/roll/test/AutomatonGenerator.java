/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.roll.test;

import java.util.Random;
import java.util.TreeMap;

import automata.FAState;
import automata.FiniteAutomaton;

// randomly generate automaton, possibly can be interpreted as NFA or Buechi automaton

public class AutomatonGenerator {

	public static FiniteAutomaton getRandomAutomaton(int numState, int numLetter) {
    	
    	assert numLetter <= 5: "only allow a,b,c,d,e";
    	
		FiniteAutomaton result = new FiniteAutomaton();
		TreeMap<Integer,FAState> st=new TreeMap<Integer,FAState>();

		Random r = new Random();
		
		for(int i = 0; i < numState; i ++) {
			st.put(i, result.createState());
		}
		
		result.setInitialState(st.get(0));
		
		// final states
		int numF = r.nextInt(numState-1);
		numF = numF > 0 ? numF : 1;
		for(int n = 0; n < numF ; n ++) {
			int f = r.nextInt(numF);
			if(f != 0)
				result.F.add(st.get(f));
		}
		
		if(result.F.isEmpty()) {
			result.F.add(st.get(numF));
		}
		
		int numTrans = r.nextInt(numState * numLetter);

		String[] alphabet = {"a", "b", "c", "d", "e"};
		
		// transitions
		for(int k=0 ; k < numLetter && k < 5; k++){
			for(int n = 0; n < numTrans; n++ ){
				int i=r.nextInt(numState);
				int j=r.nextInt(numState);
				result.addTransition(st.get(i), st.get(j), alphabet[k]);
			}
		}
				
		return result;
	}
}
