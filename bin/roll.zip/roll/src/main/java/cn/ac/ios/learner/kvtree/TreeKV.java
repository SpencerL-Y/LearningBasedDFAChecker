/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.learner.kvtree;

import cn.ac.ios.tree.Node;
import cn.ac.ios.tree.Tree;
import cn.ac.ios.tree.TreeBinaryExpoterDOT;
/**
 * Classification Tree by Kearns & Vazirani
 * from "An Introduction to Computational Learning Theory"
 * */
class TreeKV<V> implements Tree<V> {

	private final Node<V> root;
	
	private Node<V> lamdaLeaf;
	
	//private LearnerTreeKV learner;
	public TreeKV(Node<V> root) {
		this.root = root;
	}
	
	protected void setLamdaLeaf(Node<V> lamda) {
		this.lamdaLeaf = lamda;
	}
	
	protected Node<V> getLamdaLeaf() {
		return lamdaLeaf;
	}

	@Override
	public Node<V> getRoot() {
		return root;
	}
	
	public String toString() {
		return TreeBinaryExpoterDOT.toString(this);
	}

}
