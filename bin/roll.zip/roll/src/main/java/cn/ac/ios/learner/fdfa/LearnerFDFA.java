/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.learner.fdfa;

import java.util.ArrayList;
import java.util.List;

import cn.ac.ios.options.Options;
import cn.ac.ios.automata.Acceptor;
import cn.ac.ios.automata.Automaton;
import cn.ac.ios.automata.DFA;
import cn.ac.ios.automata.FDFA;
import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.automata.words.Word;
import cn.ac.ios.learner.Learner;
import cn.ac.ios.learner.LearnerType;

import cn.ac.ios.query.MembershipOracle;
import cn.ac.ios.query.Query;
import cn.ac.ios.query.QuerySimple;
import cn.ac.ios.roll.Statistics;
import cn.ac.ios.table.ExprValue;
import cn.ac.ios.util.Timer;

/**
 * From the paper "Learning Regular Omega Language"
 * */
public abstract class LearnerFDFA implements Learner<Acceptor, Boolean> {

	protected LearnerLeading learnerLeading;
	protected List<LearnerProgress> learnerProgress;
	protected final MembershipOracle<Boolean>  membershipOracle;
	protected final WordManager contextWord;
	
	public LearnerFDFA(WordManager contextWord
			, MembershipOracle<Boolean> membershipOracle) {
		assert contextWord != null && membershipOracle != null;
		this.contextWord = contextWord;
		this.membershipOracle = membershipOracle;
		this.learnerProgress = new ArrayList<>();
	}
	
	@Override
	public LearnerType getLearnerType() {
		return LearnerType.FDFA;
	}
	
	protected abstract LearnerLeading getLearnerLeading();
	
	protected abstract LearnerProgress getLearnerProgress(Word label);
	
	protected abstract boolean isPeriodic();

	@Override
	public void startLearning() {

		learnerLeading = getLearnerLeading();
		Timer timer = new Timer();
		timer.start();
		learnerLeading.startLearning();
		timer.stop();
		Statistics.timeLearnerLeading += timer.getTimeElapsed();
		
		
		for(int stateNr = 0; stateNr < learnerLeading.getHypothesis().getNumStates(); stateNr ++ ) {
			LearnerProgress learner = getLearnerProgress(learnerLeading.getStateLabel(stateNr));
			learnerProgress.add(learner);
			learner.setLearnerLeading(learnerLeading);
			timer.start();
			learner.startLearning();
			timer.stop();
			Statistics.timeLearnerProgress += timer.getTimeElapsed();
		}


	}

	/** construct FDFA */
	@Override
	public Acceptor getHypothesis() {
		DFA leadDFA = (DFA)learnerLeading.getHypothesis();
		List<DFA> proDFAs = new ArrayList<>();
		List<String> labels = new ArrayList<>();
		for(LearnerProgress learner : learnerProgress) {
			DFA progressDFA = (DFA)learner.getHypothesis();
			proDFAs.add(progressDFA);
			labels.add(learner.getLeadingLabel().toStringWithAlphabet());
		}
		FDFA fdfa = new FDFA(leadDFA, proDFAs);
		fdfa.setLeadingLabels(labels);
		return fdfa;
	}
	

	// refine FDFA by counter example
	@Override
	public void refineHypothesis(Query<Boolean> query) {
		
		ExprValue expr = learnerLeading.normalize(query);
//		ExprValue expr = learnerLeading.getExprValueWord(query.getPrefix(), query.getSuffix());
		if(Options.verbose) {
			System.out.println("normalized factorization: " + expr.toString());
		}
		Word label = learnerLeading.getStateLabel(expr.getLeft());
		Query<Boolean> queryLabel = new QuerySimple<Boolean>(label, expr.getRight());
		boolean resultLabel = membershipOracle.answerMembershipQuery(queryLabel);
		Query<Boolean> queryLeading = new QuerySimple<Boolean>(expr.getLeft(), expr.getRight());
		boolean resultCE = membershipOracle.answerMembershipQuery(queryLeading);
		queryLeading.answerQuery(resultCE);
		if(resultLabel != resultCE) { // refine leading automaton
			Timer timer = new Timer();
			timer.start();
			learnerLeading.refineHypothesis(queryLeading);
			timer.stop();
			Statistics.timeLearnerLeading += timer.getTimeElapsed();
			
			timer.start();
			if(! isPeriodic()) {
				for(LearnerProgress learner : learnerProgress) {
					learner.setLearnerLeading(learnerLeading);
					learner.startLearning();
				}
			}
			// new states, not just one (for table-based leading automaton)
			for(Word wordState : learnerLeading.getNewStates()) {
				LearnerProgress learner = getLearnerProgress(wordState);
				learner.setLearnerLeading(learnerLeading);
				learner.startLearning();
				learnerProgress.add(learner);
			}
			timer.stop();
			Statistics.timeLearnerProgress += timer.getTimeElapsed();
		}else { // refine progress automaton
			Timer timer = new Timer();
			timer.start();
			LearnerProgress learnerPro = null;
			for(LearnerProgress learner : learnerProgress) {
				if(learner.getLeadingLabel().equals(label)) {
					learnerPro = learner;
					break;
				}
			}
			learnerPro.refineHypothesis(queryLeading);
			timer.stop();
			Statistics.timeLearnerProgress += timer.getTimeElapsed();
		}
	}
	
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("T: \n" + learnerLeading.toString() + "\n");
		
		for(LearnerProgress learner : learnerProgress) {
			builder.append(learner.getLeadingLabel().toStringWithAlphabet() + ": \n");
			builder.append(learner.toString());
		}
		return builder.toString();
	}
	
	// -------------- some helper function
	public Word getProgressStateLabel(int stateLeading, int stateProgress) {
		return learnerProgress.get(stateLeading).getStateLabel(stateProgress);
	}
	
	public Word getLeadingStateLabel(int stateLeading) {
		return learnerLeading.getStateLabel(stateLeading);
	}
	
	public Automaton getLeadingAutomaton() {
		return learnerLeading.getHypothesis();
	}
	
	public Automaton getProgressAutomaton(int state) {
		assert state < learnerProgress.size();
		return learnerProgress.get(state).getHypothesis();
	}
	
	public int getNumProgressAutomata() {
		return learnerProgress.size();
	}

}
