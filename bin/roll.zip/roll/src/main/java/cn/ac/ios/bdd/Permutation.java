package cn.ac.ios.bdd;

import java.util.Collections;
import java.util.List;

import net.sf.javabdd.BDD;
import net.sf.javabdd.BDDPairing;

public class Permutation {
	
	private final List<BDD> presVars;
	private final List<BDD> nextVars;
	private final BDDManager bdd;
	private final BDDPairing bddPair;
	
	public Permutation(BDDManager bdd, List<BDD> pres, List<BDD> nexts) {
		assert pres.size() == nexts.size();
		presVars = pres;
		nextVars = nexts;
		this.bdd = bdd;
		this.bddPair = bdd.makeBDDPair(pres, nexts);
	}
	
	public BDDPairing getBDDPairing() {
		return bddPair;
	}
	
	public List<BDD> getPresVars() {
		return Collections.unmodifiableList(presVars);
	}
	
	public List<BDD> getNextVars() {
		return Collections.unmodifiableList(nextVars);
	}
	
	public BDDManager getBDDManager() {
		return bdd;
	}

}
