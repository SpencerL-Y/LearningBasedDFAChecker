/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.oracle.teacher;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

import cn.ac.ios.options.Options;
import cn.ac.ios.oracle.BuechiRunner;
import automata.FAState;
import automata.FiniteAutomaton;
import cn.ac.ios.automata.words.Alphabet;
import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.learner.fdfa.LearnerFDFA;
import cn.ac.ios.automata.words.Word;
import cn.ac.ios.query.Query;
import cn.ac.ios.query.QuerySimple;
import cn.ac.ios.roll.Statistics;
import cn.ac.ios.util.AutomatonPrinter;
import cn.ac.ios.util.BuechiBuilder;
import cn.ac.ios.util.Timer;
import cn.ac.ios.value.ValueManager;
import cn.ac.ios.value.Type;
import cn.ac.ios.value.Value;
import oracle.EqResult;
import oracle.InclusionChecker;
import oracle.IntersectionCheck;
import oracle.RabitOracle;

/**
 * Teacher for complementing Buechi automaton
 * */
public class TeacherBuechiC implements Teacher<LearnerFDFA, EqResult, Boolean> {
	private final InclusionChecker inclusionChecker;
	private final WordManager contextWord;
	private final FiniteAutomaton targetB;
	
	public TeacherBuechiC(WordManager contextWord, FiniteAutomaton targetAut) {
		assert targetAut != null && contextWord != null;
		this.contextWord = contextWord;
		this.targetB = targetAut;
		this.inclusionChecker = new InclusionChecker();
		if(Options.verbose) this.inclusionChecker.setVerbose();
		// initialize alphabet
		ValueManager contextValue = contextWord.getContextValue();
		Type typeString = contextValue.newTypeLetter(String.class);
		Value valueLetter = typeString.newValue();
		Alphabet alphabet = contextWord.getAlphabet();
		if(Options.learnerLDollar) {
			valueLetter.set(WordManager.getStringDollar());
			alphabet.add(valueLetter.clone());
		}
		for(String letter : targetAut.alphabet) {
			valueLetter.set(letter);
			alphabet.add(valueLetter.clone());
		}
		System.out.println("alphabet size: " + alphabet.size());
		alphabet.setImmutable();
		valueLetter.set("");
	    contextWord.setLetterSplitter(valueLetter);
	}
	
	@Override
	public Query<EqResult> answerEquivalenceQuery(LearnerFDFA learner) {
		EqResult result = new EqResult();
		Timer timer = new Timer();
		timer.start();
		String prefixStr = "";
		String suffixStr = "";

		System.out.println("Translating FDFA to Under Buechi automaton ...");
		FiniteAutomaton hypothesisA = BuechiBuilder.build(learner, true);
		Statistics.hypothesis = hypothesisA;
		++ this.numInterAandB;
		System.out.println("Checking the intersection of A (" + hypothesisA.states.size() + ") and B ("+ targetB.states.size() + ")...");
		long t = timer.getCurrentTime();
		IntersectionCheck checker = new IntersectionCheck(hypothesisA, targetB);
		boolean isEmpty = checker.checkEmptiness();
		t = timer.getCurrentTime() - t;
		this.timeInterAandB += t;
		if(Options.verbose) {
			System.out.println("Hypothesis for complementation");
			AutomatonPrinter.print(hypothesisA, System.out);
		}
		
		if(! isEmpty) {
			// we have omega word in FDFA which should not be there
			checker.computePath();
			for(String letter : checker.getPrefix()) {
				prefixStr += letter;
			}

			for(String letter : checker.getSuffix()) {
				suffixStr += letter;
			}
			
			result.isEqual = false;
			result.isCeInTarget = true;
			
		}else {
			// intersection check for A and not A
//			++ this.numInterAandNotA;
			FiniteAutomaton hypothesisNotA = BuechiBuilder.buildNegNFA(learner);
			/*
			System.out.println("Checking the intersection of A (" + hypothesisA.states.size() + "," + hypothesisNotA.trans + ") and not A ("+ hypothesisNotA.states.size() + "," + hypothesisNotA.trans + ")...");
			t = timer.getCurrentTime();
			checker = new IntersectionCheck(hypothesisNotA, hypothesisA);
			isEmpty = checker.checkEmptiness();
			t = timer.getCurrentTime() - t;
			this.timeAandNotA += t;
			if(Options.verbose) {
				System.out.println("Under approximation of FDFA complementation");
				AutomatonPrinter.print(hypothesisNotA, System.out);
			}*/
			isEmpty = true;
			if(! isEmpty) {
				// we have omega word in FDFA which should not be there
				checker.computePath();
				for(String letter : checker.getPrefix()) {
					prefixStr += letter;
				}

				for(String letter : checker.getSuffix()) {
					suffixStr += letter;
				}
				
				result.isEqual = false;
				result.isCeInTarget = BuechiRunner.isAccepting(targetB, checker.getPrefix(), checker.getSuffix());
			}else {
				System.out.println("Checking the inclusion for not A (" + hypothesisNotA.states.size() + ") and B ("+ targetB.states.size() + ")...");
				PrintStream outOld = System.out;
				redirectRabitOut();
			    // we have to resort to the equivalence check for hypothesisNotA
				++this.numInclusionNotAandB;
				t = timer.getCurrentTime();
				result.isEqual = inclusionChecker.isIncluded(hypothesisNotA, targetB);
				t = timer.getCurrentTime() - t;
				this.timeInclusionNotAandB += t;
				prefixStr = inclusionChecker.getPrefix();
				suffixStr = inclusionChecker.getSuffix();
					
//		    	}
		    	System.setOut(outOld);
			}
			
		}
		System.out.println("Done for checking equivalence...");
		Query<EqResult> query = null;
		result.isCeInTarget = ! result.isCeInTarget;
		
		if(result.isEqual) {
			query = new QuerySimple<>(contextWord.getEmptyWord(), contextWord.getEmptyWord());
			query.answerQuery(result);
		}else {

			Word prefix = contextWord.getWordFromString(prefixStr);
			Word suffix = null;
			if(!suffixStr.equals("")) {
				suffix = contextWord.getWordFromString(suffixStr);
			}else {
				suffix = contextWord.getEmptyWord();
			}
			query = new QuerySimple<>(prefix, suffix);
			query.answerQuery(result);
		}
		timer.stop();
		Statistics.timeEquivalenceQuery += timer.getTimeElapsed();
		++ Statistics.numEquivalenceQuery;
		Statistics.timeLastEquivalenceQuery = timer.getTimeElapsed();
		
		if(Options.verbose) System.out.println("counter example = " + query);
		return query;
	}

	@Override
	public Boolean answerMembershipQuery(Query<Boolean> query) {
		List<String> prefix = new ArrayList<>();
		List<String> suffix = new ArrayList<>();
        
		for(int i = 0; i < query.getPrefix().length(); i ++) {
			prefix.add(contextWord.letterToString(query.getPrefix().getLetter(i)));
		}
		for(int i = 0; i < query.getSuffix().length(); i ++) {
			suffix.add(contextWord.letterToString(query.getSuffix().getLetter(i)));
		}
		
        Timer timer = new Timer();
        timer.start();
        
		boolean result;
		
		if(suffix.isEmpty()) {
			result = false;
		}else {
			result = BuechiRunner.isAccepting(targetB, prefix, suffix);
		}
		
		timer.stop();
		Statistics.timeMembershipQuery += timer.getTimeElapsed();
		++ Statistics.numMembershipQuery; 
		return ! result; // reverse the result for Buechi automaton
	}
	
	private void redirectRabitOut() {
		
		try {
			PrintStream out = new PrintStream(new FileOutputStream("rabitlog.txt"));
			System.setOut(out);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	private long numInterAandB = 0;
	private long numInterAandNotA = 0;
	private long timeInterAandB = 0;
	private long timeAandNotA = 0;
	private long numInclusionNotAandB = 0;
	private long timeInclusionNotAandB = 0;
	
	public void print() {
		System.out.println("#A/\\B = " + numInterAandB);
		System.out.println("t#A/\\B = " + timeInterAandB + " ms");
		System.out.println("#A/\\!A = " + numInterAandNotA);
		System.out.println("t#A/\\!A = " + timeAandNotA + " ms");
		System.out.println("#!A<B = " + numInclusionNotAandB );
		System.out.println("#t!A<B = " + timeInclusionNotAandB + " ms");
	}

}
