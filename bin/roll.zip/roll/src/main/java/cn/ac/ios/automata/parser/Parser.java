package cn.ac.ios.automata.parser;

import java.io.OutputStream;

import automata.FiniteAutomaton;

public interface Parser {

	FiniteAutomaton parse();
	
	void print(FiniteAutomaton fa, OutputStream out);
	
	void close();
}