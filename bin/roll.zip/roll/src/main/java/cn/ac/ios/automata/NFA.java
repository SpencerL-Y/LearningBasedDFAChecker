package cn.ac.ios.automata;

import java.util.BitSet;
import java.util.HashMap;
import java.util.Map;

import cn.ac.ios.automata.words.Alphabet;
import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.graph.EdgeProperty;
import cn.ac.ios.graph.GraphSimple;
import cn.ac.ios.graph.Properties;
import cn.ac.ios.value.Type;
import cn.ac.ios.value.Value;
import cn.ac.ios.value.ValueManager;

public class NFA implements Automaton {
	
	private final ValueManager contextValue;
	private GraphSimple graph;
	private final WordManager contextWord;
	
	public NFA(WordManager contextWord) {
		assert contextWord != null;
		this.contextWord = contextWord;
		this.contextValue = contextWord.getContextValue();
		graph = new GraphSimple(contextValue);
		
		Type typeInteger = contextValue.newTypeInteger();
		graph.addSettableEdgeProperty(Properties.EXPRESSION, typeInteger);
	}

	@Override
	public AccType getAccType() {
		return AccType.NFA;
	}

	@Override
	public int getNumStates() {
		return graph.getNumNodes();
	}

	@Override
	public BitSet getInitialStates() {
		return graph.getInitialNodes();
	}

	@Override
	public BitSet getSuccessors(int state, int letter) {
		graph.queryNode(state);
		EdgeProperty edgeProp = graph.getEdgeProperty(Properties.EXPRESSION);
		BitSet successors = new BitSet(getNumStates());
		for(int succNr = 0; succNr < graph.getNumSuccessors(); succNr ++) {
			Value valueLetter = edgeProp.get(succNr);
			if(valueLetter.getInt() == letter) successors.set(graph.getSuccessorNode(succNr));
		}
		return successors;
	}
	
	@Override
	public boolean isAccepted(int state) {
		return acceptingStates.get(state);
	}

	private int currentState = -1 ;
	private Map<Integer, Integer> transMap = new HashMap<>();
	
	@Override
	public void addNewState(int number) {
		currentState = number;
		graph.queryNode(currentState);
		transMap.clear();
	}

	@Override
	public void addTransition(int letter, int to) {	
		transMap.put(letter, to);
	}

	@Override
	public void addTransition(int letter, BitSet tos) {
		addTransition(letter, tos.nextSetBit(0));
	}

	@Override
	public void addNewStateEnd() {	
		graph.prepareNode(transMap.size());
		int succNr = 0;
		Type typeInteger = contextValue.newTypeInteger();
		Value valueInteger = typeInteger.newValue();
		EdgeProperty edgeProp = graph.getEdgeProperty(Properties.EXPRESSION);
		for(Map.Entry<Integer, Integer> entry : transMap.entrySet()) {
			graph.setSuccessorNode(succNr, entry.getValue());
			valueInteger.set(entry.getKey());
			edgeProp.set(valueInteger, succNr);
			++ succNr;
		}
	}
	
	private final BitSet acceptingStates = new BitSet();
	
	@Override
	public void setAccepting() {
		acceptingStates.set(currentState);		
	}
	
	public String toString() {
		return AutomataExporterDOT.toString(this);
	}

	@Override
	public Alphabet getAlphabet() {
		return contextWord.getAlphabet();
	}

	@Override
	public void setInitial() {
		BitSet inits = graph.getInitialNodes();
		inits.set(currentState);
	}

	@Override
	public BitSet getAcceptingStates() {
		return (BitSet) acceptingStates.clone();
	}


}
