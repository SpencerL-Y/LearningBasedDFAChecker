/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.learner.fdfa.tree;

import cn.ac.ios.table.HashableValue;
import cn.ac.ios.util.Pair;

/** only used for syntactic tree */
class HashableValuePair implements HashableValue {
	
	private enum Right {
		A, 
		B,
		C;
		
		public String toString() {
			if(this == A) {
				return "A";
			}else if(this == B) {
				return "B";
			}else {
				return "C";
			}
		}
	}
	
	private int valueInt;       // corresponding state in leading automaton
	private Right valueRight;   // right value defined in the paper 
	private boolean left;       // m1 == m2
	private boolean right;      // c1 == c2
	
	public HashableValuePair(int valueInt, boolean left, boolean right) {
		this.valueInt  = valueInt;
		this.left = left;
		this.right = right;
		// q1 != q2, return false
		// q1 = q2 ==> c1 == c2
		// m1 != m2 && (c1 || c2) implies two branch are different
		if(left && right) {
			this.valueRight = Right.A;
		}else if(left && !right) {
			this.valueRight = Right.B;
		}else {
			this.valueRight = Right.C;
		}
	}


	@Override
	public boolean valueEqual(HashableValue rvalue) {
		assert rvalue instanceof HashableValuePair;
		HashableValuePair other = (HashableValuePair)rvalue;
		if(valueInt != other.getInt()) return false;   // different branch
		if(valueRight != other.valueRight) return false;     
		return true;  // same branch
	}

	@SuppressWarnings("unchecked")
	@Override
	public Pair<Boolean, Boolean> get() {
		return new Pair<>(left, right);
	}
	
	public boolean equals(Object obj) {
		if(obj instanceof HashableValuePair) {
			HashableValuePair pair = (HashableValuePair)obj;
			return valueEqual(pair);
		}
		return false;
	}
	
	public String toString() {
		return "(" +  valueInt 
				+ ", " + valueRight
				+ ")";
	}
	
	@Override
	public int hashCode() {
		int value = valueInt * 2 + valueRight.hashCode();
		return value;
	}

	@Override
	public boolean isPair() {
		return true;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Boolean getLeft() {
		return left;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Boolean getRight() {
		return right;
	}

	@Override
	public boolean isAccepting() {
		return valueRight == Right.A;
	}
	
	public int getInt() {
		return valueInt;
	}

}
