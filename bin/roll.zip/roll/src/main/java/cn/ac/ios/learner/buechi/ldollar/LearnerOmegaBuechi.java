/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.learner.buechi.ldollar;

import java.util.BitSet;
import java.util.HashMap;
import java.util.LinkedList;

import cn.ac.ios.automata.Acceptor;
import cn.ac.ios.automata.Automaton;
import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.automata.words.Word;
import cn.ac.ios.learner.Learner;
import cn.ac.ios.learner.LearnerType;
import cn.ac.ios.learner.dfa.table.LearnerDFATable;
import cn.ac.ios.learner.dfa.tree.LearnerDFATree;
import cn.ac.ios.options.Options;
import cn.ac.ios.query.MembershipOracle;
import cn.ac.ios.query.Query;
import cn.ac.ios.query.QuerySimple;
import cn.ac.ios.util.DollarAutomatonBuilder;
import cn.ac.ios.util.UtilAutomaton;
import dk.brics.automaton.BasicOperations;
import dk.brics.automaton.State;
import dk.brics.automaton.Transition;

public class LearnerOmegaBuechi implements Learner<Acceptor, Boolean> {

	protected final MembershipOracle<Boolean> membershipOracle;
	protected final WordManager contextWord;
	protected Learner<Automaton, Boolean> learner;
	protected boolean checkInclusion;

	public LearnerOmegaBuechi(WordManager contextWord, MembershipOracle<Boolean> membershipOracle, boolean tree) {
		assert contextWord != null && membershipOracle != null;
		this.contextWord = contextWord;
		this.membershipOracle = membershipOracle;
		if (tree) {
			this.learner = new LearnerDFATree(contextWord, new LDollarMembershipOracle());
		} else {
			this.learner = new LearnerDFATable(contextWord, new LDollarMembershipOracle());
		}
	}

	@Override
	public void startLearning() {
		learner.startLearning();
		constructHypothesis();
	}

	@Override
	public LearnerType getLearnerType() {
		return LearnerType.BUECHI;
	}

	@Override
	public Automaton getHypothesis() {
		return learner.getHypothesis();
	}

	private void constructHypothesis() {
		boolean flag = false;
		Automaton aut = null;
		while (!flag) {
			if(Options.verbose) System.out.println(learner.toString());
			aut = learner.getHypothesis();
			dk.brics.automaton.Automaton dkAut = UtilAutomaton.convertToDkAutomaton(aut);
			flag = checkInclusionAndRefine(dkAut);
		}
		buechi = startConvert(aut);
		buechi.restoreInvariant();
	}

	private dk.brics.automaton.Automaton buechi = null;

	public dk.brics.automaton.Automaton getBuechi() {
		return buechi;
	}

	@Override
	public void refineHypothesis(Query<Boolean> query) {
		// TODO Auto-generated method stub
		Word prefix = query.getPrefix();
		Word suffix = query.getSuffix();
		dk.brics.automaton.Automaton result = DollarAutomatonBuilder.buildDollarAutomaton(prefix, suffix);
		// System.out.println(result.toString());
		String counterexample = null;

		dk.brics.automaton.Automaton dkAut = UtilAutomaton.convertToDkAutomaton(learner.getHypothesis());
		//System.out.println(dkAut.toString());
		boolean answer = membershipOracle.answerMembershipQuery(query);
		if (answer) {
			counterexample = result.minus(dkAut).getShortestExample(true);
		} else {
			counterexample = dkAut.intersection(result).getShortestExample(true);
		}
		if(Options.verbose) System.out.println("counterexample: " + counterexample);
		Word word = contextWord.getWordFromString(counterexample);
		learner.refineHypothesis(getQueryResult(word, answer));
		constructHypothesis();
	}

	// Checks whether LDollar is contained in A*$A+. If not, refines current
	// hypothesis.
	// Assumes the first letter of the alphabet is $('\u0024').
	public boolean checkInclusionAndRefine(dk.brics.automaton.Automaton dkAut) {
		dk.brics.automaton.Automaton a = new dk.brics.automaton.Automaton();
		State s1 = new State();
		State s2 = new State();
		State s3 = new State();
		a.setInitialState(s1);
		s1.addTransition(new Transition(Character.MIN_VALUE, '\u0023', s1));
		s1.addTransition(new Transition('\u0024', s2));
		s1.addTransition(new Transition('\u0025', Character.MAX_VALUE, s1));
		s2.addTransition(new Transition(Character.MIN_VALUE, '\u0023', s3));
		s2.addTransition(new Transition('\u0025', Character.MAX_VALUE, s3));
		s3.addTransition(new Transition(Character.MIN_VALUE, '\u0023', s3));
		s3.addTransition(new Transition('\u0025', Character.MAX_VALUE, s3));
		s3.setAccept(true);
		a.setDeterministic(true);
		a.restoreInvariant();
		dkAut.restoreInvariant();
		boolean answer = dkAut.subsetOf(a) || dkAut.isEmpty();
		if (!answer) {
			String counterExample = dkAut.minus(a).getShortestExample(true);
			Word word = contextWord.getWordFromString(counterExample);
			learner.refineHypothesis(getQueryResult(word, false));
		}
		return answer;
	}

	private Query<Boolean> getQueryResult(Word word, boolean answer) {
		Query<Boolean> query = new QuerySimple<>(word);
		query.answerQuery(answer);
		return query;
	}
	
	/** NOTE that dkAut.isEmpty means that dkAut accepts empty string*/

	// Constructs the Buechi automaton
	public dk.brics.automaton.Automaton startConvert(Automaton aut) {
		dk.brics.automaton.Automaton dkAut = UtilAutomaton.convertToDkAutomaton(aut);
		//if(Options.verbose) System.out.println(aut.toString());
		if(Options.verbose) System.out.println("L$ DFA:\n" + dkAut.toDot());
		if (dkAut.isEmpty())
			return new dk.brics.automaton.Automaton();

		LinkedList<Integer> worklist = new LinkedList<Integer>();
		HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();
		// Records all '$' transitions.
		for (int stateNr = 0; stateNr < aut.getNumStates(); stateNr++) {
			int letter = 0;
			BitSet succs = aut.getSuccessors(stateNr, letter);
			int succ = succs.nextSetBit(0);
			if (succ == -1)
				continue;
			map.put(stateNr, succ);
			worklist.add(stateNr);
		}

		BitSet accepted = aut.getAcceptingStates();
		dk.brics.automaton.Automaton result = new dk.brics.automaton.Automaton();

		while (!worklist.isEmpty()) {
			int q = worklist.poll();
			// An automaton with original initial state and State q as final
			// state.
			dk.brics.automaton.Automaton Mq = UtilAutomaton.convertToDkAutomaton(aut,
					aut.getInitialStates().nextSetBit(0), q);
			Mq.minimize();
			// System.out.println("Mq:" + Mq.toDot());
			// An automaton with State q as both initial and final state.
			dk.brics.automaton.Automaton N1 = UtilAutomaton.convertToDkAutomaton(aut, q, q);
			// System.out.println("N1:" + N1.toDot());
			for (int fin = accepted.nextSetBit(0); fin >= 0; fin = accepted.nextSetBit(fin + 1)) {
				// An automaton with State q`$ as initial state and fin as final
				// state.
				dk.brics.automaton.Automaton N2 = UtilAutomaton.convertToDkAutomaton(aut, map.get(q), fin);
				// System.out.println("N2:" + N2.toDot());
				// An automaton with State fin as initial state and final state.
				dk.brics.automaton.Automaton N3 = UtilAutomaton.convertToDkAutomaton(aut, fin, fin);
				// System.out.println("N3:" + N3.toDot());
				dk.brics.automaton.Automaton Nqqf = BasicOperations.intersection(N2, N3);
				// System.out.println("N2.N3:" + Nqqf.toDot());
				Nqqf = BasicOperations.intersection(N1, Nqqf);
				Nqqf.minimize();
				// Convert Nq,qf to the automaton that accepts the language of
				// Nq,qf^\omega.
				if (!Nqqf.isEmpty())
					Nqqf = UtilAutomaton.addEpsilon(Nqqf);
				// System.out.println("Nqqf:" + Nqqf.toDot());
				result = BasicOperations.union(result, BasicOperations.concatenate(Mq, Nqqf));
				// System.out.println("result:" + result.toDot());
			}
		}
		return result;
	}

	private class LDollarMembershipOracle implements MembershipOracle<Boolean> {
		@Override
		public Boolean answerMembershipQuery(Query<Boolean> query) {
			// Checks if the word is in A*$A+ form.
			Word queriedWord = query.getQueriedWord();
			if (queriedWord.getLastLetter() == 0) {
				query.answerQuery(false);
				return false;
			}
			// Counts the number of $.
			int counter = 0;
			// Records u,v of Word u$v.
			Word prefix = null, suffix = null;
			for (int letterNr = 0; letterNr < queriedWord.length(); letterNr++) {
				if (queriedWord.getLetter(letterNr) == 0) {
					counter++;
					prefix = queriedWord.getPrefix(letterNr);
					suffix = queriedWord.getSuffix(letterNr + 1);
				}
				if (counter > 1) {
					query.answerQuery(false);
					return false;
				}
			}
			if (counter == 0) {
				query.answerQuery(false);
				return false;
			}

			// new QuerySimple
			boolean answer = membershipOracle.answerMembershipQuery(new QuerySimple<>(prefix, suffix));
			query.answerQuery(answer);
			return answer;
		}
	}

	public String toString() {
		return "\n" + learner.toString();
	}
	
	public Learner<Automaton, Boolean> getLDollarLearner() {
		return learner;
	}
}
