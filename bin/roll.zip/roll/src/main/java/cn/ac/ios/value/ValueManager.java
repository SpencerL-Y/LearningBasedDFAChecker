/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.value;

public final class ValueManager {
	
	private Type typeBoolean;
	private Type typeInteger;
	private Type typeDouble;
	
	private Type typeLetter;
	
	public ValueManager() {
		this.typeBoolean = new TypeBoolean(this);
		this.typeInteger = new TypeInteger(this);
		this.typeDouble = new TypeDouble(this);
	}
	
	public Type newTypeBoolean() {
		return typeBoolean;
	}
	
	public Type newTypeInteger() {
		return typeInteger;
	}
	
	public Type newTypeDouble() {
		return typeDouble;
	}
	
	public Type newTypeLetter(Class<?> clazz) {
		typeLetter = new TypeObject(this, null, clazz);
		return typeLetter;
	}
	
	public Type newTypeLetterInteger() {
		typeLetter = typeInteger;
		return typeLetter;
	}
	
	public Type newTypeObject(Class<?> clazz) {
		return new TypeObject(this, null, clazz);
	}
	
	public Type newTypeObject(Class<?> clazz, Object obj) {
		assert obj != null;
		Type typeObject = new TypeObject(this, null, clazz);
		Value value = typeObject.newValue();
		value.set(obj);
		typeObject.setKnownValue(value);
		return typeObject;
	}
	
	public Value getFalse() {
		return typeBoolean.getFalse();
	}
	
	public Value getTrue() {
		return typeBoolean.getTrue();
	}
	
	public Type getTypeLetter() {
		return typeLetter;
	}

}
