/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.learner.fdfa.table;

import java.util.List;

import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.automata.words.Word;

import cn.ac.ios.learner.table.ObservationRowDFA;
import cn.ac.ios.learner.table.ObservationTableDFA;
import cn.ac.ios.query.MembershipOracle;
import cn.ac.ios.table.ExprValue;
import cn.ac.ios.table.HashableValue;
import cn.ac.ios.table.ObservationRow;

public class LearnerProgressTableSyntactic extends LearnerProgressTable {

	public LearnerProgressTableSyntactic(WordManager contextWord
			, MembershipOracle<Boolean> membershipOracle
			, Word label) {
		super(contextWord, membershipOracle, label);
	}

	@Override
	protected ObservationTableDFA getTableInstance(WordManager contextWord) {
		return new ObservationTableDFASyntactic(contextWord);
	}
	
	private class ObservationTableDFASyntactic extends  ObservationTableDFA {

		protected ObservationTableDFASyntactic(WordManager contextWord) {
			super(contextWord);
		}

		@Override
		public ObservationRowDFA getRowInstance(Word word) {
			return new ObservationRowSyntactic(word);
		}
	}
	
	private class ObservationRowSyntactic extends ObservationRowDFA {

		private int state ;
		
		protected ObservationRowSyntactic(Word word) {
			super(word);
		}

		@Override
		public void setLeadingState(int state) {
			this.state = state;
		}
		
		// 1. M(x1) != M(x2) return false, otherwise
		// 2. test (m1 != m2) & (c1 | c2) = true then return false
		@Override
		public boolean valuesEqual(ObservationRow other) {
			assert other instanceof ObservationRowSyntactic;
			ObservationRowSyntactic rowOther = (ObservationRowSyntactic)other;
			if(state != rowOther.state) return false;
			List<HashableValue> thisValues = getValues();
			List<HashableValue> otherValues = other.getValues();
			assert thisValues.size() == otherValues.size();
			for(int valNr = 0; valNr < thisValues.size(); valNr ++) {
				boolean m1 = thisValues.get(valNr).getLeft()
				      , m2 = otherValues.get(valNr).getLeft();
				boolean c1 = thisValues.get(valNr).getRight()
					  , c2 = otherValues.get(valNr).getRight();
				if((m1 != m2) && (c1 || c2)) {
					return false;
				}
			}
			return true;
		}
	}
	
	protected void prepareRowDFA(ObservationRowDFA row) {
		Word label = row.getWord();
		row.setLeadingState(learnerLeading.computeReachState(state, label));
	}
	
	// for counter example analysis
	protected class CeAnalyzerTableSyntactic extends CeAnalyzer {

		public CeAnalyzerTableSyntactic(ExprValue exprValue) {
			super(exprValue);
		}

		@Override
		public void analyze() {
			Word wordCE = exprValue.get();
			// initially uv ~ u since input is normalized factorization
			HashableValue resultPrev = getHashableValueBoolean(isCEAccepting, true);
			// pairs (m1, c1) and (m2, c2), 1. c1 != c2 or (m1 != m2)
			// c1 != c2 means that M(x1) != M(x2) since M(ux1asuffix) = M(u) but M(ux2suffix) != M(u)
			// m1 != m2 means that c1 = c2 = true but m1 != m2 so x1 and x2 are distinguished
			int stateCurr, statePrev = getInitState();
			for(int letterNr = 0; letterNr < wordCE.length(); letterNr ++) {
				stateCurr = computeNextState(statePrev, wordCE.getLetter(letterNr));
				Word period = getStateLabel(stateCurr);
				period = period.concat(wordCE.getSuffix(letterNr + 1));
				HashableValue resultCurr = processMembershipQuery(period);
				if(! resultPrev.valueEqual(resultCurr)) {
					column = getExprValueWord(wordCE.getSuffix(letterNr + 1));
					break;
				}
				statePrev = stateCurr;
				//resultPrev = resultCurr; // no need actually
			}			
		}
		
	}

	@Override
	protected CeAnalyzer getCeAnalyzerInstance(ExprValue exprValue) {
		return new CeAnalyzerTableSyntactic(exprValue);
	}

}
