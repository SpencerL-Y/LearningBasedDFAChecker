package cn.ac.ios.bdd.algorithm;

import java.util.ArrayDeque;
import java.util.Deque;

import cn.ac.ios.bdd.BDDManager;
import cn.ac.ios.bdd.graph.BuechiBDD;
import net.sf.javabdd.BDD;

/** 
 *   Krishnendu Chatterjee, Monika Henzinger and Manas Joglekar, Nisarg Shah
 "Symbolic Algorithms for Qualitative Analysis of Markov Decision Processes with
   B\"{u}chi Objectives"
 * */
//TODO
public class SCCDD {
	
	class Spine { /* (U, s)-> spine set */
	    BDD u;
	    BDD s;
	    
	    Spine(BDD u, BDD s) {
	    	this.u = u;
	    	this.s = s;
	    }
	    
	    boolean isUEmpty() {
	    	return u.isZero();
	    }
	    
	    void close() {
	    	u.free();
	    	s.free();
	    }
	}

	class SkelResult {
	    BDD fwSet;
	    BDD newSet;
	    BDD newNode;
	    BDD P;
	    
	    SkelResult(BDD fwd, BDD newSet, BDD newNode, BDD P) {
	    	this.fwSet = fwd;
	    	this.newSet = newSet;
	    	this.newNode = newNode;
	    	this.P = P;
	    }
	    
	    void close() {
	    	fwSet.free();
	    	newSet.free();
	    	newNode.free();
	    	P.free();
	    }
	}

	enum Position {
	    FIRST, /* first scc find call */
	    SECOND /* second scc find call */
	}

	class StackEntry {
	    Position position;
	    BDD nodes;
	    BDD edges;
	    Spine spine;
	    SkelResult skelResult;
	    BDD scc;
	    
	    StackEntry(Position position, BDD nodes, BDD edges, Spine spine
	    		, SkelResult skelResult, BDD scc) {
	    	this.position = position;
	    	this.nodes = nodes;
	    	this.edges = edges;
	    	this.spine = spine;
	    	this.scc = scc;
	    	
	    }
	    
	    void close() {
	    	if(spine != null) {
	    		spine.close();
	    	}
	    	
	    	if(skelResult != null) {
	    		skelResult.close();
	    	}
	    	
	    	if(nodes != null) {
	    		nodes.free();
	    	}
	    	if(edges != null) {
	    		edges.free();
	    	}
	    	if(scc != null) {
	    		scc.free();
	    	}
	    }
	} 
	
	private BDDManager bdd;
	
	private final BDD presAndActions;
	private final BDD nextAndActions;
	private final BDD transitions;
    private final BDD nodes;
    private final BDD transitionsNoActions;
    private final BDD actionCube;
    private final Deque<StackEntry> stack = new ArrayDeque<>();
	
	public SCCDD(BuechiBDD buechi) {
		assert buechi != null;
		this.bdd = buechi.getBDDManager();
		this.nodes = buechi.getStateSpace();
		this.actionCube = buechi.getActionCube();
		this.presAndActions = buechi.getPreCube().and(buechi.getActionCube());
		this.nextAndActions = buechi.getNextCube().and(buechi.getActionCube());
		this.transitions = buechi.getTransition();
		this.transitionsNoActions = buechi.getTransition().exist(buechi.getActionCube());
		
		start(nodes);
	}

	private void start(BDD nodes) {

		BDD edges = null;
		BDD zero = bdd.getZero();
		Spine spine = new Spine(zero, zero);
        while (!stack.isEmpty()) {
            stack.pop().close();
        }
        
		stack.push(new StackEntry(Position.FIRST, nodes, edges, spine, null, null));
        edges.free();
        spine.close();
	}
	

	

}
