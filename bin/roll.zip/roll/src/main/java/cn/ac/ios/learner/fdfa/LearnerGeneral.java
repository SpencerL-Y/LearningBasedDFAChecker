/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.learner.fdfa;

import cn.ac.ios.automata.Automaton;
import cn.ac.ios.automata.words.Word;
import cn.ac.ios.learner.Learner;
import cn.ac.ios.table.ExprValue;
import cn.ac.ios.table.ExprValueWord;
import cn.ac.ios.table.ExprValueWordPair;
import cn.ac.ios.table.HashableValue;
import cn.ac.ios.table.HashableValueBoolean;
import cn.ac.ios.table.HashableValueBooleanPair;

public interface LearnerGeneral extends Learner<Automaton, Boolean> {
	
	default HashableValue getHashableValueBoolean(boolean value) {
		return new HashableValueBoolean(value);
	}
	
	default ExprValue getExprValueWord(Word word) {
		return new ExprValueWord(word);
	}
	
	default ExprValue getExprValueWord(Word left, Word right) {
		return new ExprValueWordPair(left, right);
	}
	
	default HashableValue getHashableValueBoolean(boolean valueLeft, boolean valueRight) {
		return new HashableValueBooleanPair(valueLeft, valueRight);
	}
	
	// only for DFA
	default int computeNextState(int state, int letter) {
		return getHypothesis().getSuccessors(state, letter).nextSetBit(0);
	}
	
	default int computeReachState(Word word) {
		return computeReachState(getInitState(), word);
	}
	
	default int computeReachState(int source, Word word) {
		int state = source;
		for(int letterNr = 0; letterNr < word.length(); letterNr ++) {
			state = computeNextState(state, word.getLetter(letterNr));
		}
		return state;
	}
	
	default int getInitState() {
		return getHypothesis().getInitialStates().nextSetBit(0);
	}
	
	Word getStateLabel(int state);
	
	default Word getStateLabel(Word word) {
		int target = computeReachState(getHypothesis().getInitialStates().nextSetBit(0), word);
		return getStateLabel(target);
	}

}
