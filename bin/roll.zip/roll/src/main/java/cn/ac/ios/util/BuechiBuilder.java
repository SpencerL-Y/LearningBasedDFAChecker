/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.util;

import java.util.ArrayList;
import java.util.BitSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import automata.FiniteAutomaton;
import cn.ac.ios.automata.Automaton;
import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.automata.words.Word;
import cn.ac.ios.learner.fdfa.LearnerFDFA;
import cn.ac.ios.options.Options;
import cn.ac.ios.oracle.Minimizer;
import cn.ac.ios.query.MembershipOracle;
import cn.ac.ios.query.Query;
import cn.ac.ios.query.QuerySimple;
import dk.brics.automaton.State;
import dk.brics.automaton.Transition;
import gnu.trove.map.TIntObjectMap;
import gnu.trove.map.hash.TIntObjectHashMap;

public class BuechiBuilder {

	public static FiniteAutomaton build(LearnerFDFA learnerFDFA, boolean isLower) {
		// transform it to Rabit form
		return UtilAutomaton.convertToRabitAutomaton(buildNFA(learnerFDFA, true, isLower));
	}

	public static dk.brics.automaton.Automaton buildNFA(LearnerFDFA learnerFDFA, boolean epsilon, boolean isLower) {
		if (Options.verbose) {
			Options.log.verbose(learnerFDFA.getHypothesis().toString());
		}

		// L means Leading and P means Progress
		Automaton autL = learnerFDFA.getLeadingAutomaton();
		TIntObjectMap<State> map = new TIntObjectHashMap<>();
		dk.brics.automaton.Automaton dkAutL = UtilAutomaton.convertToDkAutomaton(map, autL);
		for (int stateNr = 0; stateNr < autL.getNumStates(); stateNr++) {
			Automaton autP = learnerFDFA.getProgressAutomaton(stateNr);
			BitSet accStates = autP.getAcceptingStates();
			List<dk.brics.automaton.Automaton> accAuts = new ArrayList<>();
			int stateInitP = autP.getInitialStates().nextSetBit(0);
			for (int accNr = accStates.nextSetBit(0); accNr >= 0; accNr = accStates.nextSetBit(accNr + 1)) {
				dk.brics.automaton.Automaton dkAutP = UtilAutomaton.convertToDkAutomaton(autP, stateInitP, accNr);
				if(Options.simulationNFA) {
					dkAutP = Minimizer.mimimizeNFA(dkAutP);
				}else {
					dkAutP.minimize();
				}
				dk.brics.automaton.Automaton dkAutLOther = UtilAutomaton.convertToDkAutomaton(autL, stateNr, stateNr);
				if(Options.simulationNFA) {
					dkAutLOther = Minimizer.mimimizeNFA(dkAutLOther);
				}else {
					dkAutLOther.minimize();
				}
				
				dk.brics.automaton.Automaton product = dkAutP.intersection(dkAutLOther);
				if(Options.simulationNFA) {
					product = Minimizer.mimimizeNFA(product);
				}else {
					product.minimize();
				}
				
				if (isLower) {
					dk.brics.automaton.Automaton dkAutNq = UtilAutomaton.convertToDkAutomaton(autP, accNr, accNr);
					if(Options.simulationNFA) {
						dkAutNq = Minimizer.mimimizeNFA(dkAutNq);
					}else {
						dkAutNq.minimize();
					}

					product = product.intersection(dkAutNq);
					if(Options.simulationNFA) {
						product = Minimizer.mimimizeNFA(product);
					}else {
						product.minimize();
					}
				}

				if (! product.getAcceptStates().isEmpty()) {
					assert product.getAcceptStates().size() == 1;
					if(product.getAcceptStates().size() > 1) {
						System.err.println("More than one accepting state...");
						System.exit(-1);
					}
					product = UtilAutomaton.addEpsilon(product);
					accAuts.add(product);
				}
			}

			State u = map.get(stateNr); // make epsilon or Dollar transitions

			if (epsilon) {
				for (dk.brics.automaton.Automaton dkAut : accAuts) {
					State init = dkAut.getInitialState();
					for (Transition t : init.getTransitions())
						u.addTransition(new Transition(t.getMin(), t.getMax(), t.getDest()));
				}
			} else {
				for (dk.brics.automaton.Automaton p : accAuts) {
					u.addTransition(new Transition(WordManager.getStringDollar().charAt(0), p.getInitialState()));
				}
			}
		}
		 
		return dkAutL;
	}
	
	public static FiniteAutomaton buildUniversalNFA(LearnerFDFA learnerFDFA, boolean isLower) {
		if (Options.verbose)
			learnerFDFA.getHypothesis();
		// L means Leading and P means Progress
		Automaton autL = learnerFDFA.getLeadingAutomaton();
		TIntObjectMap<State> map = new TIntObjectHashMap<>();
		dk.brics.automaton.Automaton dkAutL = UtilAutomaton.convertToDkAutomaton(map, autL);
		for (int stateNr = 0; stateNr < autL.getNumStates(); stateNr++) {
			Automaton autP = learnerFDFA.getProgressAutomaton(stateNr);
			BitSet accStates = (BitSet)autP.getAcceptingStates().clone();

			List<dk.brics.automaton.Automaton> accAuts = new ArrayList<>();
			int stateInitP = autP.getInitialStates().nextSetBit(0);
			for (int accNr = accStates.nextSetBit(0); accNr >= 0; accNr = accStates.nextSetBit(accNr + 1)) {
				dk.brics.automaton.Automaton dkAutP = UtilAutomaton.convertToDkAutomaton(autP, stateInitP, accNr);
				if(Options.simulationNFA) {
					dkAutP = Minimizer.mimimizeNFA(dkAutP);
				}else {
					dkAutP.minimize();
				}
				dk.brics.automaton.Automaton dkAutLOther = UtilAutomaton.convertToDkAutomaton(autL, stateNr, stateNr);
				if(Options.simulationNFA) {
					dkAutLOther = Minimizer.mimimizeNFA(dkAutLOther);
				}else {
					dkAutLOther.minimize();
				}
				
				dk.brics.automaton.Automaton product = dkAutP.intersection(dkAutLOther);
				if(Options.simulationNFA) {
					product = Minimizer.mimimizeNFA(product);
				}else {
					product.minimize();
				}
				
				if (isLower) {
					dk.brics.automaton.Automaton dkAutNq = UtilAutomaton.convertToDkAutomaton(autP, accNr, accNr);
					if(Options.simulationNFA) {
						dkAutNq = Minimizer.mimimizeNFA(dkAutNq);
					}else {
						dkAutNq.minimize();
					}

					product = product.intersection(dkAutNq);
					if(Options.simulationNFA) {
						product = Minimizer.mimimizeNFA(product);
					}else {
						product.minimize();
					}
				}

				if (! product.getAcceptStates().isEmpty()) {
					assert product.getAcceptStates().size() == 1;
					if(product.getAcceptStates().size() > 1) {
						System.err.println("More than one accepting state...");
						System.exit(-1);
					}
					product = UtilAutomaton.addEpsilon(product);
					accAuts.add(product);
				}
			}
			
			// reverse DFA 
			accStates.flip(0, autP.getNumStates());

			for (int accNr = accStates.nextSetBit(0); accNr >= 0; accNr = accStates.nextSetBit(accNr + 1)) {
				dk.brics.automaton.Automaton dkAutP = UtilAutomaton.convertToDkAutomaton(autP, stateInitP, accNr);
				if(Options.simulationNFA) {
					dkAutP = Minimizer.mimimizeNFA(dkAutP);
				}else {
					dkAutP.minimize();
				}
				dk.brics.automaton.Automaton dkAutLOther = UtilAutomaton.convertToDkAutomaton(autL, stateNr, stateNr);
				if(Options.simulationNFA) {
					dkAutLOther = Minimizer.mimimizeNFA(dkAutLOther);
				}else {
					dkAutLOther.minimize();
				}
				
				dk.brics.automaton.Automaton product = dkAutP.intersection(dkAutLOther);
				if(Options.simulationNFA) {
					product = Minimizer.mimimizeNFA(product);
				}else {
					product.minimize();
				}
				
				if (isLower) {
					dk.brics.automaton.Automaton dkAutNq = UtilAutomaton.convertToDkAutomaton(autP, accNr, accNr);
					if(Options.simulationNFA) {
						dkAutNq = Minimizer.mimimizeNFA(dkAutNq);
					}else {
						dkAutNq.minimize();
					}

					product = product.intersection(dkAutNq);
					if(Options.simulationNFA) {
						product = Minimizer.mimimizeNFA(product);
					}else {
						product.minimize();
					}
				}

				if (! product.getAcceptStates().isEmpty()) {
					assert product.getAcceptStates().size() == 1;
					if(product.getAcceptStates().size() > 1) {
						System.err.println("More than one accepting state...");
						System.exit(-1);
					}
					product = UtilAutomaton.addEpsilon(product);
					accAuts.add(product);
				}
			}


			State u = map.get(stateNr); // make epsilon or Dollar transitions

			for (dk.brics.automaton.Automaton dkAut : accAuts) {
				State init = dkAut.getInitialState();
				for (Transition t : init.getTransitions())
					u.addTransition(new Transition(t.getMin(), t.getMax(), t.getDest()));
			}
			
		}
		System.out.println("universal buechi: +\n" + dkAutL.toDot());
		return UtilAutomaton.convertToRabitAutomaton(dkAutL);
	}
	
	public static FiniteAutomaton buildNegNFA(LearnerFDFA learnerFDFA) {
		return UtilAutomaton.convertToRabitAutomaton(buildNegNFA(learnerFDFA, true, true));
	}
	public static dk.brics.automaton.Automaton buildNegNFA(LearnerFDFA learnerFDFA, boolean epsilon, boolean isLower) {
		if (Options.verbose)
			learnerFDFA.getHypothesis();
		// L means Leading and P means Progress
		Automaton autL = learnerFDFA.getLeadingAutomaton();
		TIntObjectMap<State> map = new TIntObjectHashMap<>();
		dk.brics.automaton.Automaton dkAutL = UtilAutomaton.convertToDkAutomaton(map, autL);
		for (int stateNr = 0; stateNr < autL.getNumStates(); stateNr++) {
			Automaton autP = learnerFDFA.getProgressAutomaton(stateNr);
			BitSet accStates = (BitSet)autP.getAcceptingStates().clone();
			// reverse all the states here
			accStates.flip(0, autP.getNumStates());
			List<dk.brics.automaton.Automaton> accAuts = new ArrayList<>();
			int stateInitP = autP.getInitialStates().nextSetBit(0);
			for (int accNr = accStates.nextSetBit(0); accNr >= 0; accNr = accStates.nextSetBit(accNr + 1)) {
				dk.brics.automaton.Automaton dkAutP = UtilAutomaton.convertToDkAutomaton(autP, stateInitP, accNr);
				if(Options.simulationNFA) {
					dkAutP = Minimizer.mimimizeNFA(dkAutP);
				}else {
					dkAutP.minimize();
				}
				dk.brics.automaton.Automaton dkAutLOther = UtilAutomaton.convertToDkAutomaton(autL, stateNr, stateNr);
				if(Options.simulationNFA) {
					dkAutLOther = Minimizer.mimimizeNFA(dkAutLOther);
				}else {
					dkAutLOther.minimize();
				}
				
				dk.brics.automaton.Automaton product = dkAutP.intersection(dkAutLOther);
				if(Options.simulationNFA) {
					product = Minimizer.mimimizeNFA(product);
				}else {
					product.minimize();
				}
				
				if (isLower) {
					dk.brics.automaton.Automaton dkAutNq = UtilAutomaton.convertToDkAutomaton(autP, accNr, accNr);
					if(Options.simulationNFA) {
						dkAutNq = Minimizer.mimimizeNFA(dkAutNq);
					}else {
						dkAutNq.minimize();
					}

					product = product.intersection(dkAutNq);
					if(Options.simulationNFA) {
						product = Minimizer.mimimizeNFA(product);
					}else {
						product.minimize();
					}
				}

				if (! product.getAcceptStates().isEmpty()) {
					assert product.getAcceptStates().size() == 1;
					if(product.getAcceptStates().size() > 1) {
						System.err.println("More than one accepting state...");
						System.exit(-1);
					}
					product = UtilAutomaton.addEpsilon(product);
					accAuts.add(product);
				}
			}

			State u = map.get(stateNr); // make epsilon or Dollar transitions

			if (epsilon) {
				for (dk.brics.automaton.Automaton dkAut : accAuts) {
					State init = dkAut.getInitialState();
					for (Transition t : init.getTransitions())
						u.addTransition(new Transition(t.getMin(), t.getMax(), t.getDest()));
				}
			} else {
				for (dk.brics.automaton.Automaton p : accAuts) {
					u.addTransition(new Transition(WordManager.getStringDollar().charAt(0), p.getInitialState()));
				}
			}
		}
		return dkAutL;
	}

	// we use lower method to construct LDBA
	public static FiniteAutomaton buildLDBA(LearnerFDFA learnerFDFA) {
		// L means Leading and P means Progress
		Automaton autL = learnerFDFA.getLeadingAutomaton();
		TIntObjectMap<State> map = new TIntObjectHashMap<>();
		dk.brics.automaton.Automaton dkAutL = UtilAutomaton.convertToDkAutomaton(map, autL);
		for (int stateNr = 0; stateNr < autL.getNumStates(); stateNr++) {
			Automaton autP = learnerFDFA.getProgressAutomaton(stateNr);
			BitSet accStates = autP.getAcceptingStates();
			List<dk.brics.automaton.Automaton> accAuts = new ArrayList<>();
			int stateInitP = autP.getInitialStates().nextSetBit(0);
			for (int accNr = accStates.nextSetBit(0); accNr >= 0; accNr = accStates.nextSetBit(accNr + 1)) {
				// Aq,qf
				dk.brics.automaton.Automaton dkAutP = UtilAutomaton.convertToDkAutomaton(autP, stateInitP, accNr);
				dkAutP.minimize();
				// Mq
				dk.brics.automaton.Automaton dkAutLOther = UtilAutomaton.convertToDkAutomaton(autL, stateNr, stateNr);
				dkAutLOther.minimize();
				dk.brics.automaton.Automaton product = dkAutP.intersection(dkAutLOther);
				product.minimize();
				//Aqf,qf
				dk.brics.automaton.Automaton dkAutNq = UtilAutomaton.convertToDkAutomaton(autP, accNr, accNr);
				dkAutNq.minimize();
				// intersection of three automata
				product = product.intersection(dkAutNq);
				product.minimize();

				if (!product.getAcceptStates().isEmpty()) {
					assert product.getAcceptStates().size() == 1;
					//suppose N = L(product), then N+ = N
					LDBABuilder builder = new LDBABuilder(product);
					dk.brics.automaton.Automaton buechi = builder.buildBuechi();
					//buechi.minimize();  // not sure it will be correct to use DFA minimization
					accAuts.add(buechi);
				}
			}

			State u = map.get(stateNr); // make epsilon transitions

			for (dk.brics.automaton.Automaton dkAut : accAuts) {
				State init = dkAut.getInitialState();
				for (Transition t : init.getTransitions())
					u.addTransition(new Transition(t.getMin(), t.getMax(), t.getDest()));
			}
		}

		dkAutL.removeDeadTransitions();
		return UtilAutomaton.convertToRabitAutomaton(dkAutL);
	}
	
//	// deserted
//	public static void makePreciseFDFA(LearnerFDFA learnerFDFA, MembershipOracle<Boolean> membershipOracle) {
//		// L means Leading and P means Progress
//
//		Automaton autL = learnerFDFA.getLeadingAutomaton();
//		int stateNr = 0;
//		while (stateNr < autL.getNumStates()) {
//
//			boolean found = false;
//			// for every acc in the progress automaton
//			// M
//			dk.brics.automaton.Automaton dkAutLOther = UtilAutomaton.convertToDkAutomaton(autL, stateNr, stateNr);
//			dkAutLOther.minimize();
//			do {
//
//				found = false;
//				Automaton autP = learnerFDFA.getProgressAutomaton(stateNr);
//				if (Options.verbose) {
//					System.out.println("leading : \n" + autL.toString());
//					System.out.println("progress for " + stateNr + " : \n" + autP.toString());
//				}
//
//				BitSet accs = autP.getAcceptingStates();
//				int initNr = autP.getInitialStates().nextSetBit(0);
//
//				// first get the intersection of three automata
//				dk.brics.automaton.Automaton dkAutPNPlus = dk.brics.automaton.Automaton.makeEmpty();
//				for (int accNr = accs.nextSetBit(0); accNr >= 0; accNr = accs.nextSetBit(accNr + 1)) {
//					// language N
//					dk.brics.automaton.Automaton dkAutPN = UtilAutomaton.convertToDkAutomaton(autP, initNr, accNr);
//					dkAutPN.minimize();
//					// first make sure that MN* = M
//					dkAutPN = dkAutLOther.clone().intersection(dkAutPN); // N
//					dkAutPN.minimize();
//					if (dkAutPN.isEmpty())
//						continue;
//					// then make N+ = N
//					dk.brics.automaton.Automaton dkAutPPlus = UtilAutomaton.convertToDkAutomaton(autP, accNr, accNr);
//					dkAutPPlus.minimize();
//					// the intersection of three automata
//					dkAutPN = dkAutPPlus.intersection(dkAutPN);
//					// union
//					dkAutPNPlus = dkAutPNPlus.union(dkAutPN);
//				}
//				String xyStr = null;
//				// get x, y
//				for (int accNr = accs.nextSetBit(0); accNr >= 0; accNr = accs.nextSetBit(accNr + 1)) {
//					// language N
//					dk.brics.automaton.Automaton dkAutPN = UtilAutomaton.convertToDkAutomaton(autP, initNr, accNr);
//					dkAutPN.minimize();
//					// first make sure that MN* = M
//					dkAutPN = dkAutLOther.clone().intersection(dkAutPN); // N
//					dkAutPN.minimize();
//					if (dkAutPN.isEmpty())
//						continue;
//					// then make N2 = N
//					dk.brics.automaton.Automaton dkAutPPlus = dkAutPN.clone();
//					dkAutPPlus = dkAutPPlus.concatenate(dkAutPN);
//					dkAutPPlus.minimize();
//					// x and y are in same equivalent class, then (xx, yx) or
//					// (yy, xy) are in same class
//
//					dkAutPPlus = dkAutPPlus.minus(dkAutPNPlus.clone());
//					xyStr = dkAutPPlus.getShortestExample(true);
//
//					if (xyStr != null) {
//						break;
//					}
//
//				}
//
//				if (xyStr != null) {
//					found = true; // still need to refine P
//
//					if (Options.verbose)
//						System.out.println("found v in N: " + xyStr);
//
//					Word u = learnerFDFA.getLeadingStateLabel(stateNr);
//					Word v = u.getContextWord().getWordFromString(xyStr);
//
//					boolean result = membershipOracle.answerMembershipQuery(new QuerySimple<>(u, v));
//
//					if (result) {
//						// since xy is in L and there is no xy omega in Buechi
//						learnerFDFA.refineHypothesis(new QuerySimple<>(u, v));
//					} else {
//						// (u, v) is not in L, and v is in autP
//						learnerFDFA.refineHypothesis(new QuerySimple<>(u, v));
//					}
//				}
//
//			} while (found);
//
//			++stateNr;
//		}
//
//	}

}
