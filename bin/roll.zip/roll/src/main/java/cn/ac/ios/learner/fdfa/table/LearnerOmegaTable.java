/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.learner.fdfa.table;


import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.automata.words.Word;
import cn.ac.ios.learner.table.LearnerTable;
import cn.ac.ios.learner.table.ObservationRowDFA;
import cn.ac.ios.query.MembershipOracle;
import cn.ac.ios.query.Query;
import cn.ac.ios.query.QuerySimple;
import cn.ac.ios.table.ObservationRow;

abstract class LearnerOmegaTable extends LearnerTable {

	public LearnerOmegaTable(WordManager contextWord, MembershipOracle<Boolean> membershipOracle) {
		super(contextWord, membershipOracle);
	}

	@Override
	protected boolean isOmegaLearning() {
		return true;
	}
	
	protected <T> Query<T> getQuerySimple(ObservationRow row, Word prefix, Word suffix, int column) {
		return new QuerySimple<>(row, prefix, suffix, column);
	}

	protected boolean processMembershipQuery(ObservationRow row, Word prefix, Word suffix, int column) {
		return membershipOracle.answerMembershipQuery(getQuerySimple(row, prefix, suffix, column));
	}
	
	protected void prepareRowDFA(ObservationRowDFA row) {
		
	}


}
