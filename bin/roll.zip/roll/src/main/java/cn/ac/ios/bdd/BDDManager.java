package cn.ac.ios.bdd;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import cn.ac.ios.automata.parser.hoa.Valuation;
import cn.ac.ios.automata.parser.hoa.ValuationIterator;
import gnu.trove.map.TIntObjectMap;
import gnu.trove.map.hash.TIntObjectHashMap;
import jhoafparser.ast.Atom;
import jhoafparser.ast.AtomLabel;
import jhoafparser.ast.BooleanExpression;
import jhoafparser.ast.BooleanExpression.Type;
import net.sf.javabdd.BDD;
import net.sf.javabdd.BDDFactory;
import net.sf.javabdd.BDDPairing;
/** 
 * TODO reimplement the BDD package and supports for clone BDD operation
 * */
public class BDDManager {
		
	private BDDFactory bdd;
	
	private TIntObjectMap<String> varsMap = new TIntObjectHashMap<>();
	
	public BDDManager(int numNodes, int numCache) {
		bdd = BDDFactory.init(numNodes, numCache);
		bdd.setMaxIncrease(10000);
	}
	
	public BDDManager() {
		this(125000, 100000);
	}
	
	public void setNumVar(int numVar) {
		assert bdd != null;
		bdd.setVarNum(numVar);
	}
	
    public int getNumVars() {
    	return bdd.varNum();
    }
    
    public void addExtraVarNum(int num) {
    	bdd.extVarNum(num);
    }
    
    public BDD getOne() {
    	return bdd.one();
    }
    
    public BDD getZero() {
    	return bdd.zero();
    }
    
    public BDD ithVar(int index) {
    	return bdd.ithVar(index);
    }
	
	// print one letter
    public String toString(BDD bdd) {
        if (bdd.isOne()) {
            return "t";
        } else if (bdd.isZero()) {
            return "f";
        } else {
            boolean first = false;
            String result = "";
            if (bdd.high().isOne()) {
                result += "" + bdd.var() + "";
                first = true;
            } else if (!bdd.high().isZero()) {
                result += "(" + bdd.var() + " & "
                    + toString(bdd.high()) + ")";
                first = true;
            }

            if (bdd.low().isOne()) {
                result += (first ? "|" : "") + "!"
                    + bdd.var() + "";
            } else if (!bdd.low().isZero()) {
                result += (first ? "|" : "") + "(!"
                    + bdd.var() + "&"
                    + toString(bdd.low()) + ")";
            }
            result = "(" + result + ")";
            return result;
        }
    }
    
	// change one letter to expression
    public BooleanExpression<Atom> toBoolExpr(BDD bdd) {
        if (bdd.isOne()) {
            return new BooleanExpression<>(true);
        } else if (bdd.isZero()) {
            return new BooleanExpression<>(false);
        } else {
            boolean first = false;
            BooleanExpression<Atom> atom = new BooleanExpression<>(
            		AtomLabel.createAPIndex(bdd.var()));
            BooleanExpression<Atom> result = null;
            if (bdd.high().isOne()) {
            	result = atom;
                first = true;
            } else if (!bdd.high().isZero()) {
            	result = new BooleanExpression<>(Type.EXP_AND
                		, atom
                		, toBoolExpr(bdd.high()));
                first = true;
            }

            if (bdd.low().isOne()) {
            	result =  first ? 
            			new BooleanExpression<>(Type.EXP_OR
                		, result
                		, atom.not()) // high | !low
            			: atom.not();
            } else if (!bdd.low().isZero()) {
            	BooleanExpression<Atom> lower = new BooleanExpression<>(Type.EXP_AND
    										, atom.not()
    										, toBoolExpr(bdd.low()));
            	result = first ? 
            			new BooleanExpression<>(Type.EXP_OR
                		, result
                		, lower) // high | low
            			: lower; // low
            }
            return result;
        }
    }
    
    public BDD fromBoolExpr(BooleanExpression<AtomLabel> boolExpr) {
    	assert boolExpr != null;
    	
    	if(boolExpr.isTRUE()) {
    		return bdd.one();
    	}else if(boolExpr.isFALSE()) {
    		return bdd.zero();
    	}else if(boolExpr.isAtom()) {
    		return bdd.ithVar(boolExpr.getAtom().getAPIndex()).andWith(bdd.one());
    	}else if(boolExpr.isNOT()) {
    		return fromBoolExpr(boolExpr.getLeft()).not();
    	}else {
    		BDD left = fromBoolExpr(boolExpr.getLeft());
    		BDD right = fromBoolExpr(boolExpr.getRight());
    		if(boolExpr.isAND()) {
    			return left.andWith(right);
    		}else {
    			return left.orWith(right);
    		}
    	}    	
    }
    
    public BDD fromValuation(Valuation val) {
    	BDD result = bdd.one();
    	for(int i = 0; i < val.size(); i ++) {
    		if(val.get(i)) {
    			result = result.andWith(bdd.ithVar(i).id());
    		}else {
    			result = result.andWith(bdd.ithVar(i).not());
    		}
    	}
		return result;
    }
    
    public Set<Valuation> toValuationSet(BDD ddSet, int size) {
    	Set<Valuation> valSet = new HashSet<>();
    	ValuationIterator valIter = new ValuationIterator(size);
    	while(valIter.hasNext()) {
    		Valuation val = valIter.next();
    		BDD dd = fromValuation(val);
    		dd = dd.and(ddSet);
    		if(! dd.isZero()) {
    			valSet.add(val);
    		}
    		dd.free();
    	}
		return valSet;
    }
    
    public Valuation toOneFullValuation(BDD dd) {
    	Valuation val = new Valuation(bdd.varNum());
    	for(int i = 0; i < bdd.varNum(); i ++) {
    		BDD var = bdd.ithVar(i).id();
    		var = var.andWith(dd.id());
    		val.set(i, !var.isZero());
    		var.free();
    	}
		return val;
    }
    
    public Set<Valuation> toValuationSet(BDD ddSet) {
    	Set<Valuation> valSet = new HashSet<>();

    	BDD dd = ddSet.id();
    	while(! dd.isZero()) {
    		BDD oneSat = dd.fullSatOne();
    		valSet.add(toOneFullValuation(oneSat));
    		dd = dd.andWith(oneSat.not());
    		oneSat.free();
    	}
    	
    	dd.free();
		return valSet;
    }
    
    public Set<BDD> toValuationSetBDD(BDD ddSet, int size) {
    	Set<BDD> valSet = new HashSet<>();
    	ValuationIterator valIter = new ValuationIterator(size);
    	while(valIter.hasNext()) {
    		BDD dd = fromValuation(valIter.next());
    		dd = dd.andWith(ddSet.not());
    		if(! dd.isZero()) {
    			valSet.add(dd);
    		}
    	}
		return valSet;
    }
    
    public void setVariableName(int var, String name) {
    	varsMap.put(var, name);
    }
    
    // TODO
    public String toDot(BDD bdd) {
        StringBuilder builder = new StringBuilder();
        builder.append("digraph {\n");
        builder.append("}\n");
        return builder.toString();
    }

    
    private String getName(int var) {
    	String name = varsMap.get(var);
    	if(name != null) return name;
    	return var + "";
    }
    
    public BDDPairing makeBDDPair(List<BDD> presVars, List<BDD> nextVars) {
		BDDPairing bddPair = bdd.makePair();
		for(int index = 0; index < presVars.size(); index ++) {
			bddPair.set(presVars.get(index).var(), nextVars.get(index).var());
		}
		for(int index = 0; index < presVars.size(); index ++) {
			bddPair.set(nextVars.get(index).var(), presVars.get(index).var());
		}
		return bddPair;
    }
    
    public void close() {
    	bdd.done();
    }
    
    
 


}
