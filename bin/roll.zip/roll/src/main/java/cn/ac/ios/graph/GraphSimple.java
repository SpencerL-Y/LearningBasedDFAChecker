/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.graph;

import gnu.trove.list.TIntList;
import gnu.trove.list.array.TIntArrayList;

import java.util.ArrayList;
import java.util.BitSet;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import cn.ac.ios.value.ValueManager;
import cn.ac.ios.value.Type;
import cn.ac.ios.value.Value;

// should add graph node one by one starting with 0
// classical adjacent graph data structure, which is not mutable

// modified from the IscasMC by Ernst Moritz Hahn

public class GraphSimple implements Graph {

	private final ValueManager valueManager;
	private BitSet queriedNodes;

	private final TIntList successorsStart = new TIntArrayList();     // store start index
    private final TIntArrayList successorSize = new TIntArrayList();  // store size for each node
    private TIntArrayList cachedSuccessorNodes = new TIntArrayList(); // store successors
    private int nextCachedSuccessorIndex ;
    private int[] currentSuccessorNodes;
	private int currentNode ;
	private int numSuccessors;
	private BitSet initNodes;
	
	
	public GraphSimple(ValueManager valueManager) {
		assert valueManager != null;
        this.initNodes = new BitSet();
        this.valueManager = valueManager;
        this.queriedNodes = new BitSet();
        this.nextCachedSuccessorIndex = 0;
	}

	@Override
	public ValueManager getValueManager() {
		return valueManager;
	}

	@Override
	public int getNumNodes() {
		return queriedNodes.length();
	}

	@Override
	public BitSet getInitialNodes() {
		return initNodes;
	}
	
    public void prepareNode(int numSuccessors)  {
        assert numSuccessors >= 0;
        queriedNodes.set(currentNode);
        this.numSuccessors = numSuccessors;
        prepareCachedSuccessors(currentNode, numSuccessors);
        while (cachedSuccessorNodes.size() <= nextCachedSuccessorIndex) {
            cachedSuccessorNodes.add(-1);
        }
    }

    public void setSuccessorNode(int succNr, int succState) {
        assert succState >= 0;
        int succEntry = getCachedSuccessorEntry(currentNode, succNr);
        cachedSuccessorNodes.set(succEntry, succState);
    }
    
	private void prepareCachedSuccessors(int node, int numSuccessors) {	
        while (successorsStart.size() <= node) {
        	successorsStart.add(-1);
        	successorSize.add(-1);
        }
        int fromNode = successorsStart.get(node); // no such node
        if (fromNode == -1) {
            successorsStart.set(node, nextCachedSuccessorIndex);            
            nextCachedSuccessorIndex += numSuccessors;  // next place
            successorSize.set(node, numSuccessors);    // the number of successors 
        }
	}

	@Override
	public void queryNode(int node) {
        assert node >= 0 : node;
        currentNode = node;
        numSuccessors = getCachedNumSuccessors(node);
        if (numSuccessors == -1) {
            return;
        }
        currentSuccessorNodes = new int[numSuccessors];
        for (int succNr = 0; succNr < numSuccessors; succNr++) {
            int entryNr = getCachedSuccessorEntry(node, succNr);
            currentSuccessorNodes[succNr] = cachedSuccessorNodes.get(entryNr);
        }
        queriedNodes.set(node);
	}

	private int getCachedSuccessorEntry(int node, int succNr) {
        assert node >= 0;
        assert node < successorsStart.size() : node + " " + successorsStart.size();
        return successorsStart.get(node) + succNr;
	}

	// get the number of successors of currentNode
	private int getCachedNumSuccessors(int node) {
		assert node >= 0 : "node error: " + node;
        int result;
        if (node >= successorSize.size()) {
            return -1;
        }// in this case, you should add nodes increasingly
        result = successorSize.get(node);
        assert result >= 0 : node;
        return result;
	}

	@Override
	public int getQueriedNode() {
		return currentNode;
	}

	@Override
	public int getNumSuccessors() {
		return numSuccessors;
	}

	@Override
	public int getSuccessorNode(int succNr) {
		assert succNr < numSuccessors && succNr >= 0;
		return currentSuccessorNodes[succNr];
	}
	
	
	// ------------ node properties
    private final class NodePropertyWrapperSettable implements NodeProperty {

        private final Graph graph;
        private final Type typeEntry;
        private final ArrayList<Value> contents;
        private final Value helper;
        
        NodePropertyWrapperSettable(GraphSimple graph, Type type) {
            assert graph != null;
            assert type != null;
            this.graph = graph;
            this.typeEntry = type;
            this.contents = new ArrayList<>();
            this.helper = typeEntry.newValue();
        }
        
        @Override
        public Value get() {
        	assert currentNode < contents.size();
        	helper.set(contents.get(currentNode));
            return helper;
        }
        
        @Override
        public void set(Value value) {
            assert value != null;
            assert typeEntry == value.getType() : typeEntry + "  " + value;
            contents.ensureCapacity(currentNode + 1);
            while(contents.size() <= currentNode ) {
            	contents.add(null);
            }
            contents.set(currentNode, value.clone());
        }

        @Override
        public Type getType() {
            return helper.getType();
        }

        @Override
        public Graph getGraph() {
            return graph;
        }
    }

    private final class EdgePropertyWrapperSettable implements EdgeProperty {

        private final Graph graph;
        private final Type typeEntry;
        private final ArrayList<Value> contents;
        private final Value helper;
        
        EdgePropertyWrapperSettable(GraphSimple graph, Type type) {
            assert graph != null;
            assert type != null;
            this.graph = graph;
            this.typeEntry = type;
            this.contents = new ArrayList<>();
            this.helper = typeEntry.newValue();
        }

        @Override
        public Value get(int successor) {
            assert successor >= 0;
            int entryNr = getCachedSuccessorEntry(currentNode, successor);
            assert entryNr < contents.size() : "OutOfBound " + entryNr + ":" + contents.size(); 
            helper.set(contents.get(entryNr));
            return helper;
        }

		@Override
        public void set(Value value, int successor) {
            assert value != null;
            assert typeEntry == value.getType() : typeEntry + "  " + value;
            assert successor >= 0;
            int entryNr = getCachedSuccessorEntry(currentNode, successor);
            contents.ensureCapacity(entryNr + 1);
            while(contents.size() <= entryNr) {
            	contents.add(null);
            }
            contents.set(entryNr, value.clone());
        }

        @Override
        public Type getType() {
            return typeEntry;
        }

        @Override
        public Graph getGraph() {
            return graph;
        }
    }
    
	// ------------ add properties 
    private final Map<Object, Value> graphProperties = new LinkedHashMap<>();
    private final Map<Object, NodeProperty> nodeProperties = new LinkedHashMap<>();
    private final Map<Object, EdgeProperty> edgeProperties = new LinkedHashMap<>();
    
    // add settable graph property (property, type)
    public Value addSettableGraphProperty(Object property, Type type)  {
        assert property != null;
        assert type != null;
        registerGraphProperty(property, type);
        return getGraphProperty(property);
    }

	public NodeProperty addSettableNodeProperty(Object property, Type type) {
        assert type != null && property != null;
        assert type.getContext() == valueManager;
        NodeProperty result = new NodePropertyWrapperSettable(this, type);
        registerNodeProperty(property, result);
        return result;
    }

	public EdgeProperty addSettableEdgeProperty(Object property, Type type) {
        assert type != null && property != null;
        EdgePropertyWrapperSettable result = new EdgePropertyWrapperSettable(this, type);
        registerEdgeProperty(property, result);
        return result;
    }
	
    public void registerGraphProperty(Object propertyName, Type type) {
        assert propertyName != null;
        assert type != null;
        assert !graphProperties.containsKey(propertyName);
        graphProperties.put(propertyName, type.newValue());
    }
	
    public void registerNodeProperty(Object property,
            NodeProperty result) {
        assert property != null;
        assert result != null;
        if (nodeProperties.containsKey(property)) {
            return;
        }
        nodeProperties.put(property, result);
    }

    private void registerEdgeProperty(Object property,
			EdgeProperty result) {
        assert property != null;
        assert result != null;
        if (edgeProperties.containsKey(property)) {
            return;
        }
        edgeProperties.put(property, result);
	}

    public Value getGraphProperty(Object property) {
        return graphProperties.get(property);
    }
    
	public Set<Object> getGraphProperties() {
		return Collections.unmodifiableSet(graphProperties.keySet());
	}
	
    public NodeProperty getNodeProperty(Object property) {
        return nodeProperties.get(property);
    }

    public Set<Object> getNodeProperties() {
        return Collections.unmodifiableSet(nodeProperties.keySet());
    }
    
    public EdgeProperty getEdgeProperty(Object property) {
        return edgeProperties.get(property);
    }

    public Set<Object> getEdgeProperties() {
        return Collections.unmodifiableSet(edgeProperties.keySet());
    }
    
    public String toString() {
    	return GraphExporterDOT.toString(this);
    }
}
