/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.learner.fdfa.tree;

import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.automata.words.Word;
import cn.ac.ios.learner.tree.LearnerTree;
import cn.ac.ios.query.MembershipOracle;
import cn.ac.ios.query.Query;
import cn.ac.ios.query.QuerySimple;
import cn.ac.ios.table.ExprValue;

abstract class LearnerOmegaTree extends LearnerTree {

	public LearnerOmegaTree(WordManager contextWord, MembershipOracle<Boolean> membershipOracle) {
		super(contextWord, membershipOracle);
	}

	@Override
	public boolean isOmegaLearning() {
		return true;
	}

	@Override
	public boolean isLeading() {
		return false;
	}
	
	@Override
	protected boolean processMembershipQuery(Word label, ExprValue valueExpr) {
		assert false : "illegal method call";
		return false;
	}
	
	@Override
	protected boolean processMembershipQuery(ExprValue valueExpr) {
		assert false : "illegal method call";
		return false;
	}
	
	private Query<Boolean> getQuerySimple(Word prefix, Word suffix) {
		return new QuerySimple<>(prefix, suffix);
	}

	@Override
	protected boolean processMembershipQuery(Word row, Word column) {
		return membershipOracle.answerMembershipQuery(getQuerySimple(row, column));
	}
	
	// accepting information for returned counter example
	protected boolean isCEAccepting;
	


}
