/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.roll.sampler;

import java.util.Set;

import cn.ac.ios.automata.Acceptor;
import cn.ac.ios.automata.Automaton;
import cn.ac.ios.learner.Learner;
import cn.ac.ios.learner.buechi.ldollar.LearnerOmegaBuechi;
import cn.ac.ios.learner.fdfa.LearnerFDFA;
import cn.ac.ios.query.MembershipOracle;
import cn.ac.ios.query.Query;
import cn.ac.ios.util.DollarAutomatonBuilder;
import cn.ac.ios.util.Pair;
import cn.ac.ios.util.UtilAutomaton;
import dk.brics.automaton.State;
import dk.brics.automaton.Transition;
import oracle.EqResult;


//Sampling function before equivalence check

public class FASampler {
	
	private Learner<? extends Acceptor, Boolean> learner;
	private MembershipOracle<Boolean> membershipOracle;
	
	public FASampler(Learner<? extends Acceptor, Boolean> learner,
			MembershipOracle<Boolean> membershipOracle) {
		assert learner != null && membershipOracle != null;
		this.learner = learner;
		this.membershipOracle = membershipOracle;
	}
	
	public void sample() {
		dk.brics.automaton.Automaton automaton = null;
		boolean isOmegaLearning = false;
		if(learner instanceof LearnerFDFA) {
			LearnerFDFA learnerFDFA = (LearnerFDFA)learner;
			automaton = DollarAutomatonBuilder.buildDollarNFA(learnerFDFA);
			isOmegaLearning = true;
		}if(learner instanceof LearnerOmegaBuechi) {
			automaton = UtilAutomaton.convertToDkAutomaton((Automaton)learner.getHypothesis());
			isOmegaLearning = true;
		}else {
			automaton = UtilAutomaton.convertToDkAutomaton((Automaton)learner.getHypothesis());
		}
		
		
	}
	
	public Pair<Character, State> pickNextState(State s) {
		
		Set<Transition> ts = s.getTransitions();
		
		return null;
		
	}
	
	public Query<EqResult> getCounterexample() {
		return null;
	}

}
