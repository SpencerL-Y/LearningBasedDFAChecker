/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.roll.oracle;

import cn.ac.ios.automata.Automaton;
import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.util.UtilAutomaton;
import dk.brics.automaton.State;
import dk.brics.automaton.Transition;
import gnu.trove.map.TIntObjectMap;
import gnu.trove.map.hash.TIntObjectHashMap;

// normalize decomposition (u, v)
public class Normalizer {
	
	// normalize pair (u, v) with respect to leading automaton autL
	// it will be the smallest one 0 <= i < j
	public static String normalize(String uv, Automaton autL) {
		TIntObjectMap<State> map = new TIntObjectHashMap<>(); 
		dk.brics.automaton.Automaton dkAutL = UtilAutomaton.convertToDkAutomaton(map, autL);
		int dollarNr = uv.indexOf(WordManager.getStringDollar());
		
		String u = uv.substring(0, dollarNr);
		String v = uv.substring(dollarNr + 1);
		
		dk.brics.automaton.Automaton dkAutStr = dk.brics.automaton.Automaton.makeString(u);
		dk.brics.automaton.Automaton dkAutStrV = dk.brics.automaton.Automaton.makeString(v);
		dk.brics.automaton.Automaton dkAutStrDollar = dk.brics.automaton.Automaton.makeString(WordManager.getStringDollar());
		dk.brics.automaton.Automaton dkAutStrVStar = dkAutStrV.clone().repeat(0); // V*
		dk.brics.automaton.Automaton dkAutStrVPlus = dkAutStrV.clone().repeat(1); // V+
		
		dkAutStr = dkAutStr.concatenate(dkAutStrVStar);
		dkAutStr = dkAutStr.concatenate(dkAutStrDollar);
		dkAutStr = dkAutStr.concatenate(dkAutStrVPlus);
		
		dkAutStr.minimize();
		
		for(int stateNr = 0; stateNr < autL.getNumStates() ; stateNr ++) {
			dk.brics.automaton.Automaton dkAutLOther = UtilAutomaton.convertToDkAutomaton(autL, stateNr, stateNr);
			State state = map.get(stateNr);
			Transition trans = new Transition(WordManager.getStringDollar().charAt(0), dkAutLOther.getInitialState());
			state.addTransition(trans);
			dk.brics.automaton.Automaton dkAutInter = dkAutStr.intersection(dkAutL);
			String decomposition = dkAutInter.getShortestExample(true);
			
			if(decomposition != null) {
				return decomposition;
			}
			
			state.getTransitions().remove(trans);
		}
		
		assert false : "normalized counterexample";
		return null;
	}

}
