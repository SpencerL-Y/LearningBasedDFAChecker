/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.learner.fdfa.table;

import java.util.List;

import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.automata.words.Word;
import cn.ac.ios.learner.table.ObservationRowDFA;
import cn.ac.ios.learner.table.ObservationTableDFA;
import cn.ac.ios.query.MembershipOracle;
import cn.ac.ios.table.ExprValue;
import cn.ac.ios.table.HashableValue;
import cn.ac.ios.table.ObservationRow;

public class LearnerProgressTableRecurrent extends LearnerProgressTable {

	public LearnerProgressTableRecurrent(WordManager contextWord
			, MembershipOracle<Boolean> membershipOracle
			, Word label) {
		super(contextWord, membershipOracle, label);
	}

	@Override
	protected ObservationTableDFA getTableInstance(WordManager contextWord) {
		return new ObservationTableDFARecurrent(contextWord);
	}
	
	private class ObservationTableDFARecurrent extends ObservationTableDFA {

		protected ObservationTableDFARecurrent(WordManager contextWord) {
			super(contextWord);
		}

		@Override
		public ObservationRowDFA getRowInstance(Word word) {
			return new ObservationRowRecurrent(word);
		}
	}
	
	private class ObservationRowRecurrent extends ObservationRowDFA {

		protected ObservationRowRecurrent(Word word) {
			super(word);
		}

		@Override
		public void setLeadingState(int state) {			
		}
		
		// two elements are equal if (m1, c1) = (T, T) and (m2, c2) = (T, T) or otherwise
		// return false
		@Override
		public boolean valuesEqual(ObservationRow other) {
			assert other instanceof ObservationRowRecurrent;
			List<HashableValue> thisValues = getValues();
			List<HashableValue> otherValues = other.getValues();
			assert thisValues.size() == otherValues.size();
			for(int valNr = 0; valNr < thisValues.size(); valNr ++) {
				if(thisValues.get(valNr).isAccepting()
				!= otherValues.get(valNr).isAccepting()) {
					return false;
				}
			}
			return true;
		}
		
	}
	
	// counter example analysis
	protected class CeAnalyzerTableRecurrent extends CeAnalyzer {

		public CeAnalyzerTableRecurrent(ExprValue exprValue) {
			super(exprValue);
		}

		@Override
		public void analyze() {
			Word wordCE = exprValue.get();
			// initially uv ~ u since input is normalized factorization
			HashableValue resultPrev = getHashableValueBoolean(isCEAccepting, true);
			
			//(m1, c1) and (m2, c2), one out of thoese two is (true, true) 
			// while the other one is not
			int stateCurr, statePrev = getInitState();
			for(int letterNr = 0; letterNr < wordCE.length(); letterNr ++) {
				stateCurr = computeNextState(statePrev, wordCE.getLetter(letterNr));
				Word period = getStateLabel(stateCurr);
				period = period.concat(wordCE.getSuffix(letterNr + 1));
				HashableValue resultCurr = processMembershipQuery(period);

				if(resultPrev.isAccepting() != resultCurr.isAccepting()) {
					column = getExprValueWord(wordCE.getSuffix(letterNr + 1));
					break;
				}
				statePrev = stateCurr;
				// resultPrev = resultCurr; // no need
			}			
		}
	}

	@Override
	protected CeAnalyzer getCeAnalyzerInstance(ExprValue exprValue) {
		return new CeAnalyzerTableRecurrent(exprValue);
	}

}
