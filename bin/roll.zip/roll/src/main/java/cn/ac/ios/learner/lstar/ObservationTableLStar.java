/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.learner.lstar;

import java.io.ByteArrayOutputStream;

import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.automata.words.Word;
import cn.ac.ios.table.ExprValue;
import cn.ac.ios.table.ExprValueWord;
import cn.ac.ios.table.ObservationRow;
import cn.ac.ios.table.ObservationTableAbstract;
import cn.ac.ios.table.ObservationTablePrinterBoolean;
import cn.ac.ios.table.HashableValue;
import cn.ac.ios.table.HashableValueBoolean;

class ObservationTableLStar extends ObservationTableAbstract {
	
	ObservationTableLStar(WordManager contextWord) {
		super(contextWord);
		//1. upperTable add the epsilon row
		upperTable.add(new ObservationRowLStar(contextWord.getEmptyWord()));
		//2. columns add the epsilon column
		columns.add(new ExprValueWord(contextWord.getEmptyWord()));
	}
	
	
	
	@Override
	public ObservationRow getUnclosedLowerRow() {
		for(ObservationRow lowerRow : lowerTable) {
			boolean found = false;
			for(ObservationRow upperRow : upperTable) {
				if(lowerRow.getValues().equals(upperRow.getValues())) {
					found = true;
					break;
				}
			}
			if(!found) {
				return lowerRow;
			}
		}
		return null;
	}

	// row(s1) = row(s2) then it should be row(s1.a) = row(s2.a) for every a
	@Override
	public Word getInconsistentColumn() {
		for(int letter = 0; letter < contextWord.getNumLetters(); letter ++) {
			for(int rowNr1 = 0; rowNr1 < upperTable.size(); rowNr1 ++) {
				for(int rowNr2 = rowNr1 + 1; rowNr2 < upperTable.size(); rowNr2 ++) {
					ObservationRow upperRow1 = upperTable.get(rowNr1);
					ObservationRow upperRow2 = upperTable.get(rowNr2);
					if(upperRow1.getValues().equals(upperRow2.getValues())) {
						ObservationRow rowState1 = getTableRow(upperRow1.getWord().append(letter));
						ObservationRow rowState2 = getTableRow(upperRow2.getWord().append(letter));
						Word columnExperiment = checkConsistency(rowState1, rowState2);
						if(columnExperiment != null) return columnExperiment.preappend(letter);
					}
				}
			}
		}
		return null;
	}
	// if row(s1.a) = row(s.a) return null
	private Word checkConsistency(
			ObservationRow row1
		  , ObservationRow row2) {
		int index = 0;
		Word columnExperiment = null;
		while(index < columns.size()) {
			if(!row1.getValues().get(index).valueEqual(row2.getValues().get(index))) {
				columnExperiment = columns.get(index).get();
				break;
			}
			++ index; 
		}
		return columnExperiment;
	}
 
	public String toString() {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try {
        	ObservationTablePrinterBoolean.print(this, out);
            return out.toString();
        } catch (Exception e) {
            return "ERROR";
        }
	}
	
    // simple add methods, do not contain any check 
	@Override
	public ObservationRow addLowerRow(Word word) {
		ObservationRow row = new ObservationRowLStar(word);
		lowerTable.add(row);
		return row;
	}

	@Override
	public ObservationRow addUpperRow(Word word) {
		ObservationRow row = new ObservationRowLStar(word);
		upperTable.add(row);
		return row;
	}
	
	public HashableValue getHashableValueByBool(boolean value) {
		return new HashableValueBoolean(value);
	}
	
	public ExprValue getExprValueByWord(Word word) {
		return new ExprValueWord(word);
	}


}
