/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.learner.fdfa.table;

import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.automata.words.Word;
import cn.ac.ios.learner.fdfa.LearnerLeading;
import cn.ac.ios.learner.fdfa.LearnerProgress;
import cn.ac.ios.query.MembershipOracle;
import cn.ac.ios.query.Query;
import cn.ac.ios.table.ExprValue;
import cn.ac.ios.table.HashableValue;
import cn.ac.ios.table.ObservationRow;

abstract class LearnerProgressTable extends LearnerOmegaTable implements LearnerProgress {

	protected final Word label; 
	protected LearnerLeading learnerLeading;
	protected int state;
	
	public LearnerProgressTable(WordManager contextWord
			, MembershipOracle<Boolean> membershipOracle
			, Word label) {
		super(contextWord, membershipOracle);
		this.label = label;
	}
	
	@Override
	public void startLearning() {
		initializeTable();
	}

	@Override
	protected Query<HashableValue> processMembershipQuery(ObservationRow row, int offset, ExprValue valueExpr) {
		Word suffix = row.getWord();
		Word expr = valueExpr.get();
		suffix = suffix.concat(expr);
		boolean resultLeft = processMembershipQuery(row, label, suffix, offset);
		Query<HashableValue> query = getQuerySimple(row, label, suffix, offset);
		int stateReachByXV = learnerLeading.computeReachState(state, suffix);
		boolean resultRight = state == stateReachByXV;
		query.answerQuery(getHashableValueBoolean(resultLeft, resultRight));
		return query;
	}
	
	// for syntactic and recurrent FDFA, only for
	// computing (m, c) for counter example analysis
	protected HashableValue processMembershipQuery(Word suffix) {
		boolean resultLeft = processMembershipQuery(null, label, suffix, 0);
		int stateReachByXV = learnerLeading.computeReachState(state, suffix);
		boolean resultRight = state == stateReachByXV;
		return getHashableValueBoolean(resultLeft, resultRight);
	}

	protected boolean isCEAccepting;
	
	@Override
	protected ExprValue getCounterExampleWord(Query<Boolean> query) {
		isCEAccepting = query.getQueryAnswer();
		return getExprValueWord(query.getSuffix());
	}
	
	public Word getLeadingLabel() {
		return label;
	}
	
	//0
	public void setLearnerLeading(LearnerLeading learnerLeading) {
		this.learnerLeading = learnerLeading;
		this.state = learnerLeading.computeReachState(label);
	}
	
	protected class CeAnalyzerTable extends CeAnalyzer {

		public CeAnalyzerTable(ExprValue exprValue) {
			super(exprValue);
		}

		@Override
		public void analyze() {
			Word wordCE = exprValue.get();
			boolean resultPrev = isCEAccepting, resultCurr;
			int stateCurr, statePrev = getInitState();
			for(int letterNr = 0; letterNr < wordCE.length(); letterNr ++) {
				stateCurr = computeNextState(statePrev, wordCE.getLetter(letterNr));
				Word period = getStateLabel(stateCurr);
				period = period.concat(wordCE.getSuffix(letterNr + 1));
				resultCurr = processMembershipQuery(null, label, period, 0);
				if(resultPrev != resultCurr) {
					column = getExprValueWord(wordCE.getSuffix(letterNr + 1));
					break;
				}
				statePrev = stateCurr;
				// resultPrev = resultCurr; // no need
			}			
		}
		
	}

	@Override
	protected CeAnalyzer getCeAnalyzerInstance(ExprValue exprValue) {
		return new CeAnalyzerTable(exprValue);
	}
	

}
