/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.value;

class TypeBoolean implements Type{ 

	private final ValueManager contextValue;
	private Value knownValue = null;
	private Value valueFalse = new ValueBoolean(this, false);
	private Value valueTrue = new ValueBoolean(this, true);
	
	TypeBoolean(ValueManager contextValue, Value known) {
		assert contextValue != null;
		this.contextValue = contextValue;
		if(known != null) {
			this.knownValue = known.clone();
			this.knownValue.setImmutable();
		}
		valueFalse.setImmutable();
		valueTrue.setImmutable();
	}
	
	TypeBoolean(ValueManager contextValue) {
		this(contextValue, null);
	}
	
	@Override
	public ValueManager getContext() {
		return contextValue;
	}

	public Value newValue() {
		if(getKnownValue() != null) {
			return getKnownValue().clone();
		}else {
			return new ValueBoolean(this);
		}
	}
	@Override
	public Type clone() {
		return new TypeBoolean(contextValue, knownValue);
	}

	@Override
	public void setKnownValue(Value val) {
		assert val != null;
		assert val.isBoolean();

		this.knownValue = val.clone();
		this.knownValue.setImmutable();
	}

	@Override
	public Value getKnownValue() {
		return this.knownValue;
	}

	@Override
	public boolean isBoolean() {
		return true;
	}
	
    public Value getFalse() {
    	return valueFalse;
    }

    public Value getTrue() {
    	return valueTrue;
    }
    
    public boolean equals(Object obj) {
    	if(! (obj instanceof TypeBoolean)) {
    		return false;
    	}
    	return true;
    }
    
    public String toString() {
    	return "bool";
    }

}
