package cn.ac.ios.automata.parser.hoa;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import automata.FAState;
import automata.FiniteAutomaton;
import cn.ac.ios.bdd.BDDManager;
import cn.ac.ios.roll.Statistics;
import gnu.trove.map.TIntObjectMap;
import gnu.trove.map.TObjectCharMap;
import gnu.trove.map.hash.TIntObjectHashMap;
import gnu.trove.map.hash.TObjectCharHashMap;
import jhoafparser.ast.AtomAcceptance;
import jhoafparser.ast.AtomLabel;
import jhoafparser.ast.BooleanExpression;
import jhoafparser.consumer.HOAConsumer;
import jhoafparser.consumer.HOAConsumerException;
import jhoafparser.parser.HOAFParser;
import jhoafparser.parser.generated.ParseException;
import net.sf.javabdd.BDD;

public class HanoiParser implements HOAConsumer {
	
	// this class only allow the characters
	
	private FiniteAutomaton automaton;
	private TIntObjectMap<FAState> stateMap = new TIntObjectHashMap<>();
	// corresponds string to character
	private TObjectCharMap<String> atomMap = new TObjectCharHashMap<>();

	private BDD allLeftLabels;
	private Valuation otherVal = null;
	private final int VAR_NUM_BOUND = 6;
	public HanoiParser(String name) {
		automaton = new FiniteAutomaton();
		try {
			InputStream fileInputStream = new FileInputStream(name);
			HOAFParser.parseHOA(fileInputStream, this);
			// now check if every possible combination of AP are there
			BDD leftLabels = allLeftLabels.not();
			
			if(! leftLabels.isZero()) {
				BDD oneSat = leftLabels.fullSatOne();
				otherVal = bddManager.toOneFullValuation(oneSat);
				oneSat.free();
				automaton.alphabet.add(""+getLabel(otherVal));
			}
			allLeftLabels.free();
			allLeftLabels = leftLabels;
		} catch (ParseException e) {
			e.printStackTrace();
		} catch(FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	/** new members to handle HANOI format */
	private BDDManager bddManager;
	private APSet apset;
	private Map<String, Valuation> atomMapInv = new HashMap<>(); 
	
	// we reserve '$'
	private char getLabel(Valuation label) {
		
		String atom = label.toString();
		char ch = 0;
		if(atomMap.containsKey(atom)) {
			return atomMap.get(atom);
		}
		
		ch = (char) atomMap.size();
		if(ch >= '$' )   ch ++; // reserve '$' sign
		atomMap.put(atom, ch);
		atomMapInv.put(ch + "", label);
		return ch;
	}
	
	public FiniteAutomaton getAutomaton() {
		return automaton;
	}

	@Override
	public boolean parserResolvesAliases() {
		return false;
	}

	@Override
	public void notifyHeaderStart(String version) throws HOAConsumerException {
	}

	@Override
	public void setNumberOfStates(int numberOfStates) throws HOAConsumerException {
		for(int stateNr = 0; stateNr < numberOfStates; stateNr ++) {
			stateMap.put(stateNr, automaton.createState());
		}
	}

	/**
	 * Multiple states in stateConjunction are for alternating automaton
	 * in our setting, we only specify one state each time. 
	 * */
	@Override
	public void addStartStates(List<Integer> stateConjunction) throws HOAConsumerException {
		assert stateConjunction.size() == 1 : "only allow one initial state one time";
		int initNr = stateConjunction.get(0);
		automaton.setInitialState(stateMap.get(initNr));
	}

	/**
	 * we allow alias in the given HANOI file
	 * */
	private Map<String, BDD> aliasMap = new HashMap<>();
	@Override
	public void addAlias(String name, BooleanExpression<AtomLabel> labelExpr) throws HOAConsumerException {
		aliasMap.put(name, bddManager.fromBoolExpr(labelExpr));
	}
	
	

	/**
	 * prepare the atomic proposition set
	 * */
	@Override
	public void setAPs(List<String> aps) throws HOAConsumerException {
		apset = new APSet(aps);
		bddManager = new BDDManager();
		bddManager.setNumVar(apset.size());
		allLeftLabels = bddManager.getZero();
		System.out.println("alphabet: " + apset + " size: " + apset.size());
	}

	/** only allow buechi condition */
	@Override
	public void setAcceptanceCondition(int numberOfSets, BooleanExpression<AtomAcceptance> accExpr)
			throws HOAConsumerException {
         assert numberOfSets == 1 ;
         // by default this is Buchi acceptance conditions
	}

	@Override
	public void provideAcceptanceName(String name, List<Object> extraInfo) throws HOAConsumerException {
		// do not care
	}

	@Override
	public void setName(String name) throws HOAConsumerException {
		// do not care
	}

	@Override
	public void setTool(String name, String version) throws HOAConsumerException {	
		// do not care
	}

	@Override
	public void addProperties(List<String> properties) throws HOAConsumerException {
		// do not care
	}

	@Override
	public void addMiscHeader(String name, List<Object> content) throws HOAConsumerException {
		// do not care
	}

	@Override
	public void notifyBodyStart() throws HOAConsumerException {
		// do not care
	}

	@Override
	public void addState(int id, String info, BooleanExpression<AtomLabel> labelExpr, List<Integer> accSignature)
			throws HOAConsumerException {
		// only need to consider the labels of this state
		if(accSignature != null && accSignature.size() > 0) {
			automaton.F.add(stateMap.get(id));
		}
	}

	@Override
	public void addEdgeImplicit(int stateId, List<Integer> conjSuccessors, List<Integer> accSignature)
			throws HOAConsumerException {
		System.out.println("hello word");
	}


	/** add support for Alias*/
	@Override
	public void addEdgeWithLabel(int stateId, BooleanExpression<AtomLabel> labelExpr, List<Integer> conjSuccessors,
			List<Integer> accSignature) throws HOAConsumerException {
		assert conjSuccessors.size() == 1: "only allow one successors";
		assert labelExpr != null;
		
		if(conjSuccessors.size() != 1) {
			System.err.println("successor conjunction does not allowed");
			System.exit(-1);
		}
		int targetId = conjSuccessors.get(0);
//		System.out.println(labelExpr);
		BDD expr = null;
		
		if(labelExpr.getAtom() != null && labelExpr.getAtom().isAlias()) {
			expr = aliasMap.get(labelExpr.getAtom().getAliasName()).id();
		}else {
			expr = bddManager.fromBoolExpr(labelExpr);
		}
		Set<Valuation> vals = null;
		if(apset.size() <= VAR_NUM_BOUND) {
			vals = bddManager.toValuationSet(expr, apset.size());
		}else {
			vals = bddManager.toValuationSet(expr);
		}
		// record every transition label
		allLeftLabels = allLeftLabels.orWith(expr);
//		System.out.println(vals);		
		addTransition(stateId, vals, targetId);
	}
	
	private void addTransition(int sourceId, Set<Valuation> vals, int targetId) {
		FAState source = stateMap.get(sourceId); 
		FAState target = stateMap.get(targetId);
        for(Valuation val : vals) {
        	automaton.addTransition(source, target, "" + getLabel(val));
        }
	}

	@Override
	public void notifyEndOfState(int stateId) throws HOAConsumerException {
	}

	@Override
	public void notifyEnd() throws HOAConsumerException {	
	}

	@Override
	public void notifyAbort() {		
	}

	@Override
	public void notifyWarning(String warning) throws HOAConsumerException {		
	}
	
	public static void main(String []args) {
		String file = "/home/liyong/Desktop/learning/hoa/exp1.hoa";
		HanoiParser parser = new HanoiParser(file);
		parser.print(parser.getAutomaton(), System.out);
	}
	
	public void print(FiniteAutomaton automaton, OutputStream stream) {
		
		PrintStream out = new PrintStream(stream);
        out.println("//Buechi ");
        out.println("digraph {");
        
        Set<FAState> states = automaton.states;
        for (FAState state : states) {
            out.print("  " + state.id + " [label=\"" +  state.id + "\"");
            if(automaton.F.contains(state)) out.print(", shape = doublecircle");
            else out.print(", shape = circle");
            out.println("];");
            for (String label : automaton.getAllTransitionSymbols()) {
            	Set<FAState> succs = state.getNext(label);
            	Valuation valuation = atomMapInv.get(label);
            	if(succs == null) continue;
            	for(FAState succ : succs) {
            		out.println("  " + state.id + " -> " + succ.id + " [label=\"" + valuation.toString(apset) + "\"];");
            	}
            }
        }	
        out.println("  " + states.size() + " [label=\"\", shape = plaintext];");
        FAState initState = automaton.getInitialState();
        out.println("  " + states.size() + " -> " + initState.id + " [label=\"\"];");
        out.println();
        out.println("}");
   }
	
	public void print1(FiniteAutomaton automaton, OutputStream stream) {
		
		PrintStream out = new PrintStream(stream);
        out.println("//Buechi ");
        out.println("digraph {");
        
        Set<FAState> states = automaton.states;
        for (FAState state : states) {
            out.print("  " + state.id + " [label=\"" +  state.id + "\"");
            if(automaton.F.contains(state)) out.print(", shape = doublecircle");
            else out.print(", shape = circle");
            out.println("];");
            for (String label : automaton.getAllTransitionSymbols()) {
            	Set<FAState> succs = state.getNext(label);
            	if(succs == null) continue;
            	for(FAState succ : succs) {
            		out.println("  " + state.id + " -> " + succ.id + " [label=\"" + ((int)label.charAt(0)) + "\"];");
            	}
            }
        }	
        out.println("  " + states.size() + " [label=\"\", shape = plaintext];");
        FAState initState = automaton.getInitialState();
        out.println("  " + states.size() + " -> " + initState.id + " [label=\"\"];");
        out.println();
        out.println("}");
   }
	
	
	public void printHOA(FiniteAutomaton automaton, OutputStream stream) {
		
		PrintStream out = new PrintStream(stream);
        out.println("HOA: v1");
        out.println("tool: \"BuechiC\"");
        out.println("properties: explicit-labels state-acc trans-labels ");
        
        Set<FAState> states = automaton.states;
        out.println("States: " + states.size());
        out.println("Start: " + automaton.getInitialState().id);
        out.println("acc-name: Buchi");
        out.println("Acceptance: 1 Inf(0)");
        out.print("AP: " + apset.size());
        for(int index = 0; index < apset.size(); index ++) {
        	out.print(" \"" + apset.getAP(index) + "\"");
        }
        out.println();
        out.println("--BODY--");
        Statistics.numTransHypothesis = 0;
        for (FAState state : states) {
        	out.print("State: " + state.id);
            if(automaton.F.contains(state)) out.print(" {0}");
            out.println();
            Map<FAState, BDD> succLabels = new HashMap<>();
            for (String label : automaton.getAllTransitionSymbols()) {
            	Set<FAState> succs = state.getNext(label);
            	BDD labelDD = getBDDFromLabel(label);
            	if(succs == null) continue;
            	for(FAState succ : succs) {
            		BDD succLab = succLabels.get(succ);
            		if(succLab == null) {
            			succLab = bddManager.getZero();
            		}
            		succLab = succLab.orWith(labelDD.id());
            		succLabels.put(succ, succLab);
            	}
            	labelDD.free();
            }
            
            for(Map.Entry<FAState, BDD> entry : succLabels.entrySet()) {
            	Statistics.numTransHypothesis ++;
            	out.println("[" + bddManager.toString(entry.getValue()) + "]  " + entry.getKey().id);
            	entry.getValue().free();
            }
        }	
        out.println("--END--");
   }
	
	public void printHOA1(FiniteAutomaton automaton, OutputStream stream) {
		
		PrintStream out = new PrintStream(stream);
        out.println("HOA: v1");
        out.println("tool: \"BuechiC\"");
        out.println("properties: explicit-labels state-acc trans-labels ");
        
        Set<FAState> states = automaton.states;
        out.println("States: " + states.size());
        out.println("Start: " + automaton.getInitialState().id);
        out.println("acc-name: Buchi");
        out.println("Acceptance: 1 Inf(0)");
        out.print("AP: " + apset.size());
        for(int index = 0; index < apset.size(); index ++) {
        	out.print(" \"" + apset.getAP(index) + "\"");
        }
        out.println();
        out.println("--BODY--");
        Statistics.numTransHypothesis = 0;
        for (FAState state : states) {
        	out.print("State: " + state.id);
            if(automaton.F.contains(state)) out.print(" {0}");
            out.println();

            for (String label : automaton.getAllTransitionSymbols()) {
            	Set<FAState> succs = state.getNext(label);
            	if(succs == null) continue;
            	BDD labelDD = getBDDFromLabel(label);
            	for(FAState succ : succs) {
            		out.println("[" + bddManager.toString(labelDD)+ "]  " + succ.id);
            	}
            }
        }	
        out.println("--END--");
   }
	
	public void close() {
		allLeftLabels.free();
		for(BDD dd : aliasMap.values()) {
			dd.free();
		}
		bddManager.close();
	}
	
	private BDD getBDDFromLabel(String label) {
		Valuation valuation = atomMapInv.get(label);
		if(valuation == otherVal) {
			return allLeftLabels.id();
		}else {
			return bddManager.fromValuation(valuation);
		}
	}

}

