/* Written by Yong Li, Depeng Liu                                       */
/* Copyright (c) 2016                  	                               */
/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                  */

/* This program is distributed in the hope that it will be useful,      */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/* GNU General Public License for more details.                         */

/* You should have received a copy of the GNU General Public License    */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

package cn.ac.ios.learner.dfa.table;

import cn.ac.ios.automata.words.WordManager;
import cn.ac.ios.automata.words.Word;
import cn.ac.ios.learner.table.LearnerTable;
import cn.ac.ios.learner.table.ObservationRowDFA;
import cn.ac.ios.query.MembershipOracle;
import cn.ac.ios.query.Query;
import cn.ac.ios.query.QuerySimple;
import cn.ac.ios.table.ExprValue;
import cn.ac.ios.table.HashableValue;
import cn.ac.ios.table.ObservationRow;

/**
 * An improved table-based DFA learning algorithm which uses a suffix of the counterexample
 * to refine the conjecture upon receiving 'no'
 * */
public class LearnerDFATable extends LearnerTable {

	public LearnerDFATable(WordManager contextWord, MembershipOracle<Boolean> membershipOracle) {
		super(contextWord, membershipOracle);
	}

	@Override
	protected boolean isOmegaLearning() {
		return false;
	}

	@Override
	protected void prepareRowDFA(ObservationRowDFA row) {
	}

	@Override
	protected Query<HashableValue> processMembershipQuery(ObservationRow row, int offset, ExprValue valueExpr) {
		Query<Boolean> query = new QuerySimple<>(row, row.getWord(), valueExpr.get(), offset);
		Boolean result = membershipOracle.answerMembershipQuery(query);
		Query<HashableValue> queryResult = new QuerySimple<>(row, row.getWord(), valueExpr.get(), offset);
		queryResult.answerQuery(getHashableValueBoolean(result));
		return queryResult;
	}
	
	private boolean processMembershipQuery(Word prefix, Word suffix) {
		Query<Boolean> query = new QuerySimple<>(null, prefix, suffix, -1);
		return membershipOracle.answerMembershipQuery(query);
	}
	

	private boolean isCEAccepting;
	
	@Override
	protected ExprValue getCounterExampleWord(Query<Boolean> query) {
		if(query.getQueryAnswer() == null) {
			// for direct use of DFA
			isCEAccepting = processMembershipQuery(query.getPrefix(), query.getSuffix());
		}else {
			isCEAccepting = query.getQueryAnswer();
		}
		return getExprValueWord(query.getQueriedWord());
	}

	@Override
	protected CeAnalyzer getCeAnalyzerInstance(ExprValue exprValue) {
		return new CeAnalyzerDFA(exprValue);
	}
	
	private class CeAnalyzerDFA extends CeAnalyzer {

		public CeAnalyzerDFA(ExprValue exprValue) {
			super(exprValue);
		}

		@Override
		public void analyze() {
			Word wordCE = exprValue.get();
			boolean resultPrev = isCEAccepting, resultCurr;
			int statePrev = getInitState(), stateCurr ;
			for(int letterNr = 0; letterNr < wordCE.length(); letterNr ++) {
				stateCurr = computeNextState(statePrev, wordCE.getLetter(letterNr));
				Word prefix = getStateLabel(stateCurr);
				Word suffix = wordCE.getSuffix(letterNr + 1);
				resultCurr = processMembershipQuery(prefix, suffix);
				if(resultPrev != resultCurr) {
					column = getExprValueWord(suffix);
					break;
				}
				statePrev = stateCurr;
			}
		}
		
	}

}
